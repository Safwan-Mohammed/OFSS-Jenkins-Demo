import { Router } from 'express';
import mongoose from 'mongoose';
import crypto from 'node:crypto';
import { z } from 'zod';
import { rateLimit } from 'express-rate-limit';
import { Shop, Category, Product, AnalyticsEvent, OrderRequest } from './models.js';
import { HttpError, id, checkoutInput, eventInput } from './validation.js';
import { productFilter } from './merchant.js';

export function publicShop(shop) {
  const fields = [
    '_id',
    'name',
    'slug',
    'description',
    'logo',
    'banner',
    'address',
    'phone',
    'whatsapp',
    'businessHours',
    'theme',
    'status',
  ];
  return Object.fromEntries(fields.map((key) => [key, shop[key]]));
}
const money = (value) =>
  `₹${value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
function checkoutResponse(orderDoc, shop) {
  const order = orderDoc.toObject ? orderDoc.toObject() : { ...orderDoc };
  delete order.idempotencyKey;
  delete order.requestHash;
  const lines = [
    'Hello, I would like to place an order.',
    '',
    `Shop: ${shop.name}`,
    `Order ID: #${order.reference}`,
    `Customer: ${order.customer.name}`,
    `Phone: ${order.customer.phone}`,
    '',
    'Items:',
    ...order.items.map(
      (item, index) =>
        `${index + 1}. ${item.name} — ${item.quantity} ${item.unit} × ${money(item.price)} = ${money(item.subtotal)}`,
    ),
    '',
    `Estimated Total: ${money(order.total)}`,
  ];
  if (order.customer.note) lines.push(`Note: ${order.customer.note}`);
  lines.push(
    '',
    'This is an order request. Availability and final pricing will be confirmed by the merchant.',
  );
  const message = lines.join('\n');
  return {
    order,
    whatsappUrl: `https://wa.me/${shop.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`,
    message,
  };
}
export function publicRouter() {
  const router = Router();
  router.param('slug', async (req, res, next, slug) => {
    if (!/^[a-z0-9-]{1,100}$/.test(slug)) throw new HttpError(400, 'Invalid shop address');
    const shop = await Shop.findOne({ slug });
    if (!shop) throw new HttpError(404, 'Shop not found');
    if (shop.status !== 'active')
      throw new HttpError(423, 'Shop temporarily unavailable', 'SHOP_SUSPENDED');
    req.shop = shop;
    next();
  });
  router.get('/:slug', async (req, res) =>
    res.json({
      shop: publicShop(req.shop),
      categories: await Category.find({ shop: req.shop._id, active: true }).sort({ name: 1 }),
    }),
  );
  router.get('/:slug/products', async (req, res) => {
    const filter = productFilter(req.query);
    const activeCategories = await Category.find({ shop: req.shop._id, active: true }).distinct(
      '_id',
    );
    if (
      filter.category &&
      !activeCategories.some((categoryId) => String(categoryId) === filter.category)
    )
      return res.json({ products: [], total: 0 });
    filter.category ||= { $in: activeCategories };
    const products = await Product.find({ ...filter, shop: req.shop._id, active: true })
      .populate('category', 'name')
      .sort({ name: 1 });
    res.json({ products, total: products.length });
  });
  const activeProduct = async (shopId, productId) => {
    const product = await Product.findOne({
      _id: id(productId),
      shop: shopId,
      active: true,
    }).populate('category', 'name active');
    if (!product || !product.category?.active) throw new HttpError(404, 'Product is unavailable');
    return product;
  };
  router.get('/:slug/products/:id', async (req, res) =>
    res.json({ product: await activeProduct(req.shop._id, req.params.id) }),
  );
  const eventLimit = rateLimit({
    windowMs: 60 * 1000,
    limit: 80,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { message: 'Too many activity updates. Try again shortly.' },
  });
  router.post('/:slug/events', eventLimit, async (req, res) => {
    const data = eventInput.parse(req.body);
    const product = await activeProduct(req.shop._id, data.productId);
    if (data.type === 'add_to_cart' && product.stock === 0)
      throw new HttpError(409, 'This product is out of stock');
    await AnalyticsEvent.create({ shop: req.shop._id, product: product._id, type: data.type });
    res.status(201).json({ message: 'Activity recorded' });
  });
  const checkoutLimit = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 30,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { message: 'Too many order requests. Please try again later.' },
  });
  router.post('/:slug/checkout', checkoutLimit, async (req, res) => {
    const data = checkoutInput.parse(req.body);
    if (!/^\d{8,15}$/.test(req.shop.whatsapp.replace(/\D/g, '')))
      throw new HttpError(
        409,
        'This merchant has not configured WhatsApp ordering yet. Please contact the shop.',
      );
    const key = req.get('Idempotency-Key')
      ? z
          .string()
          .min(16)
          .max(128)
          .regex(/^[a-zA-Z0-9_-]+$/)
          .parse(req.get('Idempotency-Key'))
      : null;
    const quantities = new Map();
    for (const item of data.items)
      quantities.set(
        item.productId.toLowerCase(),
        (quantities.get(item.productId.toLowerCase()) || 0) + item.quantity,
      );
    if ([...quantities.values()].some((quantity) => quantity > 100000))
      throw new HttpError(400, 'The maximum quantity per product is 100,000');
    const requestHash = crypto
      .createHash('sha256')
      .update(JSON.stringify({ customer: data.customer, items: [...quantities.entries()].sort() }))
      .digest('hex');
    const existingResponse = async () => {
      if (!key) return null;
      const existing = await OrderRequest.findOne({
        shop: req.shop._id,
        idempotencyKey: key,
      }).select('+requestHash');
      if (!existing) return null;
      if (existing.requestHash !== requestHash)
        throw new HttpError(
          409,
          'This checkout key was already used with different order details. Start a new checkout.',
        );
      return checkoutResponse(existing, req.shop);
    };
    const existing = await existingResponse();
    if (existing) return res.json(existing);
    let order;
    try {
      await mongoose.connection.transaction(async (session) => {
        const shop = await Shop.findOne({ _id: req.shop._id, status: 'active' }).session(session);
        if (!shop) throw new HttpError(423, 'Shop temporarily unavailable', 'SHOP_SUSPENDED');
        const categories = await Category.find({ shop: shop._id, active: true })
          .distinct('_id')
          .session(session);
        const products = await Product.find({
          shop: shop._id,
          _id: { $in: [...quantities.keys()] },
          active: true,
          category: { $in: categories },
        }).session(session);
        if (products.length !== quantities.size)
          throw new HttpError(
            409,
            'One or more products are unavailable. Please review your cart.',
          );
        const items = products.map((product) => {
          const quantity = quantities.get(String(product._id));
          if (quantity > product.stock)
            throw new HttpError(
              409,
              `${product.name}: only ${product.stock} ${product.unit} available. Please review your cart.`,
            );
          const pricePaise = Math.round(product.price * 100);
          const subtotalPaise = pricePaise * quantity;
          return {
            product: product._id,
            name: product.name,
            quantity,
            price: pricePaise / 100,
            unit: product.unit,
            subtotal: subtotalPaise / 100,
            pricePaise,
            subtotalPaise,
          };
        });
        const totalPaise = items.reduce((total, item) => total + item.subtotalPaise, 0);
        if (!Number.isSafeInteger(totalPaise))
          throw new HttpError(400, 'Order total exceeds supported limits');
        [order] = await OrderRequest.create(
          [
            {
              shop: shop._id,
              reference: `ORD-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
              customer: data.customer,
              items,
              totalPaise,
              total: totalPaise / 100,
              ...(key ? { idempotencyKey: key, requestHash } : {}),
            },
          ],
          { session },
        );
        await AnalyticsEvent.create([{ shop: shop._id, type: 'whatsapp_checkout' }], { session });
      });
    } catch (error) {
      if (error.code === 11000 && key) {
        const prior = await existingResponse();
        if (prior) return res.json(prior);
      }
      throw error;
    }
    res.status(201).json(checkoutResponse(order, req.shop));
  });
  return router;
}
