import 'dotenv/config';
import { readConfig } from './config.js';
import { connectDatabase } from './database.js';
import { seedDemo } from './seed.js';

let disconnect;
try {
  const config = readConfig();
  if (config.production) throw new Error('Sample seeding is disabled in production.');
  disconnect = await connectDatabase(config);
  const result = await seedDemo();
  console.log(
    result.seeded
      ? 'Sample shops, inventory, events, and requests created. Sample identities have no Google credentials; demo login remains disabled against persistent databases.'
      : 'Database already contains users. No data was changed.',
  );
} catch (error) {
  console.error('Seed failed:', error.message);
  process.exitCode = 1;
} finally {
  if (disconnect) await disconnect();
}
