import { Router } from 'express';
import mongoose from 'mongoose';
import multer from 'multer';
import { v2 as cloudinary } from 'cloudinary';
import { rateLimit } from 'express-rate-limit';
import { Product, Category, Shop, InventoryTransaction, OrderRequest } from './models.js';
import { authenticate, requireRole, merchantContext, requireActive } from './auth.js';
import {
  HttpError,
  id,
  productInput,
  productPatch,
  categoryInput,
  categoryPatch,
  shopPatch,
  inventoryInput,
  listInput,
  daysInput,
  slugify,
  escapeRegex,
} from './validation.js';
import { shopAnalytics } from './analytics.js';

export function productFilter(query) {
  const params = listInput.parse(query);
  const filter = {};
  if (params.search)
    filter.$or = [
      { name: { $regex: escapeRegex(params.search), $options: 'i' } },
      { sku: { $regex: escapeRegex(params.search), $options: 'i' } },
    ];
  if (params.category) filter.category = params.category;
  if (params.active) filter.active = params.active === 'true';
  if (params.stock === 'out') filter.stock = 0;
  if (params.stock === 'in') filter.stock = { $gt: 0 };
  if (params.stock === 'low') {
    filter.stock = { $gt: 0 };
    filter.$expr = { $lte: ['$stock', '$minStock'] };
  }
  return filter;
}
async function checkCategory(categoryId, shopId, session) {
  if (!(await Category.exists({ _id: categoryId, shop: shopId }).session(session || null)))
    throw new HttpError(400, 'Select a category belonging to this shop');
}
async function stockHistory(product, change, reason, userId, session) {
  if (!change) return;
  await InventoryTransaction.create(
    [
      {
        shop: product.shop,
        product: product._id,
        type: change > 0 ? 'stock_in' : 'stock_out',
        quantityChange: change,
        stockBefore: product.stock - change,
        stockAfter: product.stock,
        reason,
        updatedBy: userId,
      },
    ],
    { session },
  );
}
function imageType(buffer) {
  if (buffer.length < 12) return null;
  if (buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])))
    return 'image/png';
  if (buffer[0] === 255 && buffer[1] === 216 && buffer[2] === 255) return 'image/jpeg';
  if (buffer.subarray(0, 4).toString() === 'RIFF' && buffer.subarray(8, 12).toString() === 'WEBP')
    return 'image/webp';
  if (['GIF87a', 'GIF89a'].includes(buffer.subarray(0, 6).toString())) return 'image/gif';
  return null;
}

export function merchantRouter(config) {
  const router = Router();
  router.use(authenticate(config), requireRole('merchant_admin'), merchantContext);
  router.get('/shop', (req, res) => res.json({ shop: req.shop }));
  router.use(requireActive);
  router.patch('/shop', async (req, res) => {
    const data = shopPatch.parse(req.body);
    if (data.whatsapp) data.whatsapp = data.whatsapp.replace(/\D/g, '');
    const shop = await Shop.findOneAndUpdate(
      { _id: req.shop._id, owner: req.user._id },
      { $set: data },
      { new: true, runValidators: true },
    );
    res.json({ shop });
  });
  router.get(['/dashboard', '/analytics'], async (req, res) =>
    res.json(await shopAnalytics(req.shop._id, daysInput.parse(req.query.days))),
  );
  router.get('/products', async (req, res) => {
    const filter = { ...productFilter(req.query), shop: req.shop._id };
    const products = await Product.find(filter)
      .populate('category', 'name')
      .sort({ createdAt: -1 });
    res.json({ products, total: products.length });
  });
  router.get('/products/:id', async (req, res) => {
    const product = await Product.findOne({ _id: id(req.params.id), shop: req.shop._id }).populate(
      'category',
      'name',
    );
    if (!product) throw new HttpError(404, 'Product not found');
    res.json({ product });
  });
  router.post('/products', async (req, res) => {
    const data = productInput.parse(req.body);
    let product;
    await mongoose.connection.transaction(async (session) => {
      await checkCategory(data.category, req.shop._id, session);
      [product] = await Product.create([{ ...data, shop: req.shop._id }], { session });
      await stockHistory(product, product.stock, 'Opening stock', req.user._id, session);
    });
    res
      .status(201)
      .json({
        product: await Product.findOne({ _id: product._id, shop: req.shop._id }).populate(
          'category',
          'name',
        ),
      });
  });
  router.patch('/products/:id', async (req, res) => {
    const productId = id(req.params.id);
    const data = productPatch.parse(req.body);
    await mongoose.connection.transaction(async (session) => {
      const product = await Product.findOne({ _id: productId, shop: req.shop._id }).session(
        session,
      );
      if (!product) throw new HttpError(404, 'Product not found');
      if (data.category) await checkCategory(data.category, req.shop._id, session);
      const oldStock = product.stock;
      Object.assign(product, data);
      await product.save({ session });
      await stockHistory(
        product,
        product.stock - oldStock,
        'Stock updated in product editor',
        req.user._id,
        session,
      );
    });
    res.json({
      product: await Product.findOne({ _id: productId, shop: req.shop._id }).populate(
        'category',
        'name',
      ),
    });
  });
  router.delete('/products/:id', async (req, res) => {
    const product = await Product.findOneAndUpdate(
      { _id: id(req.params.id), shop: req.shop._id },
      { active: false },
      { new: true },
    ).populate('category', 'name');
    if (!product) throw new HttpError(404, 'Product not found');
    res.json({
      product,
      message: 'Product deactivated. Inventory and request history are preserved.',
    });
  });
  router.get('/categories', async (req, res) =>
    res.json({ categories: await Category.find({ shop: req.shop._id }).sort({ name: 1 }) }),
  );
  router.post('/categories', async (req, res) => {
    const data = categoryInput.parse(req.body);
    const category = await Category.create({
      ...data,
      slug: slugify(data.name),
      shop: req.shop._id,
    });
    res.status(201).json({ category });
  });
  router.patch('/categories/:id', async (req, res) => {
    const data = categoryPatch.parse(req.body);
    if (data.name) data.slug = slugify(data.name);
    const category = await Category.findOneAndUpdate(
      { _id: id(req.params.id), shop: req.shop._id },
      data,
      { new: true, runValidators: true },
    );
    if (!category) throw new HttpError(404, 'Category not found');
    res.json({ category });
  });
  router.delete('/categories/:id', async (req, res) => {
    const category = await Category.findOneAndUpdate(
      { _id: id(req.params.id), shop: req.shop._id },
      { active: false },
      { new: true },
    );
    if (!category) throw new HttpError(404, 'Category not found');
    res.json({
      category,
      message: 'Category deactivated. Its products are hidden from the storefront.',
    });
  });
  router.get('/inventory', async (req, res) =>
    res.json({
      transactions: await InventoryTransaction.find({ shop: req.shop._id })
        .populate('product', 'name sku unit')
        .populate('updatedBy', 'name')
        .sort({ createdAt: -1 })
        .limit(500),
    }),
  );
  router.post('/inventory', async (req, res) => {
    const data = inventoryInput.parse(req.body);
    let product;
    await mongoose.connection.transaction(async (session) => {
      const query = { _id: data.productId, shop: req.shop._id };
      if (data.quantityChange < 0) query.stock = { $gte: -data.quantityChange };
      else query.stock = { $lte: 100000000 - data.quantityChange };
      product = await Product.findOneAndUpdate(
        query,
        { $inc: { stock: data.quantityChange } },
        { new: true, session, runValidators: true },
      );
      if (!product) {
        if (!(await Product.exists({ _id: data.productId, shop: req.shop._id }).session(session)))
          throw new HttpError(404, 'Product not found');
        throw new HttpError(
          409,
          'Stock adjustment exceeds available inventory or the supported stock limit',
        );
      }
      await stockHistory(product, data.quantityChange, data.reason, req.user._id, session);
    });
    res
      .status(201)
      .json({
        product: await Product.findOne({ _id: product._id, shop: req.shop._id }).populate(
          'category',
          'name',
        ),
        message: 'Inventory updated',
      });
  });
  router.get('/orders', async (req, res) =>
    res.json({
      orders: await OrderRequest.find({ shop: req.shop._id }).sort({ createdAt: -1 }).limit(500),
    }),
  );
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024, files: 5, fields: 0 },
    fileFilter: (req, file, callback) =>
      callback(
        ['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(file.mimetype)
          ? null
          : new HttpError(400, 'Upload JPG, PNG, WEBP, or GIF images'),
        true,
      ),
  });
  const uploadLimit = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 30,
    keyGenerator: (req) => String(req.user._id),
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { message: 'Upload limit reached. Try again later.' },
  });
  router.post(
    '/uploads',
    uploadLimit,
    (req, res, next) => {
      if (
        !config.cloudinary.cloud_name ||
        !config.cloudinary.api_key ||
        !config.cloudinary.api_secret
      )
        throw new HttpError(
          503,
          'Image uploads require Cloudinary configuration. Existing catalog images remain available.',
        );
      next();
    },
    upload.array('images', 5),
    async (req, res) => {
      if (!req.files?.length) throw new HttpError(400, 'Choose at least one image');
      if (req.files.some((file) => imageType(file.buffer) !== file.mimetype))
        throw new HttpError(400, 'Image content does not match its file type');
      cloudinary.config(config.cloudinary);
      const uploaded = [];
      try {
        for (const file of req.files) {
          const result = await new Promise((resolve, reject) => {
            const stream = cloudinary.uploader.upload_stream(
              {
                folder: `supplylane/${req.shop._id}`,
                resource_type: 'image',
                allowed_formats: ['jpg', 'png', 'webp', 'gif'],
              },
              (error, result) => (error ? reject(error) : resolve(result)),
            );
            stream.end(file.buffer);
          });
          uploaded.push(result);
        }
      } catch {
        await Promise.allSettled(
          uploaded.map((result) => cloudinary.uploader.destroy(result.public_id)),
        );
        throw new HttpError(502, 'Image upload failed. Please try again.');
      }
      res.status(201).json({ images: uploaded.map((result) => result.secure_url) });
    },
  );
  return router;
}
