import { Router } from 'express';
import mongoose from 'mongoose';
import { User, Shop, Product, OrderRequest, AuditLog } from './models.js';
import { authenticate, requireRole, publicUser } from './auth.js';
import { HttpError, id, statusInput, escapeRegex, listInput } from './validation.js';
import { shopAnalytics } from './analytics.js';

export function platformRouter(config) {
  const router = Router();
  router.use(authenticate(config), requireRole('super_admin'));
  router.get('/dashboard', async (req, res) => {
    const [
      totalMerchants,
      totalShops,
      totalProducts,
      totalRequests,
      activeShops,
      suspendedShops,
      shops,
      recentActivity,
    ] = await Promise.all([
      User.countDocuments({ role: 'merchant_admin' }),
      Shop.countDocuments(),
      Product.countDocuments({ active: true }),
      OrderRequest.countDocuments(),
      Shop.countDocuments({ status: 'active' }),
      Shop.countDocuments({ status: 'suspended' }),
      Shop.find().populate('owner', 'name email').sort({ createdAt: -1 }).limit(10),
      AuditLog.find()
        .populate('performedBy', 'name email')
        .populate('targetShop', 'name slug')
        .sort({ createdAt: -1 })
        .limit(10),
    ]);
    res.json({
      stats: {
        totalMerchants,
        totalShops,
        totalProducts,
        totalRequests,
        activeShops,
        suspendedShops,
      },
      shops,
      recentActivity,
    });
  });
  router.get('/shops', async (req, res) => {
    const { search } = listInput.parse(req.query);
    let filter = {};
    if (search) {
      const regex = { $regex: escapeRegex(search), $options: 'i' };
      const users = await User.find({ $or: [{ name: regex }, { email: regex }] }).distinct('_id');
      filter = { $or: [{ name: regex }, { slug: regex }, { owner: { $in: users } }] };
    }
    res.json({
      shops: await Shop.find(filter)
        .populate('owner', 'name email createdAt')
        .sort({ createdAt: -1 }),
    });
  });
  router.get('/shops/:id', async (req, res) => {
    const shop = await Shop.findById(id(req.params.id)).populate(
      'owner',
      'name email role createdAt',
    );
    if (!shop) throw new HttpError(404, 'Shop not found');
    const [products, analytics] = await Promise.all([
      Product.find({ shop: shop._id }).populate('category', 'name').sort({ name: 1 }),
      shopAnalytics(shop._id),
    ]);
    res.json({
      shop,
      owner: shop.owner ? publicUser(shop.owner) : null,
      products,
      stats: analytics.stats,
      analytics,
    });
  });
  router.patch('/shops/:id/status', async (req, res) => {
    const shopId = id(req.params.id);
    const data = statusInput.parse(req.body);
    let shop;
    await mongoose.connection.transaction(async (session) => {
      shop = await Shop.findById(shopId).session(session);
      if (!shop) throw new HttpError(404, 'Shop not found');
      const previousStatus = shop.status;
      shop.status = data.status;
      shop.suspensionReason = data.status === 'suspended' ? data.reason : '';
      shop.suspendedAt = data.status === 'suspended' ? new Date() : null;
      await shop.save({ session });
      await AuditLog.create(
        [
          {
            performedBy: req.user._id,
            action: data.status === 'suspended' ? 'shop_suspended' : 'shop_reactivated',
            targetShop: shop._id,
            targetUser: shop.owner,
            reason: data.reason,
            metadata: { previousStatus, newStatus: data.status },
          },
        ],
        { session },
      );
    });
    res.json({ shop: await Shop.findById(shop._id).populate('owner', 'name email') });
  });
  router.get('/audit', async (req, res) =>
    res.json({
      logs: await AuditLog.find()
        .populate('performedBy', 'name email')
        .populate('targetShop', 'name slug status')
        .populate('targetUser', 'name email')
        .sort({ createdAt: -1 })
        .limit(500),
    }),
  );
  return router;
}
