import mongoose from 'mongoose';
import { fileURLToPath } from 'node:url';
import { MongoMemoryReplSet } from 'mongodb-memory-server';
import { initializeModels } from './models.js';

export async function connectDatabase(config) {
  let memory;
  try {
    if (config.demoMode)
      memory = await MongoMemoryReplSet.create({
        binary: {
          downloadDir:
            process.env.MONGOMS_DOWNLOAD_DIR ||
            fileURLToPath(new URL('../../node_modules/.cache/mongodb-binaries', import.meta.url)),
        },
        replSet: { count: 1, storageEngine: 'wiredTiger' },
        instanceOpts: [{ ip: '127.0.0.1' }],
      });
    await mongoose.connect(memory ? memory.getUri('supplylane_demo') : config.mongoUri, {
      serverSelectionTimeoutMS: 15000,
    });
    const hello = await mongoose.connection.db.admin().command({ hello: 1 });
    if (!hello.setName && hello.msg !== 'isdbgrid')
      throw new Error(
        'MongoDB must run as a replica set (or Atlas/sharded deployment) to support atomic inventory, checkout, and audit transactions.',
      );
    await initializeModels();
    return async () => {
      await mongoose.disconnect();
      if (memory) await memory.stop();
    };
  } catch (error) {
    await mongoose.disconnect();
    if (memory) await memory.stop();
    throw error;
  }
}
