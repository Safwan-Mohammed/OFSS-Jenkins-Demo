import { z } from 'zod';
export class HttpError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
}
export const objectId = z.string().regex(/^[a-f\d]{24}$/i, 'Invalid ID');
export const id = (value) => objectId.parse(value);
const text = (max = 120) => z.string().trim().min(1).max(max);
const image = z
  .string()
  .max(1500)
  .refine(
    (v) => !v || /^https?:\/\/[^\s]+$/i.test(v) || /^\/(?!\/)[\w/.,%()@-]+$/.test(v),
    'Use an HTTP(S) URL or local image path',
  );
const phone = z
  .string()
  .trim()
  .max(25)
  .refine(
    (v) =>
      /^[+\d\s()-]+$/.test(v) &&
      v.replace(/\D/g, '').length >= 8 &&
      v.replace(/\D/g, '').length <= 15,
    'Enter a valid phone number',
  );
export const productInput = z
  .object({
    name: text(160),
    description: z.string().trim().max(3000).default(''),
    sku: text(80),
    price: z
      .number()
      .min(0)
      .max(10000000)
      .refine(
        (v) => Math.abs(v * 100 - Math.round(v * 100)) < 0.00001,
        'Price supports two decimal places',
      ),
    unit: text(30),
    stock: z.number().int().min(0).max(100000000).default(0),
    minStock: z.number().int().min(0).max(100000000).default(10),
    category: objectId,
    images: z.array(image).max(5).default([]),
    active: z.boolean().default(true),
  })
  .strict();
export const productPatch = z
  .object(
    Object.fromEntries(
      Object.entries(productInput.shape).map(([key, schema]) => [
        key,
        schema instanceof z.ZodDefault ? schema.removeDefault() : schema,
      ]),
    ),
  )
  .strict()
  .partial();
export const categoryInput = z
  .object({ name: text(100), image: image.default(''), active: z.boolean().default(true) })
  .strict();
export const categoryPatch = z
  .object(
    Object.fromEntries(
      Object.entries(categoryInput.shape).map(([key, schema]) => [
        key,
        schema instanceof z.ZodDefault ? schema.removeDefault() : schema,
      ]),
    ),
  )
  .strict()
  .partial();
export const shopPatch = z
  .object({
    name: text(120),
    slug: z
      .string()
      .min(3)
      .max(90)
      .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
    description: z.string().trim().max(3000),
    logo: image,
    banner: image,
    address: z.string().trim().max(600),
    phone: phone.or(z.literal('')),
    whatsapp: phone.or(z.literal('')),
    businessHours: z.string().trim().max(300),
    theme: z
      .object({ primary: z.string().regex(/^#[a-f0-9]{6}$/i, 'Use a 6-digit hex color') })
      .strict(),
  })
  .strict()
  .partial();
export const inventoryInput = z
  .object({
    productId: objectId,
    quantityChange: z
      .number()
      .int()
      .min(-100000000)
      .max(100000000)
      .refine((v) => v !== 0, 'Enter a nonzero stock change'),
    reason: text(400),
  })
  .strict();
export const checkoutInput = z
  .object({
    customer: z
      .object({ name: text(100), phone, note: z.string().trim().max(600).default('') })
      .strict(),
    items: z
      .array(
        z.object({ productId: objectId, quantity: z.number().int().min(1).max(100000) }).strict(),
      )
      .min(1)
      .max(100),
  })
  .strict();
export const eventInput = z
  .object({ type: z.enum(['product_view', 'add_to_cart']), productId: objectId })
  .strict();
export const statusInput = z
  .object({
    status: z.enum(['active', 'suspended']),
    reason: z.string().trim().min(3, 'Provide a reason for this account status change').max(600),
  })
  .strict();
export const listInput = z.object({
  search: z.string().trim().max(100).optional(),
  category: objectId.optional(),
  stock: z.enum(['low', 'out', 'in']).optional(),
  active: z.enum(['true', 'false']).optional(),
});
export const daysInput = z.coerce.number().int().min(1).max(365).default(30);
export const slugify = (value) =>
  value
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'shop';
export const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
