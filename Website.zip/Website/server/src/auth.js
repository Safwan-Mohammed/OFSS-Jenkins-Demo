import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import mongoose from 'mongoose';
import { OAuth2Client } from 'google-auth-library';
import { z } from 'zod';
import { User, Shop } from './models.js';
import { HttpError, slugify } from './validation.js';

const jwtOptions = { issuer: 'supplylane', audience: 'supplylane-web', algorithms: ['HS256'] };
export const publicUser = (user) => ({
  _id: user._id,
  name: user.name,
  email: user.email,
  role: user.role,
  shop: user.shop,
  createdAt: user.createdAt,
});
export function signToken(user, config) {
  return jwt.sign({}, config.jwtSecret, {
    algorithm: 'HS256',
    issuer: jwtOptions.issuer,
    audience: jwtOptions.audience,
    subject: String(user._id),
    expiresIn: config.jwtExpiresIn,
  });
}

export function authenticate(config) {
  return async (req, res, next) => {
    const auth = req.headers.authorization;
    if (!auth?.startsWith('Bearer ')) throw new HttpError(401, 'Sign in to continue');
    let payload;
    try {
      payload = jwt.verify(auth.slice(7), config.jwtSecret, jwtOptions);
    } catch {
      throw new HttpError(401, 'Your session has expired. Please sign in again.');
    }
    if (!mongoose.isValidObjectId(payload.sub)) throw new HttpError(401, 'Invalid session');
    const user = await User.findById(payload.sub);
    if (!user) throw new HttpError(401, 'Account not found');
    if (
      user.role === 'super_admin' &&
      !config.demoMode &&
      (!user.googleId || !config.adminEmails.includes(user.email.toLowerCase()))
    )
      throw new HttpError(403, 'Platform access is no longer authorized for this account');
    req.user = user;
    next();
  };
}
export function requireRole(role) {
  return (req, res, next) => {
    if (req.user.role !== role)
      throw new HttpError(403, 'You do not have permission to perform this action');
    next();
  };
}
export async function merchantContext(req, res, next) {
  const shop = await Shop.findOne({ _id: req.user.shop, owner: req.user._id });
  if (!shop) throw new HttpError(404, 'Your shop was not found');
  req.shop = shop;
  next();
}
export function requireActive(req, res, next) {
  if (req.shop.status !== 'active')
    throw new HttpError(
      423,
      'Your shop is temporarily suspended. Contact the platform administrator.',
      'SHOP_SUSPENDED',
    );
  next();
}

export function registerAuth(router, config, authLimiter) {
  const google = new OAuth2Client(config.googleClientId);
  router.get('/auth/config', (req, res) =>
    res.json({ demoMode: config.demoMode, googleClientId: config.googleClientId }),
  );
  router.post('/auth/google', authLimiter, async (req, res) => {
    if (!config.googleClientId)
      throw new HttpError(
        503,
        'Google sign-in is not configured. Set GOOGLE_CLIENT_ID on the server.',
      );
    const { credential } = z
      .object({ credential: z.string().min(10).max(10000) })
      .strict()
      .parse(req.body);
    let profile;
    try {
      profile = (
        await google.verifyIdToken({ idToken: credential, audience: config.googleClientId })
      ).getPayload();
    } catch {
      throw new HttpError(401, 'Google sign-in could not be verified');
    }
    if (!profile?.email_verified || !profile.email || !profile.sub)
      throw new HttpError(401, 'A verified Google email is required');
    const email = profile.email.toLowerCase();
    const role = config.adminEmails.includes(email) ? 'super_admin' : 'merchant_admin';
    let user;
    await mongoose.connection.transaction(async (session) => {
      user = await User.findOne({ email }).session(session);
      if (user?.googleId && user.googleId !== profile.sub)
        throw new HttpError(403, 'This email is linked to another Google account');
      if (!user) {
        [user] = await User.create(
          [{ name: profile.name || email.split('@')[0], email, googleId: profile.sub, role }],
          { session },
        );
      } else {
        user.googleId = profile.sub;
        user.name = profile.name || user.name;
        user.role = role;
      }
      if (role === 'merchant_admin' && !user.shop) {
        const name = `${user.name.split(' ')[0]}'s Wholesale`;
        const [shop] = await Shop.create(
          [
            {
              owner: user._id,
              name,
              slug: `${slugify(name).slice(0, 60)}-${crypto.randomBytes(4).toString('hex')}`,
            },
          ],
          { session },
        );
        user.shop = shop._id;
      }
      await user.save({ session });
    });
    const shop = user.shop ? await Shop.findById(user.shop) : null;
    res.json({ token: signToken(user, config), user: publicUser(user), shop });
  });
  router.post('/auth/demo', authLimiter, async (req, res) => {
    if (!config.demoMode || config.production || config.mongoUri)
      throw new HttpError(404, 'Route not found');
    const { account } = z
      .object({ account: z.enum(['merchant', 'merchant2', 'super_admin']) })
      .strict()
      .parse(req.body);
    const emails = {
      merchant: 'aarav@example.test',
      merchant2: 'meera@example.test',
      super_admin: 'admin@example.test',
    };
    const user = await User.findOne({ email: emails[account] });
    if (!user) throw new HttpError(503, 'Demo data has not been initialized');
    res.json({
      token: signToken(user, config),
      user: publicUser(user),
      shop: user.shop ? await Shop.findById(user.shop) : null,
    });
  });
  router.get('/auth/me', authenticate(config), async (req, res) =>
    res.json({
      user: publicUser(req.user),
      shop: req.user.shop ? await Shop.findOne({ _id: req.user.shop, owner: req.user._id }) : null,
    }),
  );
}
