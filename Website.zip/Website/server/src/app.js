import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { rateLimit } from 'express-rate-limit';
import { ZodError } from 'zod';
import { registerAuth } from './auth.js';
import { merchantRouter } from './merchant.js';
import { publicRouter } from './public.js';
import { platformRouter } from './platform.js';
import { HttpError } from './validation.js';

export function createApp(config) {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy);
  app.use(helmet());
  app.use(
    cors({
      origin(origin, callback) {
        callback(
          !origin || config.clientOrigins.includes(origin)
            ? null
            : new HttpError(403, 'This origin is not allowed'),
          true,
        );
      },
      credentials: false,
      methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'Idempotency-Key'],
    }),
  );
  app.use(express.json({ limit: '100kb' }));
  const api = express.Router();
  api.use(
    rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: 1000,
      standardHeaders: 'draft-8',
      legacyHeaders: false,
      message: { message: 'Too many requests. Please try again later.' },
    }),
  );
  api.get('/health', (req, res) =>
    res.json({ status: 'ok', mode: config.demoMode ? 'demo' : 'live' }),
  );
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 40,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { message: 'Too many login attempts. Please try again later.' },
  });
  registerAuth(api, config, authLimiter);
  api.use('/merchant', merchantRouter(config));
  api.use('/shops', publicRouter());
  api.use('/platform', platformRouter(config));
  app.use('/api', api);
  app.use((req, res, next) => next(new HttpError(404, 'Route not found')));
  app.use((error, req, res, next) => {
    if (res.headersSent) return next(error);
    if (error instanceof ZodError)
      return res
        .status(400)
        .json({
          message: 'Please check the submitted details',
          errors: error.issues.map((issue) => ({
            field: issue.path.join('.'),
            message: issue.message,
          })),
        });
    if (error.code === 11000)
      return res
        .status(409)
        .json({ message: 'That email, shop address, SKU, or category name is already in use.' });
    if (error.name === 'CastError' || error.name === 'ValidationError')
      return res.status(400).json({ message: 'The submitted data is invalid' });
    if (error.name === 'MulterError')
      return res
        .status(400)
        .json({
          message: 'Upload up to five images, each no larger than 5 MB, using the images field.',
        });
    if (error.type === 'entity.too.large')
      return res.status(413).json({ message: 'Request is too large' });
    if (error.type === 'entity.parse.failed')
      return res.status(400).json({ message: 'Request must contain valid JSON' });
    const status = error.status && error.status >= 400 && error.status < 600 ? error.status : 500;
    if (status === 500) console.error('[API error]', error.name, error.message);
    res
      .status(status)
      .json({
        message: status === 500 ? 'Something went wrong. Please try again.' : error.message,
        ...(error instanceof HttpError && error.code ? { code: error.code } : {}),
      });
  });
  return app;
}
