import mongoose from 'mongoose';
const { Schema } = mongoose;
const ref = (model, required = true) => ({ type: Schema.Types.ObjectId, ref: model, required });
const timestamps = { timestamps: true, versionKey: false };
const userSchema = new Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    googleId: { type: String, unique: true, sparse: true },
    role: { type: String, enum: ['merchant_admin', 'super_admin'], default: 'merchant_admin' },
    shop: ref('Shop', false),
  },
  timestamps,
);
const shopSchema = new Schema(
  {
    owner: { ...ref('User'), unique: true },
    name: { type: String, required: true },
    slug: { type: String, required: true, unique: true },
    description: { type: String, default: '' },
    logo: { type: String, default: '' },
    banner: { type: String, default: '' },
    address: { type: String, default: '' },
    phone: { type: String, default: '' },
    whatsapp: { type: String, default: '' },
    businessHours: { type: String, default: '' },
    theme: { primary: { type: String, default: '#246b50' } },
    status: { type: String, enum: ['active', 'suspended'], default: 'active' },
    suspensionReason: { type: String, default: '' },
    suspendedAt: { type: Date, default: null },
  },
  timestamps,
);
const categorySchema = new Schema(
  {
    shop: ref('Shop'),
    name: { type: String, required: true },
    slug: { type: String, required: true },
    image: { type: String, default: '' },
    active: { type: Boolean, default: true },
  },
  timestamps,
);
categorySchema.index({ shop: 1, slug: 1 }, { unique: true });
const productSchema = new Schema(
  {
    shop: ref('Shop'),
    category: ref('Category'),
    name: { type: String, required: true },
    description: { type: String, default: '' },
    sku: { type: String, required: true },
    price: { type: Number, required: true, min: 0 },
    unit: { type: String, required: true },
    stock: { type: Number, min: 0, default: 0 },
    minStock: { type: Number, min: 0, default: 10 },
    images: { type: [String], default: [] },
    active: { type: Boolean, default: true },
  },
  timestamps,
);
productSchema.index({ shop: 1, sku: 1 }, { unique: true });
productSchema.index({ shop: 1, active: 1, category: 1 });
const inventorySchema = new Schema(
  {
    shop: ref('Shop'),
    product: ref('Product'),
    type: { type: String, enum: ['stock_in', 'stock_out'], required: true },
    quantityChange: { type: Number, required: true },
    stockBefore: Number,
    stockAfter: Number,
    reason: { type: String, required: true },
    updatedBy: ref('User'),
  },
  timestamps,
);
inventorySchema.index({ shop: 1, createdAt: -1 });
const eventSchema = new Schema(
  {
    shop: ref('Shop'),
    product: ref('Product', false),
    type: {
      type: String,
      enum: ['product_view', 'add_to_cart', 'whatsapp_checkout'],
      required: true,
    },
  },
  timestamps,
);
eventSchema.index({ shop: 1, createdAt: -1 });
const auditSchema = new Schema(
  {
    performedBy: ref('User'),
    action: { type: String, required: true },
    targetShop: ref('Shop', false),
    targetUser: ref('User', false),
    reason: { type: String, default: '' },
    metadata: Schema.Types.Mixed,
  },
  timestamps,
);
const orderSchema = new Schema(
  {
    shop: ref('Shop'),
    reference: { type: String, required: true, unique: true },
    idempotencyKey: { type: String, select: false },
    requestHash: { type: String, select: false },
    customer: { name: String, phone: String, note: String },
    items: [
      {
        _id: false,
        product: ref('Product'),
        name: String,
        quantity: Number,
        price: Number,
        unit: String,
        subtotal: Number,
        pricePaise: Number,
        subtotalPaise: Number,
      },
    ],
    total: { type: Number, required: true },
    totalPaise: { type: Number, required: true },
    status: { type: String, default: 'requested', enum: ['requested'] },
  },
  timestamps,
);
orderSchema.index({ shop: 1, createdAt: -1 });
orderSchema.index(
  { shop: 1, idempotencyKey: 1 },
  { unique: true, partialFilterExpression: { idempotencyKey: { $type: 'string' } } },
);
export const User = mongoose.model('User', userSchema);
export const Shop = mongoose.model('Shop', shopSchema);
export const Category = mongoose.model('Category', categorySchema);
export const Product = mongoose.model('Product', productSchema);
export const InventoryTransaction = mongoose.model('InventoryTransaction', inventorySchema);
export const AnalyticsEvent = mongoose.model('AnalyticsEvent', eventSchema);
export const AuditLog = mongoose.model('AuditLog', auditSchema);
export const OrderRequest = mongoose.model('OrderRequest', orderSchema);

export async function initializeModels() {
  await Promise.all(mongoose.modelNames().map((name) => mongoose.model(name).init()));
}
