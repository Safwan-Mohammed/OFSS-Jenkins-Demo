import crypto from 'node:crypto';

export function readConfig(env = process.env) {
  const production = env.NODE_ENV === 'production';
  const demoMode = env.DEMO_MODE === 'true';
  const mongoUri = env.MONGODB_URI?.trim() || '';
  if (demoMode && production) throw new Error('Demo mode is forbidden in production.');
  if (demoMode && mongoUri)
    throw new Error('Demo mode must use its own disposable database. Remove MONGODB_URI.');
  if (!demoMode && !mongoUri)
    throw new Error('MONGODB_URI is required. Use npm run demo for an isolated local preview.');
  const jwtSecret = env.JWT_SECRET || (demoMode ? crypto.randomBytes(48).toString('hex') : '');
  if (jwtSecret.length < 32 || /replace-with|change-me|your-secret/i.test(jwtSecret))
    throw new Error('JWT_SECRET must be at least 32 random characters; replace the example value.');
  const clientOrigins = (env.CLIENT_ORIGINS || 'http://localhost:5173,http://127.0.0.1:5173')
    .split(',')
    .map((v) => v.trim())
    .filter(Boolean);
  for (const origin of clientOrigins) {
    let parsed;
    try {
      parsed = new URL(origin);
    } catch {
      throw new Error('CLIENT_ORIGINS must contain explicit HTTP(S) origins.');
    }
    if (
      !['http:', 'https:'].includes(parsed.protocol) ||
      parsed.origin !== origin ||
      (production && parsed.protocol !== 'https:')
    )
      throw new Error(
        'CLIENT_ORIGINS must contain exact origins (HTTPS in production), without a trailing slash.',
      );
  }
  if (production && !env.GOOGLE_CLIENT_ID)
    throw new Error('GOOGLE_CLIENT_ID is required in production.');
  return {
    production,
    demoMode,
    mongoUri,
    jwtSecret,
    clientOrigins,
    port: Number(env.PORT || 5000),
    host: env.HOST || (production ? '0.0.0.0' : '127.0.0.1'),
    jwtExpiresIn: env.JWT_EXPIRES_IN || '8h',
    googleClientId: env.GOOGLE_CLIENT_ID || '',
    adminEmails: (env.SUPER_ADMIN_EMAILS || '')
      .split(',')
      .map((v) => v.trim().toLowerCase())
      .filter(Boolean),
    trustProxy: env.TRUST_PROXY === '1' ? 1 : false,
    cloudinary: {
      cloud_name: env.CLOUDINARY_CLOUD_NAME,
      api_key: env.CLOUDINARY_API_KEY,
      api_secret: env.CLOUDINARY_API_SECRET,
    },
  };
}
