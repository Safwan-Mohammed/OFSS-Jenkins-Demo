import { AnalyticsEvent, OrderRequest, Product } from './models.js';

export async function shopAnalytics(shopId, days = 30) {
  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  start.setUTCDate(start.getUTCDate() - days + 1);
  const [products, eventTotals, daily, mostViewedRaw, mostRequestedRaw, recentRequests] =
    await Promise.all([
      Product.find({ shop: shopId, active: true }).populate('category', 'name').lean(),
      AnalyticsEvent.aggregate([
        { $match: { shop: shopId, createdAt: { $gte: start } } },
        { $group: { _id: '$type', count: { $sum: 1 } } },
      ]),
      AnalyticsEvent.aggregate([
        { $match: { shop: shopId, createdAt: { $gte: start } } },
        {
          $group: {
            _id: {
              date: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt', timezone: 'UTC' } },
              type: '$type',
            },
            count: { $sum: 1 },
          },
        },
      ]),
      AnalyticsEvent.aggregate([
        { $match: { shop: shopId, type: 'product_view', createdAt: { $gte: start } } },
        { $group: { _id: '$product', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
        { $limit: 5 },
      ]),
      OrderRequest.aggregate([
        { $match: { shop: shopId, createdAt: { $gte: start } } },
        { $unwind: '$items' },
        { $group: { _id: '$items.product', count: { $sum: '$items.quantity' } } },
        { $sort: { count: -1 } },
        { $limit: 5 },
      ]),
      OrderRequest.find({ shop: shopId }).sort({ createdAt: -1 }).limit(5).lean(),
    ]);
  const eventMap = Object.fromEntries(eventTotals.map((v) => [v._id, v.count]));
  const series = Array.from({ length: days }, (_, index) => {
    const date = new Date(start);
    date.setUTCDate(date.getUTCDate() + index);
    return { date: date.toISOString().slice(0, 10), views: 0, carts: 0, checkouts: 0 };
  });
  const seriesMap = new Map(series.map((v) => [v.date, v]));
  const fields = { product_view: 'views', add_to_cart: 'carts', whatsapp_checkout: 'checkouts' };
  for (const entry of daily) {
    const row = seriesMap.get(entry._id.date);
    if (row) row[fields[entry._id.type]] = entry.count;
  }
  const topIds = [...mostViewedRaw, ...mostRequestedRaw].map((v) => v._id).filter(Boolean);
  const topProducts = await Product.find({ shop: shopId, _id: { $in: topIds } })
    .populate('category', 'name')
    .lean();
  const productMap = new Map(topProducts.map((p) => [String(p._id), p]));
  const hydrate = (rows) =>
    rows
      .map((v) => ({ product: productMap.get(String(v._id)), count: v.count }))
      .filter((v) => v.product);
  const lowStockProducts = products
    .filter((p) => p.stock <= p.minStock)
    .sort((a, b) => a.stock - b.stock);
  return {
    stats: {
      totalProducts: products.length,
      lowStock: lowStockProducts.filter((p) => p.stock > 0).length,
      outOfStock: products.filter((p) => p.stock === 0).length,
      totalInventory: products.reduce((n, p) => n + p.stock, 0),
      productViews: eventMap.product_view || 0,
      cartAdditions: eventMap.add_to_cart || 0,
      checkoutRequests: eventMap.whatsapp_checkout || 0,
    },
    series,
    mostViewed: hydrate(mostViewedRaw),
    mostRequested: hydrate(mostRequestedRaw),
    recentRequests,
    lowStockProducts,
  };
}
