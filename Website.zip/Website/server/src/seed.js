import {
  User,
  Shop,
  Category,
  Product,
  InventoryTransaction,
  AnalyticsEvent,
  AuditLog,
  OrderRequest,
} from './models.js';

// Adds sample data only to an empty database. Never deletes or overwrites data.
export async function seedDemo() {
  if (await User.exists({})) return { seeded: false };
  const [merchant, otherMerchant, admin] = await User.create([
    { name: 'Aarav Sharma', email: 'aarav@example.test', role: 'merchant_admin' },
    { name: 'Meera Patel', email: 'meera@example.test', role: 'merchant_admin' },
    { name: 'Alex Morgan', email: 'admin@example.test', role: 'super_admin' },
  ]);
  const [shop, otherShop] = await Shop.create([
    {
      owner: merchant._id,
      name: 'Greenfield Wholesale',
      slug: 'greenfield-wholesale',
      description:
        'Good ingredients. Better business. Your trusted source for quality grains, pantry essentials, and everyday provisions — delivered with care since 2012.',
      address: '42, Market Yard, Gultekdi, Pune, Maharashtra 411037',
      phone: '+91 90000 00000',
      whatsapp: '919000000000',
      businessHours: 'Monday – Saturday, 9:00 AM – 7:00 PM',
      theme: { primary: '#246b50' },
    },
    {
      owner: otherMerchant._id,
      name: 'Meera Pantry Co.',
      slug: 'meera-pantry',
      description: 'Independent provisions for neighborhood retailers.',
      address: 'Ahmedabad, Gujarat',
      phone: '+91 90000 00000',
      whatsapp: '919000000000',
      businessHours: 'Monday – Friday, 10:00 AM – 6:00 PM',
      theme: { primary: '#735c3d' },
    },
  ]);
  merchant.shop = shop._id;
  otherMerchant.shop = otherShop._id;
  await merchant.save();
  await otherMerchant.save();
  const categoryNames = [
    'Grains & Pulses',
    'Oils & Essentials',
    'Spices',
    'Beverages',
    'Dry Fruits',
  ];
  const categories = await Category.create(
    categoryNames.map((name, index) => ({
      shop: shop._id,
      name,
      slug: ['grains-pulses', 'oils-essentials', 'spices', 'beverages', 'dry-fruits'][index],
    })),
  );
  const rows = [
    [
      'Premium Basmati Rice',
      'Long-grain, naturally aromatic basmati rice. Carefully aged for a fluffy, separate texture. A kitchen staple for restaurants and retailers.',
      'GF-RC-001',
      1250,
      '25 kg bag',
      248,
      30,
      0,
      'rice',
    ],
    [
      'Cold-pressed Sunflower Oil',
      'Light and versatile sunflower oil, packed fresh for daily cooking. Consistent quality for commercial kitchens.',
      'GF-OL-002',
      1450,
      '15 L tin',
      186,
      25,
      1,
      'oil',
    ],
    [
      'Unpolished Toor Dal',
      'Premium split pigeon peas with a naturally rich flavor. Sorted and cleaned for reliable wholesale quality.',
      'GF-DL-003',
      1180,
      '10 kg bag',
      142,
      25,
      0,
      'lentils',
    ],
    [
      'Whole Wheat Atta',
      'Stone-ground whole wheat flour for soft, wholesome rotis. Packed in durable sacks for easy storage.',
      'GF-FL-004',
      890,
      '25 kg bag',
      215,
      30,
      0,
      'flour',
    ],
    [
      'Refined White Sugar',
      'Clean, uniform sugar crystals for bakeries, cafés, and daily retail. Easy to measure and quick to dissolve.',
      'GF-SG-005',
      2150,
      '50 kg bag',
      82,
      20,
      1,
      'sugar',
    ],
    [
      'Turmeric Powder',
      'Vibrant, finely ground turmeric with a warm aroma. Quality spices that bring everyday recipes to life.',
      'GF-SP-006',
      245,
      '1 kg pack',
      56,
      15,
      2,
      'spices',
    ],
    [
      'Assam CTC Tea',
      'A bold, malty blend from Assam for a full-bodied cup of chai. Selected for consistent color and flavor.',
      'GF-TE-007',
      420,
      '1 kg pack',
      0,
      20,
      3,
      'tea',
    ],
    [
      'Rolled Oats',
      'Whole-grain rolled oats for breakfast bowls and baking. A versatile pantry essential with a satisfying texture.',
      'GF-OT-008',
      185,
      '1 kg pack',
      18,
      25,
      0,
      'oats',
    ],
    [
      'California Almonds',
      'Whole premium almonds, selected for size and crunch. Great for retail packs, desserts, and snacking.',
      'GF-AL-009',
      780,
      '1 kg pack',
      12,
      20,
      4,
      'almonds',
    ],
    [
      'Iodized Crystal Salt',
      'Everyday iodized salt with clean, even crystals. A dependable essential for kitchens of every size.',
      'GF-SL-010',
      280,
      '25 kg bag',
      0,
      30,
      1,
      'salt',
    ],
    [
      'Kabuli Chickpeas',
      'Large, creamy chickpeas that cook evenly and hold their shape. Ideal for curries, salads, and hummus.',
      'GF-CK-011',
      1120,
      '10 kg bag',
      104,
      25,
      0,
      'chickpeas',
    ],
    [
      'Arabica Coffee Beans',
      'Medium-roasted Arabica beans with a balanced aroma and smooth finish. Freshly packed for cafés and retailers.',
      'GF-CF-012',
      920,
      '1 kg pack',
      8,
      15,
      3,
      'coffee',
    ],
  ];
  const products = await Product.create(
    rows.map(([name, description, sku, price, unit, stock, minStock, categoryIndex, asset]) => ({
      shop: shop._id,
      category: categories[categoryIndex]._id,
      name,
      description,
      sku,
      price,
      unit,
      stock,
      minStock,
      images: [`/products/${asset}.svg`],
    })),
  );
  const otherCategory = await Category.create({
    shop: otherShop._id,
    name: 'Essentials',
    slug: 'essentials',
  });
  const otherProduct = await Product.create({
    shop: otherShop._id,
    category: otherCategory._id,
    name: 'Meera Organic Rice',
    description:
      'Sample product belonging to an independent merchant for tenant isolation testing.',
    sku: 'MP-RC-001',
    price: 950,
    unit: '10 kg bag',
    stock: 60,
    minStock: 10,
    images: ['/products/rice.svg'],
  });
  const openingDate = new Date(Date.now() - 30 * 86400000);
  await InventoryTransaction.insertMany(
    [...products, otherProduct]
      .filter((p) => p.stock > 0)
      .map((product) => ({
        shop: product.shop,
        product: product._id,
        type: 'stock_in',
        quantityChange: product.stock,
        stockBefore: 0,
        stockAfter: product.stock,
        reason: 'Opening inventory',
        updatedBy: String(product.shop) === String(shop._id) ? merchant._id : otherMerchant._id,
        createdAt: openingDate,
        updatedAt: openingDate,
      })),
  );
  const events = [];
  for (let day = 29; day >= 0; day--) {
    const date = new Date();
    date.setUTCHours(8, 30, 0, 0);
    date.setUTCDate(date.getUTCDate() - day);
    const views = 22 + (((29 - day) * 7) % 31) + Math.floor((29 - day) / 3);
    for (let i = 0; i < views; i++)
      events.push({
        shop: shop._id,
        product: products[(i * 7 + day) % products.length]._id,
        type: 'product_view',
        createdAt: date,
        updatedAt: date,
      });
    for (let i = 0; i < Math.floor(views / 4); i++)
      events.push({
        shop: shop._id,
        product: products[(i + day) % 6]._id,
        type: 'add_to_cart',
        createdAt: date,
        updatedAt: date,
      });
  }
  const customers = ['Rohan Desai', 'Priya Nair', 'Vikram Singh', 'Ananya Rao', 'Arjun Mehta'];
  const orderRows = customers.map((name, i) => {
    const date = new Date(Date.now() - i * 86400000 - (i + 1) * 3600000);
    const items = [products[i % 6], products[(i + 2) % 6]].map((p, index) => ({
      product: p._id,
      name: p.name,
      quantity: index + 2 + i,
      price: p.price,
      unit: p.unit,
      pricePaise: p.price * 100,
      subtotal: p.price * (index + 2 + i),
      subtotalPaise: p.price * (index + 2 + i) * 100,
    }));
    const totalPaise = items.reduce((total, item) => total + item.subtotalPaise, 0);
    events.push({ shop: shop._id, type: 'whatsapp_checkout', createdAt: date, updatedAt: date });
    return {
      shop: shop._id,
      reference: `ORD-DEMO-${1205 - i}`,
      customer: {
        name,
        phone: '+91 90000 00000',
        note: i === 0 ? 'Please confirm availability for morning pickup.' : '',
      },
      items,
      total: totalPaise / 100,
      totalPaise,
      createdAt: date,
      updatedAt: date,
    };
  });
  await OrderRequest.insertMany(orderRows);
  await AnalyticsEvent.insertMany(events);
  await AuditLog.create({
    performedBy: admin._id,
    action: 'demo_initialized',
    targetShop: shop._id,
    reason: 'Sample shop initialized in an empty database',
    metadata: { sampleData: true },
  });
  return { seeded: true, shop, merchant, otherMerchant, admin, products, categories };
}
