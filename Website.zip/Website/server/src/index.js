import 'dotenv/config';
import { readConfig } from './config.js';
import { connectDatabase } from './database.js';
import { createApp } from './app.js';
import { seedDemo } from './seed.js';

let server;
let disconnect;
try {
  const config = readConfig();
  if (config.demoMode)
    console.log('Starting isolated demo MongoDB replica set. The first run may download MongoDB.');
  disconnect = await connectDatabase(config);
  if (config.demoMode) await seedDemo();
  server = createApp(config).listen(config.port, config.host, () => {
    console.log(`Supplylane API listening on http://localhost:${config.port}/api`);
    if (config.demoMode)
      console.log(
        'DEMO MODE: disposable data, documented sample accounts, and placeholder WhatsApp numbers.',
      );
  });
  server.on('error', async (error) => {
    console.error('Server could not start:', error.message);
    await disconnect();
    process.exitCode = 1;
  });
} catch (error) {
  console.error('Startup failed:', error.message);
  process.exitCode = 1;
}
let stopping = false;
async function stop() {
  if (stopping) return;
  stopping = true;
  if (server) await new Promise((resolve) => server.close(resolve));
  if (disconnect) await disconnect();
}
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
