import { before, after, test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import request from 'supertest';
import { readConfig } from '../src/config.js';
import { connectDatabase } from '../src/database.js';
import { createApp } from '../src/app.js';
import { seedDemo } from '../src/seed.js';
import {
  Product,
  Category,
  InventoryTransaction,
  OrderRequest,
  AnalyticsEvent,
  Shop,
  AuditLog,
} from '../src/models.js';

const config = readConfig({ DEMO_MODE: 'true', NODE_ENV: 'test' });
let api, close, merchant, second, admin, shop, foreignShop, products, categories;
const authorization = (token) => ({ Authorization: `Bearer ${token}` });
const customer = {
  name: 'Test Customer',
  phone: '+91 98765 43210',
  note: 'Morning pickup, please.',
};
async function newProduct(overrides = {}) {
  const response = await api
    .post('/api/merchant/products')
    .set(authorization(merchant))
    .send({
      name: 'Test wholesale item',
      sku: `TEST-${crypto.randomBytes(4).toString('hex')}`,
      category: categories[0]._id,
      price: 19.99,
      unit: 'box',
      stock: 10,
      minStock: 2,
      ...overrides,
    });
  assert.equal(response.status, 201, JSON.stringify(response.body));
  return response.body.product;
}
before(
  async () => {
    close = await connectDatabase(config);
    await seedDemo();
    api = request(createApp(config));
    const first = await api.post('/api/auth/demo').send({ account: 'merchant' });
    assert.equal(first.status, 200);
    merchant = first.body.token;
    shop = first.body.shop;
    const other = await api.post('/api/auth/demo').send({ account: 'merchant2' });
    second = other.body.token;
    foreignShop = other.body.shop;
    admin = (await api.post('/api/auth/demo').send({ account: 'super_admin' })).body.token;
    products = (await api.get('/api/merchant/products').set(authorization(merchant))).body.products;
    categories = (await api.get('/api/merchant/categories').set(authorization(merchant))).body
      .categories;
  },
  { timeout: 600000 },
);
after(async () => {
  if (close) await close();
});

test('demo cannot use production or persistent databases; live demo route is unavailable', async () => {
  assert.throws(() => readConfig({ NODE_ENV: 'production', DEMO_MODE: 'true' }), /forbidden/);
  assert.throws(
    () => readConfig({ DEMO_MODE: 'true', MONGODB_URI: 'mongodb://localhost/live' }),
    /disposable/,
  );
  assert.throws(
    () => readConfig({ MONGODB_URI: 'mongodb://localhost/live', JWT_SECRET: 'short' }),
    /32/,
  );
  assert.throws(
    () =>
      readConfig({
        NODE_ENV: 'production',
        MONGODB_URI: 'mongodb://localhost/live',
        JWT_SECRET: 'a'.repeat(40),
        GOOGLE_CLIENT_ID: 'id',
        CLIENT_ORIGINS: '*',
      }),
    /origins/,
  );
  const live = request(
    createApp({ ...config, demoMode: false, mongoUri: 'mongodb://localhost/live' }),
  );
  assert.equal((await live.post('/api/auth/demo').send({ account: 'super_admin' })).status, 404);
  assert.equal((await live.get('/api/platform/dashboard').set(authorization(admin))).status, 403);
});

test('authentication, database-backed roles, validation, and secure CORS are enforced', async () => {
  assert.equal((await api.get('/api/merchant/products')).status, 401);
  assert.equal(
    (await api.get('/api/merchant/products').set(authorization('forged-token'))).status,
    401,
  );
  assert.equal((await api.get('/api/platform/dashboard').set(authorization(merchant))).status, 403);
  assert.equal((await api.get('/api/merchant/products').set(authorization(admin))).status, 403);
  assert.equal(
    (await api.get('/api/merchant/products/not-an-id').set(authorization(merchant))).status,
    400,
  );
  assert.equal(
    (await api.get('/api/health').set('Origin', 'https://untrusted.example')).status,
    403,
  );
  const allowed = await api.get('/api/health').set('Origin', 'http://localhost:5173');
  assert.equal(allowed.headers['access-control-allow-origin'], 'http://localhost:5173');
  assert.equal(
    (
      await api
        .patch('/api/merchant/shop')
        .set(authorization(merchant))
        .send({ status: 'active', owner: 'forged' })
    ).status,
    400,
  );
});

test('merchant product, category, inventory, and reporting operations cannot cross tenant boundaries', async () => {
  const foreignProduct = (await api.get('/api/merchant/products').set(authorization(second))).body
    .products[0];
  const foreignCategory = (await api.get('/api/merchant/categories').set(authorization(second)))
    .body.categories[0];
  assert.equal(
    (await api.get(`/api/merchant/products/${foreignProduct._id}`).set(authorization(merchant)))
      .status,
    404,
  );
  assert.equal(
    (
      await api
        .patch(`/api/merchant/products/${foreignProduct._id}`)
        .set(authorization(merchant))
        .send({ price: 1 })
    ).status,
    404,
  );
  assert.equal(
    (await api.delete(`/api/merchant/products/${foreignProduct._id}`).set(authorization(merchant)))
      .status,
    404,
  );
  assert.equal(
    (
      await api
        .post('/api/merchant/inventory')
        .set(authorization(merchant))
        .send({ productId: foreignProduct._id, quantityChange: 1, reason: 'Spoofed update' })
    ).status,
    404,
  );
  assert.equal(
    (
      await api
        .patch(`/api/merchant/categories/${foreignCategory._id}`)
        .set(authorization(merchant))
        .send({ name: 'Spoofed' })
    ).status,
    404,
  );
  assert.equal(
    (
      await api
        .patch(`/api/merchant/products/${products[0]._id}`)
        .set(authorization(merchant))
        .send({ category: foreignCategory._id })
    ).status,
    400,
  );
  const mine = await api.get('/api/merchant/products').set(authorization(merchant));
  assert.ok(mine.body.products.every((product) => product.shop === shop._id));
  const history = await api.get('/api/merchant/inventory').set(authorization(merchant));
  assert.ok(history.body.transactions.every((row) => row.shop === shop._id));
  const orders = await api.get('/api/merchant/orders').set(authorization(second));
  assert.equal(orders.body.orders.length, 0);
  assert.equal(
    (await api.get(`/api/shops/${shop.slug}/products/${foreignProduct._id}`)).status,
    404,
  );
});

test('product partial edits preserve omitted stock/defaults and record intentional stock changes', async () => {
  const product = await newProduct({
    stock: 17,
    minStock: 4,
    description: 'Keep this description',
    active: false,
    images: ['/products/rice.svg'],
  });
  const updated = await api
    .patch(`/api/merchant/products/${product._id}`)
    .set(authorization(merchant))
    .send({ name: 'Renamed item' });
  assert.equal(updated.status, 200);
  assert.equal(updated.body.product.stock, 17);
  assert.equal(updated.body.product.minStock, 4);
  assert.equal(updated.body.product.active, false);
  assert.equal(updated.body.product.description, 'Keep this description');
  assert.deepEqual(updated.body.product.images, ['/products/rice.svg']);
  await api
    .patch(`/api/merchant/products/${product._id}`)
    .set(authorization(merchant))
    .send({ stock: 12 });
  const history = await InventoryTransaction.find({ product: product._id }).sort({ createdAt: 1 });
  assert.equal(history.length, 2);
  assert.equal(history[1].quantityChange, -5);
  assert.equal(history[1].stockBefore, 17);
  assert.equal(history[1].stockAfter, 12);
});

test('concurrent inventory reductions stay nonnegative and history commits atomically', async () => {
  const product = await newProduct({ stock: 3 });
  const results = await Promise.all(
    [1, 2].map(() =>
      api
        .post('/api/merchant/inventory')
        .set(authorization(merchant))
        .send({ productId: product._id, quantityChange: -2, reason: 'Wholesale dispatch' }),
    ),
  );
  assert.deepEqual(results.map((result) => result.status).sort(), [201, 409]);
  assert.equal((await Product.findById(product._id)).stock, 1);
  assert.equal(await InventoryTransaction.countDocuments({ product: product._id }), 2);
  const original = InventoryTransaction.create;
  InventoryTransaction.create = async () => {
    throw new Error('Simulated inventory audit failure');
  };
  try {
    const failed = await api
      .post('/api/merchant/inventory')
      .set(authorization(merchant))
      .send({ productId: product._id, quantityChange: 10, reason: 'Rollback verification' });
    assert.equal(failed.status, 500);
    assert.equal((await Product.findById(product._id)).stock, 1);
    assert.ok(!JSON.stringify(failed.body).includes('Simulated'));
  } finally {
    InventoryTransaction.create = original;
  }
});

test('checkout aggregates duplicates, uses exact server prices, keeps stock, and is idempotent', async () => {
  const product = await newProduct({ stock: 10 });
  const key = crypto.randomUUID();
  const body = {
    customer,
    items: [
      { productId: product._id, quantity: 1 },
      { productId: product._id, quantity: 2 },
    ],
  };
  const before = await AnalyticsEvent.countDocuments({ shop: shop._id, type: 'whatsapp_checkout' });
  const first = await api
    .post(`/api/shops/${shop.slug}/checkout`)
    .set('Idempotency-Key', key)
    .send(body);
  assert.equal(first.status, 201, JSON.stringify(first.body));
  assert.equal(first.body.order.items.length, 1);
  assert.equal(first.body.order.items[0].quantity, 3);
  assert.equal(first.body.order.totalPaise, 5997);
  assert.equal(first.body.order.total, 59.97);
  assert.match(first.body.message, /Greenfield Wholesale/);
  assert.match(first.body.message, /Test Customer/);
  assert.match(first.body.message, /Morning pickup/);
  assert.match(first.body.whatsappUrl, /^https:\/\/wa\.me\/919000000000\?text=/);
  assert.equal(first.body.order.requestHash, undefined);
  assert.equal((await Product.findById(product._id)).stock, 10);
  const replay = await api
    .post(`/api/shops/${shop.slug}/checkout`)
    .set('Idempotency-Key', key)
    .send(body);
  assert.equal(replay.status, 200);
  assert.equal(replay.body.order._id, first.body.order._id);
  assert.equal(await OrderRequest.countDocuments({ idempotencyKey: key }), 1);
  assert.equal(
    await AnalyticsEvent.countDocuments({ shop: shop._id, type: 'whatsapp_checkout' }),
    before + 1,
  );
  assert.equal(
    (
      await api
        .post(`/api/shops/${shop.slug}/checkout`)
        .set('Idempotency-Key', key)
        .send({ ...body, customer: { ...customer, name: 'Different customer' } })
    ).status,
    409,
  );
  assert.equal(
    (
      await api.post(`/api/shops/${shop.slug}/checkout`).send({
        customer,
        items: [
          { productId: product._id, quantity: 6 },
          { productId: product._id, quantity: 6 },
        ],
      })
    ).status,
    409,
  );
  assert.equal(
    (
      await api
        .post(`/api/shops/${shop.slug}/checkout`)
        .send({ customer, items: [{ productId: product._id, quantity: 1, price: 0.01 }] })
    ).status,
    400,
  );
  const concurrentKey = crypto.randomUUID();
  const concurrent = await Promise.all(
    [1, 2].map(() =>
      api.post(`/api/shops/${shop.slug}/checkout`).set('Idempotency-Key', concurrentKey).send(body),
    ),
  );
  assert.deepEqual(concurrent.map((result) => result.status).sort(), [200, 201]);
  assert.equal(concurrent[0].body.order._id, concurrent[1].body.order._id);
  assert.equal(await OrderRequest.countDocuments({ idempotencyKey: concurrentKey }), 1);
});

test('inactive, foreign, out-of-stock, and fractional items cannot be ordered or used to forge checkout analytics', async () => {
  const inactive = await newProduct({ active: false });
  const soldOut = await newProduct({ stock: 0 });
  const foreign = await Product.findOne({ shop: foreignShop._id });
  for (const product of [inactive, soldOut, foreign]) {
    const response = await api
      .post(`/api/shops/${shop.slug}/checkout`)
      .send({ customer, items: [{ productId: String(product._id), quantity: 1 }] });
    assert.equal(response.status, 409);
  }
  assert.equal(
    (
      await api
        .post(`/api/shops/${shop.slug}/checkout`)
        .send({ customer, items: [{ productId: products[0]._id, quantity: 1.5 }] })
    ).status,
    400,
  );
  assert.equal(
    (
      await api
        .post(`/api/shops/${shop.slug}/events`)
        .send({ type: 'whatsapp_checkout', productId: products[0]._id })
    ).status,
    400,
  );
  const category = await Category.create({
    shop: shop._id,
    name: 'Hidden',
    slug: 'hidden',
    active: false,
  });
  const hidden = await newProduct({ category: String(category._id) });
  assert.equal((await api.get(`/api/shops/${shop.slug}/products/${hidden._id}`)).status, 404);
  const list = await api.get(`/api/shops/${shop.slug}/products?category=${category._id}`);
  assert.equal(list.body.products.length, 0);
  assert.equal(
    (
      await api
        .post(`/api/shops/${shop.slug}/checkout`)
        .send({ customer, items: [{ productId: hidden._id, quantity: 1 }] })
    ).status,
    409,
  );
});

test('suspension and audit are atomic, access is blocked, and reactivation restores the shop', async () => {
  const original = AuditLog.create;
  AuditLog.create = async () => {
    throw new Error('Simulated platform audit failure');
  };
  try {
    const failed = await api
      .patch(`/api/platform/shops/${shop._id}/status`)
      .set(authorization(admin))
      .send({ status: 'suspended', reason: 'Rollback test' });
    assert.equal(failed.status, 500);
    assert.equal((await Shop.findById(shop._id)).status, 'active');
  } finally {
    AuditLog.create = original;
  }
  const suspended = await api
    .patch(`/api/platform/shops/${shop._id}/status`)
    .set(authorization(admin))
    .send({ status: 'suspended', reason: 'Verification requested' });
  assert.equal(suspended.status, 200);
  assert.equal(suspended.body.shop.suspensionReason, 'Verification requested');
  assert.ok(suspended.body.shop.suspendedAt);
  const publicResponse = await api.get(`/api/shops/${shop.slug}`);
  assert.equal(publicResponse.status, 423);
  assert.equal(publicResponse.body.message, 'Shop temporarily unavailable');
  assert.equal(publicResponse.body.code, 'SHOP_SUSPENDED');
  assert.equal((await api.get('/api/merchant/dashboard').set(authorization(merchant))).status, 423);
  assert.equal((await api.get('/api/merchant/products').set(authorization(merchant))).status, 423);
  assert.equal((await api.get('/api/merchant/shop').set(authorization(merchant))).status, 200);
  assert.equal((await api.get('/api/auth/me').set(authorization(merchant))).status, 200);
  assert.equal((await api.get(`/api/shops/${foreignShop.slug}`)).status, 200);
  assert.equal(
    (
      await api
        .patch('/api/merchant/shop')
        .set(authorization(merchant))
        .send({ name: 'Blocked edit' })
    ).status,
    423,
  );
  const log = await AuditLog.findOne({ targetShop: shop._id, action: 'shop_suspended' });
  assert.equal(log.reason, 'Verification requested');
  assert.equal(log.metadata.previousStatus, 'active');
  const restored = await api
    .patch(`/api/platform/shops/${shop._id}/status`)
    .set(authorization(admin))
    .send({ status: 'active', reason: 'Verification completed' });
  assert.equal(restored.status, 200);
  assert.equal(restored.body.shop.suspendedAt, null);
  assert.equal((await api.get(`/api/shops/${shop.slug}`)).status, 200);
});

test('dashboard, platform search, details, and audit expose the agreed response shapes', async () => {
  const dashboard = await api.get('/api/merchant/analytics?days=7').set(authorization(merchant));
  assert.equal(dashboard.status, 200);
  assert.equal(dashboard.body.series.length, 7);
  assert.ok(dashboard.body.stats.productViews > 0);
  assert.ok(dashboard.body.lowStockProducts.some((product) => product.stock === 0));
  assert.equal(
    dashboard.body.lowStockProducts.length,
    dashboard.body.stats.lowStock + dashboard.body.stats.outOfStock,
  );
  assert.ok(Array.isArray(dashboard.body.mostRequested));
  const platform = await api.get('/api/platform/dashboard').set(authorization(admin));
  assert.equal(platform.body.stats.totalMerchants, 2);
  assert.equal(platform.body.stats.totalShops, 2);
  const search = await api
    .get('/api/platform/shops?search=meera@example.test')
    .set(authorization(admin));
  assert.equal(search.body.shops.length, 1);
  assert.equal(search.body.shops[0].owner.email, 'meera@example.test');
  const detail = await api.get(`/api/platform/shops/${shop._id}`).set(authorization(admin));
  assert.equal(detail.body.owner.email, 'aarav@example.test');
  assert.ok(detail.body.stats.checkoutRequests > 0);
  const audit = await api.get('/api/platform/audit').set(authorization(admin));
  assert.ok(
    audit.body.logs.some(
      (log) => log.action === 'shop_reactivated' && log.performedBy.email === 'admin@example.test',
    ),
  );
});

test('login attempts are rate limited with a useful error response', async () => {
  let response;
  for (let attempt = 0; attempt < 41; attempt++) {
    response = await api.post('/api/auth/demo').send({ account: 'merchant' });
    if (response.status === 429) break;
  }
  assert.equal(response.status, 429);
  assert.match(response.body.message, /Too many login attempts/);
  assert.ok(response.headers['retry-after']);
});
