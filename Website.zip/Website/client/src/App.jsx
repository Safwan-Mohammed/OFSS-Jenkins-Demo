import { lazy, Suspense } from 'react';
import { Navigate, Outlet, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import { EmptyState, Loading } from './components/ui';
import Login from './pages/Login';
const Dashboard = lazy(() => import('./pages/merchant/Dashboard'));
import { Products, ProductForm } from './pages/merchant/Products';
import Categories from './pages/merchant/Categories';
import Inventory from './pages/merchant/Inventory';
import Orders from './pages/merchant/Orders';
import Settings from './pages/merchant/Settings';
const Storefront = lazy(() => import('./pages/storefront/Storefront'));
const Platform = lazy(() => import('./pages/platform/Platform'));

function Protected({ role }) {
  const { user, loading } = useAuth();
  if (loading) return <Loading />;
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== role)
    return <Navigate to={user.role === 'super_admin' ? '/platform' : '/dashboard'} replace />;
  return <Outlet />;
}
function Home() {
  const { user, loading } = useAuth();
  if (loading) return <Loading />;
  return (
    <Navigate
      to={!user ? '/login' : user.role === 'super_admin' ? '/platform' : '/dashboard'}
      replace
    />
  );
}
export default function App() {
  return (
    <Suspense fallback={<Loading />}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/shop/:slug/*" element={<Storefront />} />
        <Route element={<Protected role="merchant_admin" />}>
          <Route element={<Layout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/products" element={<Products />} />
            <Route path="/products/new" element={<ProductForm />} />
            <Route path="/products/:id/edit" element={<ProductForm />} />
            <Route path="/categories" element={<Categories />} />
            <Route path="/inventory" element={<Inventory />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/analytics" element={<Dashboard analytics />} />
            <Route path="/settings" element={<Settings />} />
          </Route>
        </Route>
        <Route element={<Protected role="super_admin" />}>
          <Route element={<Layout />}>
            <Route path="/platform/*" element={<Platform />} />
          </Route>
        </Route>
        <Route
          path="*"
          element={
            <div className="not-found">
              <EmptyState
                title="This page took a wrong turn"
                description="The page you’re looking for doesn’t exist."
              >
                <a className="button button-primary" href="/">
                  Back to your workspace
                </a>
              </EmptyState>
            </div>
          }
        />
      </Routes>
    </Suspense>
  );
}
