import { createContext, useContext, useEffect, useState } from 'react';
import { api, TOKEN_KEY } from '../lib/api';

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [config, setConfig] = useState({ demoMode: false });
  const [configError, setConfigError] = useState(null);
  useEffect(() => {
    api('/auth/config').then(setConfig).catch(setConfigError);
    if (sessionStorage.getItem(TOKEN_KEY))
      api('/auth/me')
        .then(setSession)
        .catch(() => sessionStorage.removeItem(TOKEN_KEY))
        .finally(() => setLoading(false));
    else setLoading(false);
    const expire = () => {
      sessionStorage.removeItem(TOKEN_KEY);
      setSession(null);
    };
    window.addEventListener('session-expired', expire);
    return () => window.removeEventListener('session-expired', expire);
  }, []);
  const login = async (type, body) => {
    const result = await api(`/auth/${type}`, { method: 'POST', body });
    sessionStorage.setItem(TOKEN_KEY, result.token);
    setSession({ user: result.user, shop: result.shop });
    return result;
  };
  const logout = () => {
    sessionStorage.removeItem(TOKEN_KEY);
    setSession(null);
  };
  const refresh = async () => {
    const result = await api('/auth/me');
    setSession(result);
    return result;
  };
  return (
    <AuthContext.Provider
      value={{ ...session, loading, config, configError, login, logout, refresh }}
    >
      {children}
    </AuthContext.Provider>
  );
}
export const useAuth = () => useContext(AuthContext);
