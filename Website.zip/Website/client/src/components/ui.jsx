import { useEffect, useId, useRef } from 'react';
import { AlertCircle, CheckCircle2, LoaderCircle, PackageOpen, X } from 'lucide-react';

export function PageHeading({ title, description, children }) {
  return (
    <div className="page-heading">
      <div>
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      {children && <div className="heading-actions">{children}</div>}
    </div>
  );
}
export function StatCard({ label, value, icon: Icon, note, accent = '' }) {
  return (
    <div className={`stat-card ${accent}`}>
      <div className="stat-top">
        <span>{label}</span>
        {Icon && (
          <span className="stat-icon">
            <Icon size={18} />
          </span>
        )}
      </div>
      <strong>{value ?? '—'}</strong>
      {note && <span className="stat-note">{note}</span>}
    </div>
  );
}
export function StatusBadge({ status }) {
  const name = String(status ?? 'active');
  return (
    <span className={`status-badge status-${name.toLowerCase().replaceAll(' ', '-')}`}>
      <span />
      {name.replaceAll('_', ' ').replace(/^\w/, (s) => s.toUpperCase())}
    </span>
  );
}
export function EmptyState({ title = 'Nothing here yet', description, children }) {
  return (
    <div className="empty-state">
      <PackageOpen size={38} strokeWidth={1.4} />
      <h3>{title}</h3>
      {description && <p>{description}</p>}
      {children}
    </div>
  );
}
export function Loading() {
  return (
    <div className="loading" role="status">
      <LoaderCircle className="spin" size={24} />
      Loading your workspace…
    </div>
  );
}
export function ErrorState({ error, onRetry }) {
  return (
    <div className="error-state" role="alert">
      <AlertCircle size={24} />
      <div>
        <h3>We couldn’t load this page</h3>
        <p>{error?.message || 'Please try again.'}</p>
      </div>
      {onRetry && (
        <button className="button button-secondary" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}
export function Notice({ children, type = 'success' }) {
  return children ? (
    <div role={type === 'error' ? 'alert' : 'status'} className={`notice notice-${type}`}>
      {type === 'error' ? <AlertCircle size={18} /> : <CheckCircle2 size={18} />}
      <span>{children}</span>
    </div>
  ) : null;
}
export function Modal({ open, title, onClose, children }) {
  const ref = useRef(null);
  const id = useId();
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement;
    ref.current?.focus();
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const keydown = (event) => {
      if (event.key === 'Escape') closeRef.current();
      if (event.key !== 'Tab') return;
      const nodes = ref.current?.querySelectorAll(
        'button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]',
      );
      if (!nodes?.length) {
        event.preventDefault();
        return;
      }
      const first = nodes[0],
        last = nodes[nodes.length - 1];
      if (
        event.shiftKey &&
        (document.activeElement === first || document.activeElement === ref.current)
      ) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', keydown);
    return () => {
      document.body.style.overflow = oldOverflow;
      document.removeEventListener('keydown', keydown);
      previous?.focus();
    };
  }, [open]);
  if (!open) return null;
  return (
    <div
      className="modal-overlay"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby={id}
        tabIndex={-1}
        ref={ref}
      >
        <div className="modal-heading">
          <h2 id={id}>{title}</h2>
          <button type="button" className="icon-button" aria-label="Close dialog" onClick={onClose}>
            <X size={20} />
          </button>
        </div>
        {children}
      </section>
    </div>
  );
}
export function ProductImage({ product, className = '' }) {
  return (
    <img
      className={`product-image ${className}`}
      src={product?.images?.[0] || '/placeholder.svg'}
      alt={product?.name || 'Product'}
      onError={(e) => {
        e.currentTarget.onerror = null;
        e.currentTarget.src = '/placeholder.svg';
      }}
    />
  );
}
