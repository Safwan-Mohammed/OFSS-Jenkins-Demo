import { useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  ArrowUpRight,
  BarChart3,
  Bell,
  ChevronDown,
  ChevronsUpDown,
  CircleHelp,
  ClipboardList,
  ExternalLink,
  FolderOpen,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  Search,
  Settings2,
  ShieldCheck,
  ShoppingBag,
  Store,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Modal } from './ui';

const merchantLinks = [
  ['/dashboard', 'Overview', LayoutDashboard],
  ['/products', 'Products', Package],
  ['/categories', 'Categories', FolderOpen],
  ['/inventory', 'Inventory', ClipboardList],
  ['/orders', 'Order requests', ShoppingBag],
  ['/analytics', 'Analytics', BarChart3],
];
const platformLinks = [
  ['/platform', 'Overview', LayoutDashboard],
  ['/platform/shops', 'Merchants & shops', Store],
  ['/platform/audit', 'Audit logs', ShieldCheck],
];
export function Brand({ light = false }) {
  return (
    <span className={`brand ${light ? 'brand-light' : ''}`}>
      <span className="brand-symbol">
        <Package size={23} strokeWidth={1.7} />
      </span>
      <span>
        supplylane<span className="brand-period">.</span>
      </span>
    </span>
  );
}

export default function Layout() {
  const { user, shop, config, logout } = useAuth();
  const location = useLocation();
  const [mobile, setMobile] = useState(false);
  const [help, setHelp] = useState(false);
  const platform = user?.role === 'super_admin';
  const links = platform ? platformLinks : merchantLinks;
  const current =
    [...links, ['/settings', 'Shop settings']].find(
      ([path]) =>
        location.pathname === path ||
        (path !== '/platform' && location.pathname.startsWith(path + '/')),
    )?.[1] || 'Workspace';
  return (
    <div className="app-shell">
      {mobile && (
        <button
          className="sidebar-scrim"
          aria-label="Close navigation"
          onClick={() => setMobile(false)}
        />
      )}
      <aside className={`sidebar ${mobile ? 'is-open' : ''}`}>
        <Link to={platform ? '/platform' : '/dashboard'} className="brand-link">
          <Brand />
        </Link>
        <div className="workspace-card">
          <div className="shop-monogram">
            {platform ? <ShieldCheck size={21} /> : shop?.name?.[0] || 'S'}
          </div>
          <div>
            <strong>{platform ? 'Platform workspace' : shop?.name || 'Your wholesale shop'}</strong>
            <span>{platform ? 'Super administrator' : 'Merchant workspace'}</span>
          </div>
          <ChevronsUpDown size={15} />
        </div>
        <div className="nav-label">WORKSPACE</div>
        <nav className="main-nav">
          {links.map(([to, label, Icon]) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/platform'}
              onClick={() => setMobile(false)}
              className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
            >
              <Icon size={19} />
              <span>{label}</span>
              {label === 'Products' && <span className="nav-dot" />}
            </NavLink>
          ))}
        </nav>
        {!platform && (
          <>
            <div className="nav-label nav-label-second">MANAGE</div>
            <nav className="main-nav">
              <NavLink
                to="/settings"
                className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
                onClick={() => setMobile(false)}
              >
                <Settings2 size={19} />
                <span>Shop settings</span>
              </NavLink>
              <Link className="nav-link" target="_blank" to={`/shop/${shop?.slug}`}>
                <ExternalLink size={18} />
                <span>View storefront</span>
                <ArrowUpRight size={14} />
              </Link>
            </nav>
          </>
        )}
        <div className="sidebar-bottom">
          {!platform && (
            <div className="sidebar-tip">
              <div className="tip-icon">
                <Store size={18} />
              </div>
              <strong>Your shop, always open.</strong>
              <p>Share your catalog and let the orders come to you.</p>
              <Link to={`/shop/${shop?.slug}`} target="_blank">
                Visit your storefront <ArrowUpRight size={15} />
              </Link>
            </div>
          )}
          <button className="nav-link help-link" onClick={() => setHelp(true)}>
            <CircleHelp size={18} />
            <span>Help & getting started</span>
          </button>
          <div className="profile">
            <div className="avatar">
              {user?.name
                ?.split(' ')
                .map((x) => x[0])
                .slice(0, 2)
                .join('') || 'AS'}
            </div>
            <div>
              <strong>{user?.name}</strong>
              <span>{platform ? 'Platform owner' : 'Shop owner'}</span>
            </div>
            <button className="icon-button" onClick={logout} title="Sign out" aria-label="Sign out">
              <LogOut size={17} />
            </button>
          </div>
        </div>
      </aside>
      <div className="workspace-main">
        <header className="topbar">
          <div className="breadcrumb">
            <button
              className="icon-button mobile-menu"
              aria-label="Open navigation"
              onClick={() => setMobile(true)}
            >
              <Menu size={21} />
            </button>
            <span>{platform ? 'Platform' : 'Workspace'}</span>
            <span className="breadcrumb-slash">/</span>
            <strong>{current}</strong>
          </div>
          <div className="topbar-right">
            {config.demoMode && (
              <span className="demo-indicator">
                <span />
                Local demo
              </span>
            )}
            <button
              className="icon-button"
              onClick={() => setHelp(true)}
              aria-label="Workspace help"
            >
              <CircleHelp size={19} />
            </button>
            <span className="topbar-divider" />
            <div className="avatar avatar-small">{user?.name?.[0] || 'A'}</div>
          </div>
        </header>
        {shop?.status === 'suspended' ? (
          <main className="page-content">
            <div className="suspended-panel">
              <ShieldCheck size={42} />
              <h1>Your shop is temporarily suspended</h1>
              <p>{shop.suspensionReason || 'Please contact your platform administrator.'}</p>
              <p>Your public catalog is unavailable until your account is reactivated.</p>
              <button className="button button-secondary" onClick={() => window.location.reload()}>
                Check account status
              </button>
            </div>
          </main>
        ) : (
          <main className="page-content">
            <Outlet />
          </main>
        )}
        <footer className="workspace-footer">
          <span>Made for the way wholesale works.</span>
          <span>
            SupplyLane <span className="footer-dot">•</span>{' '}
            {config.demoMode ? 'Demo workspace' : 'Merchant workspace'}
          </span>
        </footer>
      </div>
      <Modal open={help} title="Welcome to your workspace" onClose={() => setHelp(false)}>
        <div className="help-content">
          <p>Bring your wholesale business online in a few simple steps.</p>
          <ol>
            <li>
              <strong>Make it yours.</strong> Add your shop details and a valid WhatsApp number in
              Shop settings.
            </li>
            <li>
              <strong>Build your catalog.</strong> Create categories, add products, and set your
              stock quantities.
            </li>
            <li>
              <strong>Share your storefront.</strong> Customers browse without an account and send
              requests to WhatsApp.
            </li>
            <li>
              <strong>Keep stock up to date.</strong> Record inventory adjustments after confirming
              each order.
            </li>
          </ol>
          {config.demoMode && (
            <div className="notice">
              This is a disposable local demo. Sample activity is seeded, changes reset when the API
              restarts, and the WhatsApp number is a placeholder.
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
}
