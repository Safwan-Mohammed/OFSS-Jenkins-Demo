import { useCallback, useEffect, useState } from 'react';
import { Link, Route, Routes, useParams } from 'react-router-dom';
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  ClipboardList,
  ExternalLink,
  Mail,
  MapPin,
  Package,
  Search,
  ShieldCheck,
  ShoppingBag,
  Store,
  Users,
  XCircle,
} from 'lucide-react';
import { api, money, formatDate } from '../../lib/api';
import {
  PageHeading,
  StatCard,
  StatusBadge,
  EmptyState,
  Modal,
  Loading,
  ErrorState,
} from '../../components/ui';
import './platform.css';

function useResource(path) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [revision, setRevision] = useState(0);
  const refresh = useCallback(() => setRevision((value) => value + 1), []);

  useEffect(() => {
    let current = true;
    setLoading(true);
    setError(null);
    api(path)
      .then((result) => {
        if (current) setData(result);
      })
      .catch((err) => {
        if (current) setError(err);
      })
      .finally(() => {
        if (current) setLoading(false);
      });
    return () => {
      current = false;
    };
  }, [path, revision]);

  return { data, error, loading, refresh };
}

function formatAction(action) {
  return String(action || 'Platform action')
    .replace(/[_.-]/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function ShopIdentity({ shop, showOwner = true }) {
  return (
    <div className="platform-identity">
      <div className="platform-avatar" aria-hidden="true">
        {shop.logo ? <img src={shop.logo} alt="" /> : <Store size={19} />}
      </div>
      <div>
        <Link className="platform-name" to={`/platform/shops/${shop._id}`}>
          {shop.name}
        </Link>
        <div className="platform-subtext">
          {showOwner ? shop.owner?.name || shop.owner?.email || shop.slug : `/${shop.slug}`}
        </div>
      </div>
    </div>
  );
}

function ShopsTable({ shops = [] }) {
  if (!shops.length)
    return (
      <EmptyState
        title="No shops found"
        description="Registered shops will appear here. Try a different search if you applied a filter."
      />
    );
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            <th>Shop / merchant</th>
            <th>Contact</th>
            <th>Status</th>
            <th>Joined</th>
            <th>
              <span className="platform-sr-only">Open shop</span>
            </th>
          </tr>
        </thead>
        <tbody>
          {shops.map((shop) => (
            <tr key={shop._id}>
              <td>
                <ShopIdentity shop={shop} />
              </td>
              <td>
                <span>{shop.owner?.email || shop.phone || '—'}</span>
              </td>
              <td>
                <StatusBadge status={shop.status} />
              </td>
              <td className="muted">{shop.createdAt ? formatDate(shop.createdAt) : '—'}</td>
              <td>
                <Link
                  className="platform-arrow-link"
                  to={`/platform/shops/${shop._id}`}
                  aria-label={`View ${shop.name}`}
                >
                  <ArrowRight size={17} />
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AuditTable({ logs = [] }) {
  if (!logs.length)
    return (
      <EmptyState
        title="No platform actions yet"
        description="Shop suspensions and reactivations are recorded here with the administrator and reason."
      />
    );
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            <th>Action</th>
            <th>Shop</th>
            <th>Administrator</th>
            <th>Reason</th>
            <th>Date & time</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log) => (
            <tr key={log._id}>
              <td>
                <span className="platform-action">
                  <span
                    className={`platform-action-dot ${String(log.action).includes('suspend') ? 'is-warning' : ''}`}
                  />
                  {formatAction(log.action)}
                </span>
              </td>
              <td>
                {log.targetShop?._id ? (
                  <Link className="platform-name" to={`/platform/shops/${log.targetShop._id}`}>
                    {log.targetShop.name}
                  </Link>
                ) : (
                  log.targetShop?.name || log.metadata?.shopName || '—'
                )}
              </td>
              <td>
                <div>{log.performedBy?.name || 'Administrator'}</div>
                <div className="platform-subtext">{log.performedBy?.email || '—'}</div>
              </td>
              <td className="platform-reason-cell">{log.reason || '—'}</td>
              <td className="muted platform-date-cell">
                {log.createdAt || log.timestamp ? formatDate(log.createdAt || log.timestamp) : '—'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Dashboard() {
  const { data, error, loading, refresh } = useResource('/platform/dashboard');
  if (loading) return <Loading />;
  if (error) return <ErrorState error={error} onRetry={refresh} />;
  const { stats = {}, shops = [], recentActivity = [] } = data || {};
  return (
    <div className="page-stack platform-page">
      <PageHeading
        title="Platform overview"
        description="A clear view of your merchants, shops, and platform activity."
      >
        <Link className="button button-primary" to="/platform/shops">
          <Store size={16} /> Manage shops
        </Link>
      </PageHeading>
      <div className="platform-role-note">
        <ShieldCheck size={17} />
        <span>Platform administration</span>
        <span className="platform-note-divider" />
        <span>Account changes are recorded in the audit log.</span>
      </div>
      <div className="stats-grid">
        <StatCard
          label="Total merchants"
          value={stats.totalMerchants ?? 0}
          icon={Users}
          note="Registered merchant accounts"
        />
        <StatCard
          label="Total shops"
          value={stats.totalShops ?? 0}
          icon={Store}
          note={`${stats.activeShops ?? 0} active shops`}
        />
        <StatCard
          label="Catalog products"
          value={stats.totalProducts ?? 0}
          icon={Package}
          note="Across all merchant catalogs"
        />
        <StatCard
          label="Order requests"
          value={stats.totalRequests ?? 0}
          icon={ShoppingBag}
          note="WhatsApp checkout requests"
        />
      </div>
      <section className="panel">
        <div className="platform-panel-heading">
          <div>
            <h2>Merchant shops</h2>
            <p className="muted">Your most recently registered shops.</p>
          </div>
          <Link className="platform-text-link" to="/platform/shops">
            View all shops <ArrowRight size={15} />
          </Link>
        </div>
        <ShopsTable shops={shops.slice(0, 5)} />
      </section>
      <div className="platform-bottom-grid">
        <section className="panel platform-health-panel">
          <div className="platform-panel-heading">
            <div>
              <h2>Shop account status</h2>
              <p className="muted">Availability across the platform.</p>
            </div>
            <Activity size={19} className="muted" />
          </div>
          <div className="platform-health-row">
            <span>
              <span className="platform-status-icon is-active">
                <CheckCircle2 size={19} />
              </span>
              Active shops
            </span>
            <strong>{stats.activeShops ?? 0}</strong>
          </div>
          <div className="platform-health-row">
            <span>
              <span className="platform-status-icon is-suspended">
                <XCircle size={19} />
              </span>
              Temporarily suspended
            </span>
            <strong>{stats.suspendedShops ?? 0}</strong>
          </div>
          <p className="platform-health-note">
            Suspended shops cannot accept order requests. Reactivate a shop from its account detail
            page.
          </p>
        </section>
        <section className="panel">
          <div className="platform-panel-heading">
            <div>
              <h2>Recent account activity</h2>
              <p className="muted">The latest administrative changes.</p>
            </div>
            <Link className="platform-text-link" to="/platform/audit">
              Audit log <ArrowRight size={15} />
            </Link>
          </div>
          {recentActivity.length ? (
            <div className="platform-activity-list">
              {recentActivity.slice(0, 4).map((log) => (
                <div className="platform-activity-item" key={log._id}>
                  <span className="platform-activity-icon">
                    <ClipboardList size={17} />
                  </span>
                  <div>
                    <strong>{formatAction(log.action)}</strong>
                    <p>
                      {log.targetShop?.name || log.metadata?.shopName || 'Merchant shop'} ·{' '}
                      {log.performedBy?.name || 'Administrator'}
                    </p>
                    <p className="muted">{formatDate(log.createdAt || log.timestamp)}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="platform-inline-empty">
              <ShieldCheck size={26} />
              <p>No account changes yet.</p>
              <span>Administrative actions will appear here.</span>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

function Shops() {
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  useEffect(() => {
    const timer = setTimeout(() => setQuery(search.trim()), 250);
    return () => clearTimeout(timer);
  }, [search]);
  const { data, error, loading, refresh } = useResource(
    `/platform/shops?search=${encodeURIComponent(query)}`,
  );
  return (
    <div className="page-stack platform-page">
      <PageHeading
        title="Merchants & shops"
        description="Search merchant accounts, review catalogs, and manage shop availability."
      />
      <section className="panel">
        <div className="platform-panel-heading">
          <div>
            <h2>All shops</h2>
            <p className="muted">
              {loading
                ? 'Loading shops…'
                : `${data?.shops?.length || 0} ${query ? 'matching' : 'registered'} shops`}
            </p>
          </div>
          <label className="platform-search">
            <Search size={17} />
            <input
              className="input"
              aria-label="Search shops and merchants"
              placeholder="Search name, merchant, or email…"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </label>
        </div>
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={refresh} />
        ) : (
          <ShopsTable shops={data?.shops} />
        )}
      </section>
    </div>
  );
}

function DetailField({ label, children }) {
  return (
    <div className="platform-detail-field">
      <dt>{label}</dt>
      <dd>{children || '—'}</dd>
    </div>
  );
}

function ProductRanking({ title, description, entries = [], unit }) {
  return (
    <section className="panel">
      <div className="platform-panel-heading">
        <div>
          <h2>{title}</h2>
          <p className="muted">{description}</p>
        </div>
      </div>
      {entries.length ? (
        <ol className="platform-ranking">
          {entries.map((entry, index) => (
            <li key={entry.product?._id || index}>
              <span className="platform-ranking-number">{index + 1}</span>
              <span className="platform-ranking-name">{entry.product?.name || 'Product'}</span>
              <strong>
                {entry.count ?? 0}
                <small>{unit}</small>
              </strong>
            </li>
          ))}
        </ol>
      ) : (
        <div className="platform-ranking-empty">No product activity in this period.</div>
      )}
    </section>
  );
}

function ShopDetail() {
  const { id } = useParams();
  const { data, error, loading, refresh } = useResource(
    `/platform/shops/${encodeURIComponent(id)}`,
  );
  const [action, setAction] = useState(null);
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [notice, setNotice] = useState('');
  if (loading) return <Loading />;
  if (error) return <ErrorState error={error} onRetry={refresh} />;
  const { shop, products = [], stats = {}, owner, analytics } = data || {};
  if (!shop)
    return <EmptyState title="Shop not found" description="This shop is no longer available." />;
  const merchant = owner || shop.owner || {};
  const openAction = (status) => {
    setAction(status);
    setReason('');
    setSaveError('');
  };
  const closeAction = () => {
    if (!saving) setAction(null);
  };
  const submitStatus = async (event) => {
    event.preventDefault();
    if (!reason.trim()) {
      setSaveError('Please enter a reason for this account change.');
      return;
    }
    setSaving(true);
    setSaveError('');
    try {
      await api(`/platform/shops/${encodeURIComponent(id)}/status`, {
        method: 'PATCH',
        body: { status: action, reason: reason.trim() },
      });
      setNotice(
        action === 'suspended'
          ? 'Shop suspended. The account change has been recorded in the audit log.'
          : 'Shop reactivated. The account change has been recorded in the audit log.',
      );
      setAction(null);
      refresh();
    } catch (err) {
      setSaveError(err.message || 'We could not update the shop status. Please try again.');
    } finally {
      setSaving(false);
    }
  };
  return (
    <div className="page-stack platform-page">
      <Link className="platform-back-link" to="/platform/shops">
        <ArrowLeft size={16} /> All merchants & shops
      </Link>
      <PageHeading title={shop.name} description={`Shop account · /${shop.slug}`}>
        <Link
          className="button button-secondary"
          target="_blank"
          rel="noopener noreferrer"
          to={`/shop/${shop.slug}`}
        >
          <ExternalLink size={16} /> View storefront
        </Link>
      </PageHeading>
      {notice && (
        <div className="platform-notice" role="status">
          <CheckCircle2 size={18} />
          {notice}
        </div>
      )}
      <section
        className={`panel platform-account-panel ${shop.status === 'suspended' ? 'is-suspended' : ''}`}
      >
        <div className="platform-account-summary">
          <span className="platform-account-icon">
            <ShieldCheck size={24} />
          </span>
          <div>
            <div className="platform-account-title">
              <h2>Shop account status</h2>
              <StatusBadge status={shop.status} />
            </div>
            <p>
              {shop.status === 'suspended'
                ? 'This shop is temporarily unavailable to customers.'
                : 'This shop is active and available to customers.'}
            </p>
            {shop.status === 'suspended' && (
              <p className="platform-suspension-reason">
                <strong>Reason:</strong> {shop.suspensionReason || 'No reason recorded.'}
                {shop.suspendedAt && <span> · {formatDate(shop.suspendedAt)}</span>}
              </p>
            )}
          </div>
        </div>
        <button
          className={`button ${shop.status === 'suspended' ? 'button-primary' : 'button-danger'}`}
          onClick={() => openAction(shop.status === 'suspended' ? 'active' : 'suspended')}
        >
          {shop.status === 'suspended' ? (
            <>
              <CheckCircle2 size={16} /> Reactivate shop
            </>
          ) : (
            <>
              <XCircle size={16} /> Suspend shop
            </>
          )}
        </button>
      </section>
      <div className="stats-grid">
        <StatCard
          label="Active products"
          value={stats.totalProducts ?? products.length}
          icon={Package}
          note={`${stats.lowStockProducts ?? stats.lowStock ?? 0} low in stock`}
        />
        <StatCard
          label="Product views"
          value={stats.productViews ?? stats.views ?? 0}
          icon={Activity}
          note="Product views · last 30 days"
        />
        <StatCard
          label="Cart additions"
          value={stats.cartAdditions ?? stats.addToCart ?? 0}
          icon={ShoppingBag}
          note="Cart additions · last 30 days"
        />
        <StatCard
          label="Order requests"
          value={stats.totalRequests ?? stats.whatsappCheckouts ?? stats.checkoutRequests ?? 0}
          icon={ClipboardList}
          note="WhatsApp requests · last 30 days"
        />
      </div>
      <div className="platform-bottom-grid">
        <section className="panel">
          <div className="platform-panel-heading">
            <h2>Merchant details</h2>
            <Users size={18} className="muted" />
          </div>
          <dl className="platform-detail-list">
            <DetailField label="Merchant name">{merchant.name}</DetailField>
            <DetailField label="Email address">
              {merchant.email && (
                <a href={`mailto:${merchant.email}`}>
                  <Mail size={14} />
                  {merchant.email}
                </a>
              )}
            </DetailField>
            <DetailField label="Joined">
              {merchant.createdAt
                ? formatDate(merchant.createdAt)
                : shop.createdAt
                  ? formatDate(shop.createdAt)
                  : '—'}
            </DetailField>
          </dl>
        </section>
        <section className="panel">
          <div className="platform-panel-heading">
            <h2>Shop information</h2>
            <MapPin size={18} className="muted" />
          </div>
          <dl className="platform-detail-list">
            <DetailField label="Address">{shop.address}</DetailField>
            <DetailField label="Contact number">{shop.phone}</DetailField>
            <DetailField label="WhatsApp number">
              {shop.whatsapp || shop.whatsappNumber}
            </DetailField>
          </dl>
        </section>
      </div>
      {shop.description && (
        <section className="panel platform-description">
          <h2>About the shop</h2>
          <p className="muted">{shop.description}</p>
        </section>
      )}
      {analytics && (
        <div className="platform-bottom-grid">
          <ProductRanking
            title="Most viewed products"
            description="Customer interest over the last 30 days."
            entries={analytics.mostViewed}
            unit="views"
          />
          <ProductRanking
            title="Most requested products"
            description="Units included in requests over the last 30 days."
            entries={analytics.mostRequested}
            unit="units"
          />
        </div>
      )}
      <section className="panel">
        <div className="platform-panel-heading">
          <div>
            <h2>Product catalog</h2>
            <p className="muted">{products.length} products in this shop.</p>
          </div>
          <span className="badge">Read-only catalog</span>
        </div>
        {!products.length ? (
          <EmptyState
            title="No products yet"
            description="Products added by this merchant will appear here."
          />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Available stock</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => (
                  <tr key={product._id}>
                    <td>
                      <div className="platform-identity">
                        <span className="platform-product-image">
                          {product.images?.[0] ? (
                            <img
                              src={
                                typeof product.images[0] === 'string'
                                  ? product.images[0]
                                  : product.images[0].url
                              }
                              alt=""
                            />
                          ) : (
                            <Package size={18} />
                          )}
                        </span>
                        <div>
                          <strong>{product.name}</strong>
                          <div className="platform-subtext">{product.sku || 'No SKU'}</div>
                        </div>
                      </div>
                    </td>
                    <td>{product.category?.name || 'Uncategorized'}</td>
                    <td>
                      {money(product.price)}
                      <span className="muted"> / {product.unit}</span>
                    </td>
                    <td>
                      <span className={product.stock === 0 ? 'platform-out-of-stock' : ''}>
                        {product.stock === 0 ? 'Out of stock' : `${product.stock} ${product.unit}`}
                      </span>
                    </td>
                    <td>
                      <StatusBadge status={product.active === false ? 'inactive' : 'active'} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
      <Modal
        open={Boolean(action)}
        title={action === 'suspended' ? 'Temporarily suspend this shop?' : 'Reactivate this shop?'}
        onClose={closeAction}
      >
        <form className="platform-status-form" onSubmit={submitStatus}>
          <p>
            {action === 'suspended'
              ? `Customers will see “Shop temporarily unavailable” when visiting ${shop.name}. New order requests will be blocked and the merchant will see the account status after signing in.`
              : `${shop.name} will be available to customers again and the merchant can resume managing the shop.`}
          </p>
          <p className="muted">
            Your name, the reason, and the time of this change will be saved in the platform audit
            log.
          </p>
          <label className="field">
            <span>
              Reason <span aria-hidden="true">*</span>
            </span>
            <textarea
              className="input"
              rows={4}
              required
              minLength={3}
              maxLength={600}
              value={reason}
              onChange={(event) => setReason(event.target.value)}
              placeholder={
                action === 'suspended'
                  ? 'Explain why this shop is being suspended…'
                  : 'Explain why the shop is being reactivated…'
              }
              disabled={saving}
            />
          </label>
          {saveError && (
            <p className="platform-form-error" role="alert">
              {saveError}
            </p>
          )}
          <div className="platform-modal-actions">
            <button
              type="button"
              className="button button-secondary"
              onClick={closeAction}
              disabled={saving}
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`button ${action === 'suspended' ? 'button-danger' : 'button-primary'}`}
              disabled={saving || reason.trim().length < 3}
            >
              {saving
                ? 'Saving change…'
                : action === 'suspended'
                  ? 'Suspend shop'
                  : 'Reactivate shop'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

function Audit() {
  const { data, error, loading, refresh } = useResource('/platform/audit');
  return (
    <div className="page-stack platform-page">
      <PageHeading
        title="Platform audit log"
        description="An accountable record of shop status changes across your platform."
      />
      <section className="panel">
        <div className="platform-panel-heading">
          <div>
            <h2>Account activity</h2>
            <p className="muted">
              Every action records the administrator, affected shop, reason, and time.
            </p>
          </div>
          <ShieldCheck size={22} className="muted" />
        </div>
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={refresh} />
        ) : (
          <AuditTable logs={data?.logs} />
        )}
      </section>
    </div>
  );
}

export default function Platform() {
  return (
    <Routes>
      <Route index element={<Dashboard />} />
      <Route path="shops" element={<Shops />} />
      <Route path="shops/:id" element={<ShopDetail />} />
      <Route path="audit" element={<Audit />} />
      <Route
        path="*"
        element={
          <EmptyState
            title="Page not found"
            description="Choose a page from the platform navigation."
          >
            <Link className="button button-primary" to="/platform">
              Platform overview
            </Link>
          </EmptyState>
        }
      />
    </Routes>
  );
}
