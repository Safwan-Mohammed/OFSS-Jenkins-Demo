import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, Route, Routes, useLocation, useParams, useSearchParams } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Leaf,
  MapPin,
  MessageCircle,
  Minus,
  Package,
  Plus,
  Search,
  ShieldCheck,
  ShoppingBag,
  SlidersHorizontal,
  Store,
  Trash2,
  X,
} from 'lucide-react';
import { api, money } from '../../lib/api';
import './storefront.css';

const fallback = '/placeholder.svg';
const cartKey = (slug) => `supplylane:cart:${slug}`;
function readCart(slug) {
  try {
    const data = JSON.parse(localStorage.getItem(cartKey(slug)) || '[]');
    return Array.isArray(data)
      ? data
          .filter(
            (item) =>
              typeof item._id === 'string' && Number.isInteger(item.quantity) && item.quantity > 0,
          )
          .slice(0, 100)
      : [];
  } catch {
    return [];
  }
}
function productSnapshot(product, quantity) {
  return {
    _id: product._id,
    name: product.name,
    price: product.price,
    unit: product.unit,
    stock: product.stock,
    image: product.images?.[0] || fallback,
    quantity,
  };
}
function ProductImage({ src, alt, ...props }) {
  return (
    <img
      src={src || fallback}
      alt={alt}
      loading="lazy"
      onError={(event) => {
        event.currentTarget.onerror = null;
        event.currentTarget.src = fallback;
      }}
      {...props}
    />
  );
}
function ErrorState({ message, retry, title = 'Something went wrong' }) {
  return (
    <div className="sf-state" role="alert">
      <Package size={34} />
      <h2>{title}</h2>
      <p>{message}</p>
      {retry && (
        <button className="sf-button" onClick={retry}>
          Try again
        </button>
      )}
    </div>
  );
}
function Loading({ text = 'Getting everything ready…' }) {
  return (
    <div className="sf-state" role="status">
      <span className="sf-spinner" />
      <p>{text}</p>
    </div>
  );
}
function Quantity({ value, max, onChange, name = 'item', disabled = false }) {
  return (
    <div className="sf-quantity">
      <button
        type="button"
        disabled={disabled || value <= 1}
        aria-label={`Decrease ${name} quantity`}
        onClick={() => onChange(value - 1)}
      >
        <Minus size={14} />
      </button>
      <span aria-live="polite">{value}</span>
      <button
        type="button"
        disabled={disabled || value >= max}
        aria-label={`Increase ${name} quantity`}
        onClick={() => onChange(value + 1)}
      >
        <Plus size={14} />
      </button>
    </div>
  );
}
function useCurrentProducts(slug, items) {
  const signature = items
    .map((item) => item._id)
    .sort()
    .join(',');
  const [state, setState] = useState({ products: {}, unavailable: [], loading: true, error: '' });
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let live = true;
    if (!signature) {
      setState({ products: {}, unavailable: [], loading: false, error: '' });
      return;
    }
    setState((current) => ({ ...current, loading: true, error: '' }));
    Promise.all(
      signature.split(',').map(async (id) => {
        try {
          const result = await api(`/shops/${encodeURIComponent(slug)}/products/${id}`);
          return [id, result.product];
        } catch (error) {
          if (error.status === 404) return [id, null];
          throw error;
        }
      }),
    )
      .then((entries) => {
        if (live)
          setState({
            products: Object.fromEntries(entries.filter(([, product]) => product)),
            unavailable: entries.filter(([, product]) => !product).map(([id]) => id),
            loading: false,
            error: '',
          });
      })
      .catch((error) => {
        if (live) setState((current) => ({ ...current, loading: false, error: error.message }));
      });
    return () => {
      live = false;
    };
  }, [slug, signature, attempt]);
  return { ...state, retry: () => setAttempt((value) => value + 1) };
}

export default function Storefront() {
  const { slug } = useParams();
  const location = useLocation();
  const base = `/shop/${slug}`;
  const [shopState, setShopState] = useState({
    loading: true,
    shop: null,
    categories: [],
    error: null,
  });
  const [attempt, setAttempt] = useState(0);
  const [cartState, setCartState] = useState(() => ({ slug, items: readCart(slug) }));
  const [toast, setToast] = useState('');
  const toastTimer = useRef();
  const items = cartState.slug === slug ? cartState.items : readCart(slug);
  const setItems = (updater) =>
    setCartState((current) => ({
      slug,
      items:
        typeof updater === 'function'
          ? updater(current.slug === slug ? current.items : readCart(slug))
          : updater,
    }));
  useEffect(() => {
    try {
      localStorage.setItem(cartKey(cartState.slug), JSON.stringify(cartState.items));
    } catch {
      /* The cart still works if browser storage is unavailable. */
    }
  }, [cartState]);
  useEffect(() => {
    let live = true;
    setShopState({ loading: true, shop: null, categories: [], error: null });
    api(`/shops/${encodeURIComponent(slug)}`)
      .then((data) => {
        if (live) setShopState({ ...data, loading: false, error: null });
      })
      .catch((error) => {
        if (live) setShopState({ loading: false, shop: null, categories: [], error });
      });
    return () => {
      live = false;
    };
  }, [slug, attempt]);
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);
  useEffect(() => () => clearTimeout(toastTimer.current), []);
  function notify(message) {
    setToast(message);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 3500);
  }
  function track(type, productId) {
    api(`/shops/${encodeURIComponent(slug)}/events`, {
      method: 'POST',
      body: { type, productId },
    }).catch(() => {});
  }
  function addToCart(product, quantity = 1) {
    if (product.active === false || product.stock < 1) return;
    const existing = items.find((item) => item._id === product._id);
    const nextQuantity = Math.min(product.stock, (existing?.quantity || 0) + quantity);
    if (existing && nextQuantity === existing.quantity) {
      notify('You’ve added all available stock.');
      return;
    }
    setItems((current) => {
      const found = current.find((item) => item._id === product._id);
      return found
        ? current.map((item) =>
            item._id === product._id
              ? productSnapshot(product, Math.min(product.stock, item.quantity + quantity))
              : item,
          )
        : [...current, productSnapshot(product, Math.min(product.stock, quantity))];
    });
    track('add_to_cart', product._id);
    notify(`${product.name} added to your bag`);
  }
  const { shop, categories = [], error, loading } = shopState;
  if (loading)
    return (
      <main className="storefront">
        <Loading text="Opening the shop…" />
      </main>
    );
  if (error || !shop || shop.status === 'suspended') {
    const suspended =
      error?.status === 423 || error?.code === 'SHOP_SUSPENDED' || shop?.status === 'suspended';
    return (
      <main className="storefront sf-unavailable">
        <Link to="/" className="sf-platform">
          <Leaf size={21} /> SupplyLane
        </Link>
        <div className="sf-unavailable-card">
          <span className="sf-empty-icon">
            <Store size={36} />
          </span>
          <span className="sf-eyebrow">{suspended ? 'WE’LL BE BACK' : 'SHOP UNAVAILABLE'}</span>
          <h1>
            {suspended
              ? 'Shop temporarily unavailable'
              : error?.status === 404
                ? 'This shop couldn’t be found'
                : 'We couldn’t open this shop'}
          </h1>
          <p>
            {suspended
              ? 'This shop is taking a pause. Please check back later or contact the merchant directly.'
              : error?.status === 404
                ? 'Check the shop address and try again.'
                : error?.message || 'Please try again in a moment.'}
          </p>
          {error?.status !== 404 && !suspended && (
            <button className="sf-button" onClick={() => setAttempt((value) => value + 1)}>
              Try again
            </button>
          )}
          <Link to="/" className="sf-text-link">
            Back to SupplyLane <ArrowRight size={16} />
          </Link>
        </div>
      </main>
    );
  }
  const context = { shop, categories, slug, base, items, setItems, addToCart, track, notify };
  const cartCount = items.reduce((sum, item) => sum + item.quantity, 0);
  return (
    <div
      className="storefront"
      style={{
        '--sf-brand': /^#[0-9a-f]{6}$/i.test(shop.theme?.primary || '')
          ? shop.theme.primary
          : '#28624e',
      }}
    >
      <div className="sf-utility">
        <div className="sf-container">
          <span>
            <Leaf size={13} /> Thoughtfully sourced. Wholesale made simple.
          </span>
          <Link to="/login">
            Merchant sign in <ArrowUpRight size={13} />
          </Link>
        </div>
      </div>
      <header className="sf-header">
        <div className="sf-container sf-header-inner">
          <Link to={base} className="sf-shop-brand">
            {shop.logo ? (
              <ProductImage src={shop.logo} alt="" />
            ) : (
              <span className="sf-brand-mark">
                <Leaf size={24} />
              </span>
            )}
            <span>
              <strong>{shop.name}</strong>
              <small>YOUR WHOLESALE PARTNER</small>
            </span>
          </Link>
          <nav aria-label="Shop navigation">
            <Link
              className={
                location.pathname === base || location.pathname === `${base}/` ? 'active' : ''
              }
              to={base}
            >
              Shop all
            </Link>
            <a href={`${base}#shop-about`}>Our story</a>
            <a href={`${base}#shop-contact`}>Get in touch</a>
          </nav>
          <Link
            to={`${base}/cart`}
            className="sf-bag"
            aria-label={`Shopping bag, ${cartCount} items`}
          >
            <ShoppingBag size={20} />
            <span>Your bag</span>
            <b>{cartCount}</b>
          </Link>
        </div>
      </header>
      <Routes>
        <Route index element={<Catalog {...context} />} />
        <Route path="products" element={<Catalog {...context} listing />} />
        <Route path="category/:categoryId" element={<Catalog {...context} />} />
        <Route path="products/:productId" element={<ProductDetail {...context} />} />
        <Route path="cart" element={<Cart {...context} />} />
        <Route path="checkout" element={<Checkout {...context} />} />
        <Route
          path="*"
          element={
            <main className="sf-container">
              <ErrorState
                title="Page not found"
                message="The page you’re looking for has moved or doesn’t exist."
              />
              <Link className="sf-button" to={base}>
                Explore the shop
              </Link>
            </main>
          }
        />
      </Routes>
      <footer className="sf-footer" id="shop-contact">
        <div className="sf-container sf-footer-top">
          <div id="shop-about">
            <Link to={base} className="sf-shop-brand">
              <span className="sf-brand-mark">
                <Leaf size={23} />
              </span>
              <strong>{shop.name}</strong>
            </Link>
            <p>
              {shop.description ||
                'Good products, honest prices, and a partner you can count on. Stock your shelves with confidence.'}
            </p>
          </div>
          <div>
            <h3>Visit & connect</h3>
            {shop.address && (
              <p>
                <MapPin size={15} />
                {shop.address}
              </p>
            )}
            {shop.phone && (
              <p>
                <MessageCircle size={15} />
                <a href={`tel:${shop.phone}`}>{shop.phone}</a>
              </p>
            )}
            {shop.businessHours && (
              <p>
                <Clock3 size={15} />
                {shop.businessHours}
              </p>
            )}
          </div>
          <div className="sf-footer-note">
            <ShieldCheck size={23} />
            <h3>A little more personal.</h3>
            <p>
              Send your order request on WhatsApp. Your merchant will confirm stock, delivery, and
              the final price.
            </p>
          </div>
        </div>
        <div className="sf-container sf-footer-bottom">
          <span>
            © {new Date().getFullYear()} {shop.name}. All rights reserved.
          </span>
          <Link to="/">
            Powered by <Leaf size={13} />
            <strong>SupplyLane</strong>
          </Link>
        </div>
      </footer>
      {toast && (
        <div className="sf-toast" role="status">
          <CheckCircle2 size={19} />
          <span>{toast}</span>
          <button onClick={() => setToast('')} aria-label="Dismiss notification">
            <X size={16} />
          </button>
        </div>
      )}
    </div>
  );
}

function Catalog({ shop, categories, slug, base, addToCart, listing = false }) {
  const { categoryId } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState(searchParams.get('search') || '');
  const [stockOnly, setStockOnly] = useState(searchParams.get('stock') === 'in');
  const [state, setState] = useState({ products: [], total: 0, loading: true, error: '' });
  const [attempt, setAttempt] = useState(0);
  const [sort, setSort] = useState('featured');
  const category = categories.find((item) => item._id === categoryId);
  useEffect(() => {
    setSearch(searchParams.get('search') || '');
    setStockOnly(searchParams.get('stock') === 'in');
  }, [searchParams]);
  useEffect(() => {
    let live = true;
    const timeout = setTimeout(() => {
      const query = new URLSearchParams();
      if (search.trim()) query.set('search', search.trim());
      if (categoryId) query.set('category', categoryId);
      if (stockOnly) query.set('stock', 'in');
      query.set('limit', '200');
      setState((current) => ({ ...current, loading: true, error: '' }));
      api(`/shops/${encodeURIComponent(slug)}/products?${query}`)
        .then((data) => {
          if (live) setState({ ...data, loading: false, error: '' });
        })
        .catch((error) => {
          if (live) setState({ products: [], total: 0, loading: false, error: error.message });
        });
    }, 250);
    return () => {
      live = false;
      clearTimeout(timeout);
    };
  }, [slug, categoryId, search, stockOnly, attempt]);
  const products = useMemo(() => {
    const data = (state.products || []).filter((product) => product.active !== false);
    if (sort === 'price-low') return [...data].sort((a, b) => a.price - b.price);
    if (sort === 'price-high') return [...data].sort((a, b) => b.price - a.price);
    if (sort === 'name') return [...data].sort((a, b) => a.name.localeCompare(b.name));
    return data;
  }, [state.products, sort]);
  function updateFilters(nextSearch, nextStock) {
    setSearch(nextSearch);
    setStockOnly(nextStock);
    const params = new URLSearchParams();
    if (nextSearch) params.set('search', nextSearch);
    if (nextStock) params.set('stock', 'in');
    setSearchParams(params, { replace: true, preventScrollReset: true });
  }
  const hero = !categoryId && !listing && !search;
  return (
    <main>
      {hero && (
        <section className="sf-hero sf-container">
          <div className="sf-hero-copy">
            <span className="sf-eyebrow">
              <span /> GOOD BUSINESS STARTS HERE
            </span>
            <h1>
              Well stocked.
              <br />
              <em>Well connected.</em>
            </h1>
            <p>
              {shop.description ||
                'Your everyday essentials, at exceptional wholesale prices. Thoughtfully sourced for businesses like yours.'}
            </p>
            <a href="#catalog" className="sf-button">
              Explore the collection <ArrowRight size={17} />
            </a>
            <div className="sf-hero-proof">
              <span className="sf-check-circle">
                <Check size={12} />
              </span>
              Wholesale prices <i /> Direct from your merchant
            </div>
          </div>
          <div className={`sf-hero-visual ${shop.banner ? 'has-banner' : ''}`}>
            {shop.banner ? (
              <ProductImage src={shop.banner} alt={`${shop.name} wholesale collection`} />
            ) : (
              <>
                <div className="sf-hero-orbit" />
                <div className="sf-pack sf-pack-one">
                  <span>
                    THE EVERYDAY
                    <br />
                    ESSENTIALS
                  </span>
                  <Leaf size={42} />
                  <strong>
                    Good things,
                    <br />
                    in good company.
                  </strong>
                  <small>QUALITY YOU CAN COUNT ON</small>
                </div>
                <div className="sf-pack sf-pack-two">
                  <Leaf size={29} />
                  <strong>
                    naturally
                    <br />
                    better.
                  </strong>
                  <span>STOCK UP ON THE GOOD STUFF</span>
                </div>
                <div className="sf-hero-sprig">
                  <Leaf size={92} strokeWidth={1} />
                </div>
              </>
            )}
            <div className="sf-hero-sticker">
              <ShieldCheck size={24} />
              <span>
                Good quality.
                <br />
                <strong>Great partnerships.</strong>
              </span>
            </div>
            <span className="sf-hero-caption">FROM OUR SHELVES TO YOURS</span>
          </div>
        </section>
      )}
      {hero && (
        <div className="sf-promises sf-container">
          <span>
            <Package size={20} />
            <strong>Wholesale, without the hassle</strong>
          </span>
          <span>
            <MessageCircle size={20} />
            <strong>Easy ordering on WhatsApp</strong>
          </span>
          <span>
            <ShieldCheck size={20} />
            <strong>A merchant you can reach</strong>
          </span>
        </div>
      )}
      <section className="sf-container sf-catalog" id="catalog">
        <div className="sf-section-heading">
          <div>
            <span className="sf-eyebrow">THE CATALOG</span>
            <h2>{category?.name || (categoryId ? 'Category' : 'Everyday essentials, sorted.')}</h2>
            <p>
              {category
                ? `Explore wholesale ${category.name.toLowerCase()} for your business.`
                : 'Discover good products for your next great order.'}
            </p>
          </div>
          <span className="sf-product-count">
            {state.loading
              ? 'Loading collection'
              : `${state.total ?? products.length} products to explore`}
          </span>
        </div>
        <div className="sf-catalog-controls">
          <div className="sf-search">
            <Search size={18} />
            <input
              aria-label="Search products"
              placeholder="Search for something good…"
              value={search}
              onChange={(event) => updateFilters(event.target.value, stockOnly)}
            />
            {search && (
              <button aria-label="Clear search" onClick={() => updateFilters('', stockOnly)}>
                <X size={16} />
              </button>
            )}
          </div>
          <label className="sf-stock-filter">
            <input
              type="checkbox"
              checked={stockOnly}
              onChange={(event) => updateFilters(search, event.target.checked)}
            />
            <span>In stock only</span>
          </label>
          <div className="sf-sort">
            <SlidersHorizontal size={16} />
            <select
              aria-label="Sort products"
              value={sort}
              onChange={(event) => setSort(event.target.value)}
            >
              <option value="featured">Featured</option>
              <option value="price-low">Price: low to high</option>
              <option value="price-high">Price: high to low</option>
              <option value="name">Name: A to Z</option>
            </select>
          </div>
        </div>
        <nav className="sf-category-tabs" aria-label="Product categories">
          <Link
            to={`${base}${searchParams.size ? `?${searchParams}` : ''}`}
            className={!categoryId ? 'active' : ''}
          >
            <span>All products</span>
          </Link>
          {categories
            .filter((item) => item.active !== false)
            .map((item) => (
              <Link
                key={item._id}
                className={categoryId === item._id ? 'active' : ''}
                to={`${base}/category/${item._id}${searchParams.size ? `?${searchParams}` : ''}`}
              >
                {item.name}
              </Link>
            ))}
        </nav>
        {state.loading ? (
          <div className="sf-product-grid" aria-label="Loading products" aria-busy="true">
            {Array.from({ length: 8 }, (_, index) => (
              <div key={index} className="sf-skeleton-card">
                <div />
                <span />
                <span />
              </div>
            ))}
          </div>
        ) : state.error ? (
          <ErrorState message={state.error} retry={() => setAttempt((value) => value + 1)} />
        ) : !products.length ? (
          <div className="sf-state">
            <Search size={33} />
            <h2>No products found</h2>
            <p>Try another search or explore a different category.</p>
            <button className="sf-button sf-button-light" onClick={() => updateFilters('', false)}>
              Clear filters
            </button>
          </div>
        ) : (
          <div className="sf-product-grid">
            {products.map((product) => (
              <ProductCard key={product._id} product={product} base={base} addToCart={addToCart} />
            ))}
          </div>
        )}
        {!state.loading && !state.error && state.total > products.length && (
          <p className="sf-catalog-limit">
            Showing {products.length} of {state.total} products. Choose a category or search to find
            more.
          </p>
        )}
      </section>
      <section className="sf-whatsapp-banner sf-container">
        <span className="sf-whatsapp-symbol">
          <MessageCircle size={29} />
        </span>
        <div>
          <h2>Good business starts with a conversation.</h2>
          <p>Build your bag, send it on WhatsApp, and let’s take it from there.</p>
        </div>
        <Link className="sf-button sf-button-light" to={`${base}/cart`}>
          View your bag <ArrowUpRight size={17} />
        </Link>
      </section>
    </main>
  );
}

function ProductCard({ product, base, addToCart }) {
  const available = product.stock > 0 && product.active !== false;
  return (
    <article className="sf-product-card">
      <Link className="sf-product-image" to={`${base}/products/${product._id}`}>
        <ProductImage src={product.images?.[0]} alt={product.name} />
        <span className={`sf-stock-tag ${!available ? 'sf-stock-out' : ''}`}>
          <span />
          {available ? 'In stock' : 'Out of stock'}
        </span>
        <span className="sf-image-arrow">
          <ArrowUpRight size={18} />
        </span>
      </Link>
      <div className="sf-product-meta">
        <span>{product.category?.name || 'ESSENTIALS'}</span>
        <span>{product.unit}</span>
      </div>
      <h3>
        <Link to={`${base}/products/${product._id}`}>{product.name}</Link>
      </h3>
      <p className="sf-product-description">
        {product.description || 'Quality essentials for your business.'}
      </p>
      <div className="sf-product-bottom">
        <div>
          <strong>{money(product.price)}</strong>
          <span> / {product.unit}</span>
        </div>
        <button
          className="sf-add-button"
          disabled={!available}
          aria-label={`Add ${product.name} to bag`}
          onClick={() => addToCart(product)}
        >
          {available ? <Plus size={19} /> : <Minus size={19} />}
        </button>
      </div>
    </article>
  );
}

function ProductDetail({ slug, base, addToCart, track, items }) {
  const { productId } = useParams();
  const [state, setState] = useState({ loading: true, product: null, error: '' });
  const [attempt, setAttempt] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  useEffect(() => {
    let live = true;
    setState({ loading: true, product: null, error: '' });
    setQuantity(1);
    setSelectedImage(0);
    api(`/shops/${encodeURIComponent(slug)}/products/${productId}`)
      .then((data) => {
        if (live) {
          setState({ ...data, loading: false, error: '' });
          track('product_view', productId);
        }
      })
      .catch((error) => {
        if (live) setState({ loading: false, product: null, error: error.message });
      });
    return () => {
      live = false;
    };
  }, [slug, productId, attempt]);
  if (state.loading)
    return (
      <main className="sf-container">
        <Loading text="Getting the product details…" />
      </main>
    );
  if (state.error || !state.product)
    return (
      <main className="sf-container">
        <ErrorState
          title="Product unavailable"
          message={state.error || 'This product is no longer available.'}
          retry={() => setAttempt((value) => value + 1)}
        />
        <Link to={base} className="sf-text-link">
          <ArrowLeft size={16} /> Back to the collection
        </Link>
      </main>
    );
  const { product } = state;
  const available = product.stock > 0 && product.active !== false;
  const inCart = items.find((item) => item._id === productId)?.quantity || 0;
  const remaining = Math.max(0, product.stock - inCart);
  const images = product.images?.length ? product.images : [fallback];
  return (
    <main className="sf-container sf-detail-page">
      <nav className="sf-breadcrumb" aria-label="Breadcrumb">
        <Link to={base}>Shop all</Link>
        <ChevronRight size={13} />
        {product.category && (
          <>
            <Link to={`${base}/category/${product.category._id}`}>{product.category.name}</Link>
            <ChevronRight size={13} />
          </>
        )}
        <span>{product.name}</span>
      </nav>
      <section className="sf-detail-grid">
        <div>
          <div className="sf-detail-image">
            <ProductImage src={images[selectedImage]} alt={product.name} />
            <span className={`sf-stock-tag ${!available ? 'sf-stock-out' : ''}`}>
              <span />
              {available ? 'In stock' : 'Out of stock'}
            </span>
          </div>
          {images.length > 1 && (
            <div className="sf-image-thumbnails">
              {images.map((src, index) => (
                <button
                  key={`${src}-${index}`}
                  className={selectedImage === index ? 'active' : ''}
                  aria-label={`View product image ${index + 1}`}
                  aria-pressed={selectedImage === index}
                  onClick={() => setSelectedImage(index)}
                >
                  <ProductImage src={src} alt={`${product.name}, view ${index + 1}`} />
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="sf-detail-copy">
          <span className="sf-eyebrow">{product.category?.name || 'EVERYDAY ESSENTIALS'}</span>
          <h1>{product.name}</h1>
          <div className="sf-detail-price">
            {money(product.price)}
            <span> / {product.unit}</span>
          </div>
          <span className="sf-price-note">Wholesale price · Final total confirmed by merchant</span>
          <p className="sf-detail-description">{product.description}</p>
          <dl className="sf-specs">
            <div>
              <dt>Availability</dt>
              <dd className={!available ? 'sf-danger-text' : ''}>
                {available
                  ? `${product.stock} ${product.unit}${product.stock === 1 ? '' : 's'} available`
                  : 'Out of stock'}
              </dd>
            </div>
            <div>
              <dt>Unit</dt>
              <dd>{product.unit}</dd>
            </div>
            {product.sku && (
              <div>
                <dt>Product code</dt>
                <dd>{product.sku}</dd>
              </div>
            )}
          </dl>
          {available && remaining > 0 && (
            <div className="sf-detail-quantity">
              <label>Quantity</label>
              <Quantity
                value={Math.min(quantity, remaining)}
                max={remaining}
                name={product.name}
                onChange={setQuantity}
              />
            </div>
          )}
          <button
            className="sf-button sf-detail-add"
            disabled={!available || !remaining}
            onClick={() => addToCart(product, Math.min(quantity, remaining))}
          >
            <ShoppingBag size={18} />
            {!available
              ? 'Currently out of stock'
              : !remaining
                ? 'All available stock is in your bag'
                : 'Add to your bag'}
            {available && remaining > 0 && (
              <span>{money(product.price * Math.min(quantity, remaining))}</span>
            )}
          </button>
          {inCart > 0 && (
            <Link to={`${base}/cart`} className="sf-in-cart">
              <CheckCircle2 size={16} /> {inCart} already in your bag <ArrowRight size={15} />
            </Link>
          )}
          <div className="sf-detail-assurance">
            <MessageCircle size={20} />
            <p>
              <strong>A simple, personal way to order.</strong>
              <br />
              Send your request on WhatsApp. Your merchant will confirm availability and delivery.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}

function Cart({ slug, base, items, setItems }) {
  const current = useCurrentProducts(slug, items);
  const valid =
    !current.loading &&
    !current.error &&
    items.every((item) => {
      const product = current.products[item._id];
      return product && product.active !== false && product.stock >= item.quantity;
    });
  const total = items.reduce(
    (sum, item) => sum + (current.products[item._id]?.price ?? item.price) * item.quantity,
    0,
  );
  function setQuantity(id, quantity, max) {
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > max) return;
    setItems((previous) =>
      previous.map((item) => (item._id === id ? { ...item, quantity } : item)),
    );
  }
  if (!items.length) return <EmptyCart base={base} />;
  return (
    <main className="sf-container sf-cart-page">
      <Link to={base} className="sf-text-link">
        <ArrowLeft size={15} /> Keep exploring
      </Link>
      <div className="sf-page-heading">
        <span className="sf-eyebrow">GOOD THINGS IN THE BAG</span>
        <h1>
          Your shopping bag<span>{items.length}</span>
        </h1>
        <p>You’re one step closer to a well-stocked business.</p>
      </div>
      <div className="sf-cart-layout">
        <section className="sf-cart-items" aria-label="Shopping bag items">
          {current.loading && (
            <p className="sf-inline-status" role="status">
              Checking current prices and availability…
            </p>
          )}
          {current.error && (
            <div className="sf-error" role="alert">
              {current.error} <button onClick={current.retry}>Try again</button>
            </div>
          )}
          {items.map((item) => {
            const product = current.products[item._id];
            const unavailable =
              !current.loading &&
              !current.error &&
              (!product || product.active === false || product.stock < 1);
            const stock = product?.stock ?? item.stock;
            return (
              <article key={item._id} className="sf-cart-item">
                <Link to={`${base}/products/${item._id}`} className="sf-cart-image">
                  <ProductImage
                    src={product?.images?.[0] || item.image}
                    alt={product?.name || item.name}
                  />
                </Link>
                <div className="sf-cart-item-copy">
                  <Link to={`${base}/products/${item._id}`}>
                    <h3>{product?.name || item.name}</h3>
                  </Link>
                  <p>
                    {money(product?.price ?? item.price)} / {product?.unit || item.unit}
                  </p>
                  {unavailable ? (
                    <span className="sf-danger-text">This product is no longer available</span>
                  ) : product && item.quantity > stock ? (
                    <span className="sf-danger-text">
                      Only {stock} available. Please reduce your quantity.
                    </span>
                  ) : (
                    <span className="sf-muted">Sold by the {product?.unit || item.unit}</span>
                  )}
                  <div className="sf-cart-item-actions">
                    <Quantity
                      value={item.quantity}
                      max={stock}
                      name={item.name}
                      disabled={unavailable || current.loading}
                      onChange={(quantity) =>
                        setQuantity(item._id, Math.min(quantity, stock), stock)
                      }
                    />
                    <button
                      className="sf-remove"
                      aria-label={`Remove ${item.name}`}
                      onClick={() =>
                        setItems((previous) => previous.filter((entry) => entry._id !== item._id))
                      }
                    >
                      <Trash2 size={15} />
                      <span>Remove</span>
                    </button>
                  </div>
                </div>
                <strong className="sf-line-total">
                  {money((product?.price ?? item.price) * item.quantity)}
                </strong>
              </article>
            );
          })}
          <div className="sf-cart-bottom-note">
            <ShieldCheck size={17} />
            Prices and stock are checked before you send your request.
          </div>
        </section>
        <OrderSummary items={items} total={total}>
          <Link
            aria-disabled={!valid}
            tabIndex={!valid ? -1 : undefined}
            onClick={(event) => {
              if (!valid) event.preventDefault();
            }}
            className={`sf-button sf-full ${!valid ? 'sf-disabled' : ''}`}
            to={`${base}/checkout`}
          >
            Continue to checkout <ArrowRight size={17} />
          </Link>
          {!current.loading && !current.error && !valid && (
            <p className="sf-danger-text">
              Update unavailable quantities or remove items to continue.
            </p>
          )}
        </OrderSummary>
      </div>
    </main>
  );
}
function EmptyCart({ base }) {
  return (
    <main className="sf-container">
      <div className="sf-state sf-empty-cart">
        <span className="sf-empty-icon">
          <ShoppingBag size={35} />
        </span>
        <span className="sf-eyebrow">ROOM FOR SOMETHING GOOD</span>
        <h1>Your bag is waiting.</h1>
        <p>Explore the collection and add a few essentials to get started.</p>
        <Link className="sf-button" to={base}>
          Explore the collection <ArrowRight size={17} />
        </Link>
      </div>
    </main>
  );
}
function OrderSummary({ items, total, children }) {
  return (
    <aside className="sf-order-summary">
      <h2>Order summary</h2>
      <div className="sf-summary-row">
        <span>Subtotal · {items.reduce((sum, item) => sum + item.quantity, 0)} units</span>
        <strong>{money(total)}</strong>
      </div>
      <div className="sf-summary-row">
        <span>Delivery</span>
        <span>Confirmed by merchant</span>
      </div>
      <div className="sf-summary-total">
        <span>Estimated total</span>
        <strong>{money(total)}</strong>
      </div>
      <p>Delivery charges and final pricing will be confirmed by your merchant.</p>
      {children}
      <div className="sf-summary-note">
        <MessageCircle size={18} />
        <span>
          No payment required here.
          <br />
          Order directly with your merchant.
        </span>
      </div>
    </aside>
  );
}

function Checkout({ shop, slug, base, items, setItems }) {
  const current = useCurrentProducts(slug, items);
  const [customer, setCustomer] = useState({ name: '', phone: '', note: '' });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(null);
  const [submittedItems, setSubmittedItems] = useState([]);
  const requestKey = useRef(null);
  const submitLock = useRef(false);
  const valid =
    !current.loading &&
    !current.error &&
    items.length > 0 &&
    items.every((item) => {
      const product = current.products[item._id];
      return product && product.active !== false && product.stock >= item.quantity;
    });
  const total = items.reduce(
    (sum, item) => sum + (current.products[item._id]?.price ?? item.price) * item.quantity,
    0,
  );
  const payloadSignature = JSON.stringify({
    customer,
    items: items.map((item) => ({ productId: item._id, quantity: item.quantity })),
  });
  useEffect(() => {
    requestKey.current = null;
  }, [payloadSignature]);
  async function submit(event) {
    event.preventDefault();
    if (!valid || submitting || submitLock.current) return;
    const phoneDigits = customer.phone.replace(/\D/g, '');
    if (
      !customer.name.trim() ||
      !/^[+\d\s()-]+$/.test(customer.phone.trim()) ||
      phoneDigits.length < 8 ||
      phoneDigits.length > 15
    ) {
      setError('Please enter your name and a valid phone number containing 8–15 digits.');
      return;
    }
    submitLock.current = true;
    setSubmitting(true);
    setError('');
    try {
      const payload = {
        customer: {
          name: customer.name.trim(),
          phone: customer.phone.trim(),
          note: customer.note.trim(),
        },
        items: items.map((item) => ({ productId: item._id, quantity: item.quantity })),
      };
      if (!requestKey.current) requestKey.current = crypto.randomUUID();
      const data = await api(`/shops/${encodeURIComponent(slug)}/checkout`, {
        method: 'POST',
        headers: { 'Idempotency-Key': requestKey.current },
        body: payload,
      });
      setSubmittedItems(
        data.order?.items?.length
          ? data.order.items.map((item) => ({
              ...item,
              _id: item.product || item.productId || item._id,
            }))
          : items.map((item) => ({
              ...item,
              name: current.products[item._id]?.name || item.name,
              price: current.products[item._id]?.price ?? item.price,
            })),
      );
      setSuccess({ ...data, estimatedTotal: total });
      setItems([]);
    } catch (caught) {
      setError(caught.message);
      current.retry();
    } finally {
      setSubmitting(false);
      submitLock.current = false;
    }
  }
  if (success) {
    const reference =
      success.order?.reference ||
      success.order?.orderReference ||
      success.order?._id ||
      'Your order request';
    let whatsappUrl = '';
    try {
      const url = new URL(success.whatsappUrl);
      if (
        url.protocol === 'https:' &&
        ['wa.me', 'api.whatsapp.com', 'web.whatsapp.com'].includes(url.hostname)
      )
        whatsappUrl = url.href;
    } catch {
      /* Invalid links are never opened. */
    }
    return (
      <main className="sf-container sf-success-page">
        <div className="sf-success-header">
          <span className="sf-empty-icon">
            <CheckCircle2 size={38} />
          </span>
          <span className="sf-eyebrow">LET’S MAKE IT HAPPEN</span>
          <h1>Your request is ready.</h1>
          <p>
            Continue to WhatsApp and send your message to {shop.name}.<br />
            Your order is confirmed only when your merchant replies.
          </p>
          <span className="sf-reference">{reference}</span>
        </div>
        <div className="sf-success-card">
          <h2>Your order request</h2>
          {submittedItems.map((item) => (
            <div className="sf-success-item" key={item._id}>
              <div>
                <strong>{item.name}</strong>
                <span>
                  {item.quantity} {item.unit} × {money(item.price)}
                </span>
              </div>
              <strong>{money(item.price * item.quantity)}</strong>
            </div>
          ))}
          <div className="sf-summary-total">
            <span>Estimated total</span>
            <strong>
              {money(
                success.order?.total ?? success.order?.estimatedTotal ?? success.estimatedTotal,
              )}
            </strong>
          </div>
          {success.message && (
            <details className="sf-message-preview">
              <summary>Preview your WhatsApp message</summary>
              <pre>{success.message}</pre>
            </details>
          )}
          {whatsappUrl ? (
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="sf-button sf-full"
            >
              <MessageCircle size={19} /> Continue to WhatsApp <ArrowUpRight size={17} />
            </a>
          ) : (
            <p className="sf-error">
              The WhatsApp link is unavailable. Please contact the merchant with your order
              reference.
            </p>
          )}
          <p className="sf-success-note">
            This button opens WhatsApp. Review the message and tap send to share your request.
          </p>
        </div>
        <Link to={base} className="sf-text-link">
          <ArrowLeft size={16} /> Back to the collection
        </Link>
      </main>
    );
  }
  if (!items.length) return <EmptyCart base={base} />;
  return (
    <main className="sf-container sf-cart-page">
      <Link to={`${base}/cart`} className="sf-text-link">
        <ArrowLeft size={15} /> Back to your bag
      </Link>
      <div className="sf-page-heading">
        <span className="sf-eyebrow">THE FINAL DETAILS</span>
        <h1>Let’s connect your order.</h1>
        <p>A few details, then a conversation with your merchant.</p>
      </div>
      <form onSubmit={submit} className="sf-cart-layout">
        <section className="sf-checkout-form">
          <div className="sf-form-heading">
            <span>01</span>
            <div>
              <h2>Your contact details</h2>
              <p>So your merchant knows who to get in touch with.</p>
            </div>
          </div>
          <div className="sf-form-fields">
            <label>
              Full name <span>*</span>
              <input
                autoComplete="name"
                placeholder="e.g. Aarav Sharma"
                minLength={2}
                maxLength={100}
                required
                value={customer.name}
                onChange={(event) => setCustomer({ ...customer, name: event.target.value })}
                disabled={submitting}
              />
            </label>
            <label>
              Phone number <span>*</span>
              <input
                type="tel"
                autoComplete="tel"
                placeholder="e.g. +91 98765 43210"
                title="Enter a valid phone number with 8 to 15 digits."
                maxLength={25}
                required
                value={customer.phone}
                onChange={(event) => setCustomer({ ...customer, phone: event.target.value })}
                disabled={submitting}
              />
              <small>Include your country code if you’re ordering internationally.</small>
            </label>
            <label>
              Delivery note <small>(optional)</small>
              <textarea
                placeholder="Delivery address, preferred time, or anything else we should know…"
                rows={4}
                maxLength={600}
                value={customer.note}
                onChange={(event) => setCustomer({ ...customer, note: event.target.value })}
                disabled={submitting}
              />
            </label>
          </div>
          <div className="sf-checkout-explainer">
            <MessageCircle size={22} />
            <div>
              <h3>What happens next?</h3>
              <p>
                We’ll prepare your order request. You can review it, then open WhatsApp to send it
                to your merchant. Stock, delivery, and the final total are confirmed by the
                merchant.
              </p>
            </div>
          </div>
          {current.loading && (
            <p className="sf-inline-status" role="status">
              Verifying your products and their current prices…
            </p>
          )}
          {current.error && (
            <div className="sf-error" role="alert">
              {current.error}{' '}
              <button type="button" onClick={current.retry}>
                Try again
              </button>
            </div>
          )}
          {!current.loading && !current.error && !valid && (
            <div className="sf-error" role="alert">
              Some products are unavailable or have less stock than requested.{' '}
              <Link to={`${base}/cart`}>Update your bag</Link> before continuing.
            </div>
          )}
          {error && (
            <p className="sf-error" role="alert">
              {error}
            </p>
          )}
        </section>
        <OrderSummary items={items} total={total}>
          <div className="sf-checkout-lines">
            {items.map((item) => (
              <div key={item._id}>
                <span>
                  {item.quantity} × {current.products[item._id]?.name || item.name}
                </span>
                <strong>
                  {money((current.products[item._id]?.price ?? item.price) * item.quantity)}
                </strong>
              </div>
            ))}
          </div>
          <button type="submit" className="sf-button sf-full" disabled={!valid || submitting}>
            {submitting ? (
              <>
                <span className="sf-spinner sf-spinner-small" /> Preparing your request…
              </>
            ) : (
              <>
                Prepare order request <ArrowRight size={17} />
              </>
            )}
          </button>
        </OrderSummary>
      </form>
    </main>
  );
}
