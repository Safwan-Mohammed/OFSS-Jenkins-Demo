import { useState } from 'react';
import { Download, MessageCircle, Search } from 'lucide-react';
import { useApi } from '../../lib/hooks';
import { downloadCsv, formatDate, money } from '../../lib/api';
import {
  EmptyState,
  ErrorState,
  Loading,
  Modal,
  PageHeading,
  StatusBadge,
} from '../../components/ui';

export default function Orders() {
  const { data, loading, error, reload } = useApi('/merchant/orders');
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState('');
  const orders = (data?.orders || []).filter((order) =>
    `${order.reference} ${order.customer?.name} ${order.customer?.phone}`
      .toLowerCase()
      .includes(search.toLowerCase()),
  );
  const download = () =>
    downloadCsv('supplylane-requests.csv', [
      ['Reference', 'Customer', 'Phone', 'Estimated total', 'Date', 'Delivery note'],
      ...orders.map((o) => [
        o.reference,
        o.customer?.name,
        o.customer?.phone,
        o.total,
        formatDate(o.createdAt),
        o.customer?.note,
      ]),
    ]);
  return (
    <div className="page-stack">
      <PageHeading
        title="New conversations. New possibilities."
        description="Order requests from your catalog, ready to follow up on WhatsApp."
      >
        <button className="button button-secondary" onClick={download} disabled={!orders.length}>
          <Download size={16} />
          Export requests
        </button>
      </PageHeading>
      <div className="info-banner">
        <MessageCircle size={20} />
        <span>
          These are order requests, not confirmed sales. Confirm availability with your customer,
          then record the stock change in Inventory.
        </span>
      </div>
      <section className="panel">
        <div className="toolbar">
          <h2>Order requests</h2>
          <div className="search-input">
            <Search size={17} />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search reference, name, or phone…"
              aria-label="Search order requests"
            />
          </div>
        </div>
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !orders.length ? (
          <EmptyState
            title="Your next order starts with a hello"
            description="Share your storefront. Customer checkout requests will appear here."
          />
        ) : (
          <>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>REFERENCE</th>
                    <th>CUSTOMER</th>
                    <th>ITEMS</th>
                    <th>ESTIMATED TOTAL</th>
                    <th>DATE</th>
                    <th>
                      <span className="sr-only">Details</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((o) => (
                    <tr key={o._id}>
                      <td>
                        <strong className="order-reference">#{o.reference}</strong>
                      </td>
                      <td>
                        <strong>{o.customer?.name}</strong>
                        <small className="block muted">{o.customer?.phone}</small>
                      </td>
                      <td>{o.items?.length || 0} products</td>
                      <td>{money(o.total)}</td>
                      <td className="muted">{formatDate(o.createdAt)}</td>
                      <td>
                        <button
                          className="button button-secondary button-small"
                          onClick={() => setSelected(o)}
                        >
                          View request
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="table-footer">
              {orders.length} requests<span>Estimated totals · INR</span>
            </div>
          </>
        )}
      </section>
      <Modal
        open={!!selected}
        title={`Request #${selected?.reference || ''}`}
        onClose={() => setSelected(null)}
      >
        {selected && (
          <div className="order-detail">
            <div className="order-customer">
              <div>
                <strong>{selected.customer?.name}</strong>
                <p>{selected.customer?.phone}</p>
              </div>
              <span className="muted">{formatDate(selected.createdAt)}</span>
            </div>
            {selected.items?.map((item, i) => (
              <div className="order-line" key={i}>
                <div>
                  <strong>{item.name}</strong>
                  <small>
                    {item.quantity} {item.unit} × {money(item.price)}
                  </small>
                </div>
                <strong>{money(item.subtotal ?? item.quantity * item.price)}</strong>
              </div>
            ))}
            <div className="order-total">
              <span>Estimated total</span>
              <strong>{money(selected.total)}</strong>
            </div>
            {selected.customer?.note && (
              <div className="delivery-note">
                <strong>Delivery note</strong>
                <p>{selected.customer.note}</p>
              </div>
            )}
            <div className="notice">
              A saved request does not confirm that a WhatsApp message was sent or the order was
              accepted.
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
