import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowUpRight,
  ImagePlus,
  MoreHorizontal,
  Pencil,
  Plus,
  Search,
  SlidersHorizontal,
  Trash2,
  X,
} from 'lucide-react';
import { api, downloadCsv, money, number } from '../../lib/api';
import { useApi, useDebounce } from '../../lib/hooks';
import {
  EmptyState,
  ErrorState,
  Loading,
  Modal,
  Notice,
  PageHeading,
  ProductImage,
  StatusBadge,
} from '../../components/ui';

export function Products() {
  const [params] = useSearchParams();
  const [search, setSearch] = useState('');
  const [stock, setStock] = useState(params.get('stock') || '');
  const [category, setCategory] = useState('');
  const [active, setActive] = useState('');
  const [selected, setSelected] = useState(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [actionError, setActionError] = useState('');
  const debounced = useDebounce(search);
  const query = new URLSearchParams(
    Object.fromEntries(
      Object.entries({ search: debounced, stock, category, active }).filter(([, value]) => value),
    ),
  ).toString();
  const { data, loading, error, reload } = useApi(`/merchant/products?${query}`);
  const categories = useApi('/merchant/categories');
  const deactivate = async () => {
    setBusy(true);
    setActionError('');
    try {
      await api(`/merchant/products/${selected._id}`, { method: 'DELETE' });
      setSelected(null);
      setMessage('Product deactivated. It is no longer visible in your catalog.');
      reload();
    } catch (err) {
      setActionError(err.message);
    } finally {
      setBusy(false);
    }
  };
  const exportProducts = () =>
    downloadCsv('supplylane-products.csv', [
      ['Name', 'SKU', 'Category', 'Price (INR)', 'Unit', 'Stock', 'Low stock threshold', 'Active'],
      ...(data?.products || []).map((p) => [
        p.name,
        p.sku,
        p.category?.name,
        p.price,
        p.unit,
        p.stock,
        p.minStock,
        p.active,
      ]),
    ]);
  return (
    <div className="page-stack">
      <PageHeading
        title="Your products"
        description="A great catalog starts with great products. Keep yours in good shape."
      >
        <button
          className="button button-secondary"
          onClick={exportProducts}
          disabled={!data?.products?.length}
        >
          Export catalog
        </button>
        <Link className="button button-primary" to="/products/new">
          <Plus size={17} />
          Add product
        </Link>
      </PageHeading>
      <Notice>{message}</Notice>
      <section className="panel">
        <div className="toolbar">
          <div className="search-input">
            <Search size={17} />
            <input
              aria-label="Search products"
              placeholder="Search by product name or SKU…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <select
            className="input filter-select"
            aria-label="Category filter"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">All categories</option>
            {categories.data?.categories?.map((c) => (
              <option key={c._id} value={c._id}>
                {c.name}
              </option>
            ))}
          </select>
          <select
            className="input filter-select"
            aria-label="Stock filter"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
          >
            <option value="">All stock levels</option>
            <option value="in">In stock</option>
            <option value="low">Low stock</option>
            <option value="out">Out of stock</option>
          </select>
          <select
            className="input filter-select"
            aria-label="Status filter"
            value={active}
            onChange={(e) => setActive(e.target.value)}
          >
            <option value="">Any status</option>
            <option value="true">Active</option>
            <option value="false">Inactive</option>
          </select>
        </div>
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data.products.length ? (
          <EmptyState
            title="No products found"
            description="Try another search, or add something new to your catalog."
          >
            <Link to="/products/new" className="button button-primary">
              <Plus size={16} />
              Add product
            </Link>
          </EmptyState>
        ) : (
          <>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>PRODUCT</th>
                    <th>CATEGORY</th>
                    <th>WHOLESALE PRICE</th>
                    <th>INVENTORY</th>
                    <th>STATUS</th>
                    <th>
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {data.products.map((p) => (
                    <tr key={p._id}>
                      <td>
                        <Link to={`/products/${p._id}/edit`} className="product-cell">
                          <ProductImage product={p} />
                          <span>
                            <strong>{p.name}</strong>
                            <small>{p.sku || 'No SKU'}</small>
                          </span>
                        </Link>
                      </td>
                      <td>{p.category?.name || 'Uncategorized'}</td>
                      <td className="nowrap">
                        {money(p.price)}
                        <small className="cell-unit"> / {p.unit}</small>
                      </td>
                      <td>
                        <span
                          className={
                            p.stock === 0 ? 'rust-text' : p.stock <= p.minStock ? 'gold-text' : ''
                          }
                        >
                          {number(p.stock)} {p.unit}
                        </span>
                        {p.stock <= p.minStock && (
                          <small className="block muted">
                            {p.stock === 0 ? 'Out of stock' : 'Low stock'}
                          </small>
                        )}
                      </td>
                      <td>
                        <StatusBadge status={p.active ? 'active' : 'inactive'} />
                      </td>
                      <td>
                        <div className="row-actions">
                          <Link
                            className="icon-button"
                            to={`/products/${p._id}/edit`}
                            aria-label={`Edit ${p.name}`}
                          >
                            <Pencil size={16} />
                          </Link>
                          {p.active && (
                            <button
                              className="icon-button"
                              onClick={() => {
                                setSelected(p);
                                setActionError('');
                              }}
                              aria-label={`Deactivate ${p.name}`}
                            >
                              <Trash2 size={16} />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="table-footer">
              {data.total ?? data.products.length} products <span>Prices shown in INR</span>
            </div>
          </>
        )}
      </section>
      <Modal
        open={!!selected}
        title="Deactivate product?"
        onClose={() => !busy && setSelected(null)}
      >
        <p className="modal-copy">
          <strong>{selected?.name}</strong> will be hidden from your public catalog. Its inventory
          history is preserved, and you can reactivate it from the edit page.
        </p>
        <Notice type="error">{actionError}</Notice>
        <div className="form-actions">
          <button
            className="button button-secondary"
            disabled={busy}
            onClick={() => setSelected(null)}
          >
            Cancel
          </button>
          <button className="button button-danger" disabled={busy} onClick={deactivate}>
            {busy ? 'Saving…' : 'Deactivate product'}
          </button>
        </div>
      </Modal>
    </div>
  );
}

const blank = {
  name: '',
  description: '',
  sku: '',
  price: '',
  unit: 'kg',
  stock: '0',
  minStock: '10',
  category: '',
  active: true,
  images: [],
};
export function ProductForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState(blank);
  const [loading, setLoading] = useState(!!id);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const categories = useApi('/merchant/categories');
  useEffect(() => {
    if (id)
      api(`/merchant/products/${id}`)
        .then(({ product }) =>
          setForm({
            ...blank,
            ...product,
            category: product.category?._id || product.category || '',
          }),
        )
        .catch((err) => setError(err.message))
        .finally(() => setLoading(false));
  }, [id]);
  const change = (e) =>
    setForm({
      ...form,
      [e.target.name]: e.target.type === 'checkbox' ? e.target.checked : e.target.value,
    });
  const upload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    if (form.images.length + files.length > 5) {
      setError('You can upload up to five images per product.');
      return;
    }
    setUploading(true);
    setError('');
    try {
      const body = new FormData();
      files.forEach((file) => body.append('images', file));
      const result = await api('/merchant/uploads', { method: 'POST', body });
      setForm((prev) => ({ ...prev, images: [...prev.images, ...result.images] }));
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const body = {
        name: form.name,
        description: form.description,
        sku: form.sku,
        price: Number(form.price),
        unit: form.unit,
        stock: Number(form.stock),
        minStock: Number(form.minStock),
        category: form.category,
        active: form.active,
        images: form.images,
      };
      await api(`/merchant/products${id ? `/${id}` : ''}`, { method: id ? 'PATCH' : 'POST', body });
      navigate('/products');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };
  if (loading) return <Loading />;
  return (
    <div className="page-stack">
      <Link to="/products" className="back-link">
        <ArrowLeft size={16} />
        Back to products
      </Link>
      <PageHeading
        title={id ? 'Edit product' : 'Add something great'}
        description={
          id
            ? 'Keep your product details accurate and your customers informed.'
            : 'Give your customers all the details they need to place an order.'
        }
      />
      <Notice type="error">{error}</Notice>
      <form onSubmit={submit} className="product-form-layout">
        <div className="page-stack">
          <section className="panel form-panel">
            <h2>Product details</h2>
            <div className="field">
              <label htmlFor="product-name">
                Product name <span>*</span>
              </label>
              <input
                className="input"
                id="product-name"
                name="name"
                required
                maxLength={160}
                value={form.name}
                onChange={change}
                placeholder="e.g. Premium Basmati Rice"
              />
            </div>
            <div className="field">
              <label htmlFor="product-description">Description</label>
              <textarea
                className="input"
                id="product-description"
                name="description"
                rows={5}
                maxLength={3000}
                value={form.description}
                onChange={change}
                placeholder="Tell customers what makes this product a good choice…"
              />
            </div>
            <div className="form-grid">
              <div className="field">
                <label htmlFor="product-category">Category</label>
                <select
                  className="input"
                  id="product-category"
                  name="category"
                  required
                  value={form.category}
                  onChange={change}
                >
                  <option value="">Choose a category</option>
                  {categories.data?.categories
                    ?.filter((c) => c.active || c._id === form.category)
                    .map((c) => (
                      <option key={c._id} value={c._id}>
                        {c.name}
                        {c.active ? '' : ' (inactive)'}
                      </option>
                    ))}
                </select>
              </div>
              <div className="field">
                <label htmlFor="product-sku">SKU</label>
                <input
                  className="input"
                  id="product-sku"
                  name="sku"
                  required
                  maxLength={80}
                  value={form.sku}
                  onChange={change}
                  placeholder="e.g. GRN-001"
                />
              </div>
            </div>
          </section>
          <section className="panel form-panel">
            <h2>Pricing & inventory</h2>
            <div className="form-grid">
              <div className="field">
                <label htmlFor="product-price">
                  Wholesale price (₹) <span>*</span>
                </label>
                <input
                  className="input"
                  type="number"
                  id="product-price"
                  name="price"
                  min="0.01"
                  max="10000000"
                  step="0.01"
                  required
                  value={form.price}
                  onChange={change}
                />
              </div>
              <div className="field">
                <label htmlFor="product-unit">Unit type</label>
                <input
                  className="input"
                  id="product-unit"
                  name="unit"
                  required
                  maxLength={30}
                  list="unit-types"
                  value={form.unit}
                  onChange={change}
                />
                <datalist id="unit-types">
                  {[
                    'piece',
                    'box',
                    'kg',
                    'packet',
                    'bag',
                    'litre',
                    'bottle',
                    'dozen',
                    'carton',
                  ].map((unit) => (
                    <option key={unit} value={unit} />
                  ))}
                </datalist>
              </div>
              <div className="field">
                <label htmlFor="product-stock">Stock quantity</label>
                <input
                  className="input"
                  type="number"
                  id="product-stock"
                  name="stock"
                  min="0"
                  max="100000000"
                  step="1"
                  required
                  value={form.stock}
                  onChange={change}
                />
                <small>Changes are recorded in inventory history.</small>
              </div>
              <div className="field">
                <label htmlFor="product-minStock">Low-stock alert at</label>
                <input
                  className="input"
                  type="number"
                  id="product-minStock"
                  name="minStock"
                  min="0"
                  max="100000000"
                  step="1"
                  required
                  value={form.minStock}
                  onChange={change}
                />
                <small>Get a heads-up when stock reaches this quantity.</small>
              </div>
            </div>
          </section>
        </div>
        <div className="page-stack">
          <section className="panel form-panel">
            <h2>Product images</h2>
            <p className="muted">Add up to 5 JPG, PNG or WebP images. Max 5 MB each.</p>
            <div className="image-grid">
              {form.images.map((url, index) => (
                <div key={url + index} className="uploaded-image">
                  <img
                    src={url}
                    alt={`Product image ${index + 1}`}
                    onError={(e) => {
                      e.currentTarget.src = '/placeholder.svg';
                    }}
                  />
                  <button
                    type="button"
                    className="remove-image"
                    aria-label={`Remove image ${index + 1}`}
                    onClick={() =>
                      setForm({ ...form, images: form.images.filter((_, i) => i !== index) })
                    }
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
            <label className={`upload-zone ${uploading ? 'disabled' : ''}`}>
              <ImagePlus size={26} />
              <strong>{uploading ? 'Uploading images…' : 'Choose images'}</strong>
              <span>or take a fresh product photo</span>
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                multiple
                disabled={uploading || form.images.length >= 5}
                onChange={upload}
              />
            </label>
            <small className="muted">
              Uploads use your configured Cloudinary account. A placeholder appears if no image is
              added.
            </small>
          </section>
          <section className="panel form-panel">
            <h2>Catalog visibility</h2>
            <label className="checkbox-field">
              <input type="checkbox" name="active" checked={form.active} onChange={change} />
              <span>
                <strong>Active product</strong>
                <small>Visible to customers in your shop.</small>
              </span>
            </label>
            <p className="muted small-text">
              Products in an inactive category stay hidden from the storefront.
            </p>
          </section>
          <div className="form-actions">
            <Link to="/products" className="button button-secondary">
              Cancel
            </Link>
            <button className="button button-primary" type="submit" disabled={busy || uploading}>
              {busy ? 'Saving…' : id ? 'Save changes' : 'Create product'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
