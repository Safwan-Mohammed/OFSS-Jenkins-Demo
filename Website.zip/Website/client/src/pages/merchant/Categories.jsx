import { useState } from 'react';
import { ImagePlus, Pencil, Plus, Search, Trash2, X } from 'lucide-react';
import { api } from '../../lib/api';
import { useApi } from '../../lib/hooks';
import {
  PageHeading,
  Loading,
  ErrorState,
  EmptyState,
  Notice,
  Modal,
  StatusBadge,
} from '../../components/ui';

const emptyCategory = { name: '', image: '', active: true };
const describeError = (error) =>
  error.errors?.length
    ? error.errors
        .map((item) => `${item.field ? `${item.field}: ` : ''}${item.message}`)
        .join(' · ')
    : error.message;
const imageFallback = (event) => {
  if (!event.currentTarget.src.endsWith('/placeholder.svg'))
    event.currentTarget.src = '/placeholder.svg';
};

export default function Categories() {
  const { data, loading, error, reload } = useApi('/merchant/categories');
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyCategory);
  const [deactivating, setDeactivating] = useState(null);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formError, setFormError] = useState('');
  const [actionError, setActionError] = useState('');
  const [notice, setNotice] = useState('');
  const categories = data?.categories || [];
  const filtered = categories.filter(
    (category) =>
      (!search.trim() ||
        `${category.name} ${category.slug}`.toLowerCase().includes(search.trim().toLowerCase())) &&
      (!status || category.active === (status === 'active')),
  );

  const openEditor = (category) => {
    setEditing(category || {});
    setForm(
      category
        ? { name: category.name, image: category.image || '', active: category.active }
        : { ...emptyCategory },
    );
    setFormError('');
    setNotice('');
  };
  const closeEditor = () => {
    if (!busy && !uploading) setEditing(null);
  };
  const uploadImage = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(file.type)) {
      setFormError('Choose a JPG, PNG, WEBP, or GIF image.');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setFormError('Choose an image smaller than 5 MB.');
      return;
    }
    setUploading(true);
    setFormError('');
    try {
      const body = new FormData();
      body.append('images', file);
      const result = await api('/merchant/uploads', { method: 'POST', body });
      if (!result.images?.[0])
        throw new Error('No image URL was returned. Please try the upload again.');
      setForm((current) => ({ ...current, image: result.images[0] }));
    } catch (err) {
      setFormError(describeError(err));
    } finally {
      setUploading(false);
    }
  };
  const saveCategory = async (event) => {
    event.preventDefault();
    if (!form.name.trim()) {
      setFormError('Enter a category name.');
      return;
    }
    setBusy(true);
    setFormError('');
    try {
      const body = { name: form.name.trim(), image: form.image.trim(), active: form.active };
      await api(`/merchant/categories${editing._id ? `/${editing._id}` : ''}`, {
        method: editing._id ? 'PATCH' : 'POST',
        body,
      });
      setNotice(
        editing._id
          ? 'Category updated. Your catalog reflects its current visibility.'
          : 'Category created. You can now assign products to it.',
      );
      setEditing(null);
      reload();
    } catch (err) {
      setFormError(describeError(err));
    } finally {
      setBusy(false);
    }
  };
  const deactivateCategory = async () => {
    setBusy(true);
    setActionError('');
    try {
      await api(`/merchant/categories/${deactivating._id}`, { method: 'DELETE' });
      setNotice(
        `${deactivating.name} was deactivated. Its products are hidden from your public catalog.`,
      );
      setDeactivating(null);
      reload();
    } catch (err) {
      setActionError(describeError(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page-stack">
      <PageHeading
        title="Product categories"
        description="Make it easy for customers to find exactly what they need."
      >
        <button className="button button-primary" onClick={() => openEditor(null)}>
          <Plus size={17} /> Add category
        </button>
      </PageHeading>
      <Notice>{notice}</Notice>
      <section className="panel">
        <div className="toolbar">
          <div className="search-input">
            <Search size={17} />
            <input
              aria-label="Search categories"
              placeholder="Search categories…"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>
          <select
            className="input filter-select"
            aria-label="Category status"
            value={status}
            onChange={(event) => setStatus(event.target.value)}
          >
            <option value="">Any status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !filtered.length ? (
          <EmptyState
            title={
              categories.length ? 'No matching categories' : 'Give your catalog some structure'
            }
            description={
              categories.length
                ? 'Try another name or clear the status filter.'
                : 'Create your first category to group similar products together.'
            }
          >
            {!categories.length && (
              <button className="button button-primary" onClick={() => openEditor(null)}>
                <Plus size={16} /> Add category
              </button>
            )}
          </EmptyState>
        ) : (
          <>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Category</th>
                    <th>Catalog slug</th>
                    <th>Status</th>
                    <th>
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((category) => (
                    <tr key={category._id}>
                      <td>
                        <div className="product-cell">
                          <img
                            className="product-image"
                            src={category.image || '/placeholder.svg'}
                            alt=""
                            onError={imageFallback}
                          />
                          <span>
                            <strong>{category.name}</strong>
                            <small>Product category</small>
                          </span>
                        </div>
                      </td>
                      <td>
                        <span className="muted">{category.slug}</span>
                      </td>
                      <td>
                        <StatusBadge status={category.active ? 'active' : 'inactive'} />
                      </td>
                      <td>
                        <div className="row-actions">
                          <button
                            className="icon-button"
                            aria-label={`Edit ${category.name}`}
                            title={`Edit ${category.name}`}
                            onClick={() => openEditor(category)}
                          >
                            <Pencil size={16} />
                          </button>
                          {category.active && (
                            <button
                              className="icon-button"
                              aria-label={`Deactivate ${category.name}`}
                              title={`Deactivate ${category.name}`}
                              onClick={() => {
                                setDeactivating(category);
                                setActionError('');
                                setNotice('');
                              }}
                            >
                              <Trash2 size={16} />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="table-footer">
              {filtered.length} {filtered.length === 1 ? 'category' : 'categories'}
              <span>
                {categories.filter((category) => category.active).length} active in your catalog
              </span>
            </div>
          </>
        )}
      </section>
      <Modal
        open={Boolean(editing)}
        title={editing?._id ? 'Edit category' : 'Add category'}
        onClose={closeEditor}
      >
        <form className="page-stack" onSubmit={saveCategory}>
          <Notice type="error">{formError}</Notice>
          <div className="field">
            <label htmlFor="category-name">
              Category name <span>*</span>
            </label>
            <input
              className="input"
              id="category-name"
              autoComplete="off"
              required
              maxLength={100}
              value={form.name}
              onChange={(event) => setForm((current) => ({ ...current, name: event.target.value }))}
              disabled={busy}
              placeholder="e.g. Grains & cereals"
            />
            <small>The catalog slug is generated automatically from this name.</small>
          </div>
          <div className="field">
            <label htmlFor="category-image">
              Category image <span className="muted">(optional)</span>
            </label>
            {form.image && (
              <div className="image-grid">
                <div className="uploaded-image">
                  <img src={form.image} alt="Category preview" onError={imageFallback} />
                  <button
                    type="button"
                    className="remove-image"
                    aria-label="Remove category image"
                    onClick={() => setForm((current) => ({ ...current, image: '' }))}
                    disabled={busy || uploading}
                  >
                    <X size={14} />
                  </button>
                </div>
              </div>
            )}
            <label className={`upload-zone ${uploading ? 'disabled' : ''}`}>
              <ImagePlus size={24} />
              <strong>
                {uploading
                  ? 'Uploading image…'
                  : form.image
                    ? 'Replace category image'
                    : 'Choose a category image'}
              </strong>
              <span>JPG, PNG, WEBP, or GIF · up to 5 MB</span>
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp,image/gif"
                onChange={uploadImage}
                disabled={busy || uploading}
              />
            </label>
            <input
              id="category-image"
              className="input"
              placeholder="Or paste an image URL"
              maxLength={1500}
              value={form.image}
              onChange={(event) =>
                setForm((current) => ({ ...current, image: event.target.value }))
              }
              disabled={busy || uploading}
            />
            <small>Uploads use your configured Cloudinary account.</small>
          </div>
          <label className="checkbox-field">
            <input
              type="checkbox"
              checked={form.active}
              onChange={(event) =>
                setForm((current) => ({ ...current, active: event.target.checked }))
              }
              disabled={busy}
            />
            <span>
              <strong>Active category</strong>
              <small>Show this category and its active products in your public catalog.</small>
            </span>
          </label>
          {!form.active && (
            <p className="muted small-text">
              This category and all products assigned to it will stay hidden from customers.
              Inventory and history are preserved.
            </p>
          )}
          <div className="form-actions">
            <button
              className="button button-secondary"
              type="button"
              onClick={closeEditor}
              disabled={busy || uploading}
            >
              Cancel
            </button>
            <button
              className="button button-primary"
              type="submit"
              disabled={busy || uploading || !form.name.trim()}
            >
              {busy ? 'Saving…' : editing?._id ? 'Save category' : 'Create category'}
            </button>
          </div>
        </form>
      </Modal>
      <Modal
        open={Boolean(deactivating)}
        title="Deactivate category?"
        onClose={() => {
          if (!busy) setDeactivating(null);
        }}
      >
        <p className="modal-copy">
          <strong>{deactivating?.name}</strong> and every product assigned to it will be hidden from
          your public catalog. Products, inventory, and history will be preserved. To restore
          visibility later, edit the category and turn on <strong>Active category</strong>.
        </p>
        <Notice type="error">{actionError}</Notice>
        <div className="form-actions">
          <button
            className="button button-secondary"
            disabled={busy}
            onClick={() => setDeactivating(null)}
          >
            Cancel
          </button>
          <button className="button button-danger" disabled={busy} onClick={deactivateCategory}>
            {busy ? 'Saving…' : 'Deactivate category'}
          </button>
        </div>
      </Modal>
    </div>
  );
}
