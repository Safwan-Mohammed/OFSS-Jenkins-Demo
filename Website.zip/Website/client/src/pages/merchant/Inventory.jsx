import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ArrowDownLeft, ArrowUpRight, ClipboardList, Download, Plus, Search } from 'lucide-react';
import { api, downloadCsv, formatDate, number } from '../../lib/api';
import { useApi } from '../../lib/hooks';
import {
  EmptyState,
  ErrorState,
  Loading,
  Modal,
  Notice,
  PageHeading,
  ProductImage,
  StatCard,
} from '../../components/ui';

export default function Inventory() {
  const [params] = useSearchParams();
  const [open, setOpen] = useState(!!params.get('product'));
  const [productId, setProductId] = useState(params.get('product') || '');
  const [direction, setDirection] = useState('in');
  const [quantity, setQuantity] = useState('');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [search, setSearch] = useState('');
  const history = useApi('/merchant/inventory');
  const products = useApi('/merchant/products');
  const transactions = history.data?.transactions || [];
  const filtered = transactions.filter((t) =>
    `${t.product?.name || ''} ${t.reason || ''}`.toLowerCase().includes(search.toLowerCase()),
  );
  const selected = products.data?.products?.find((p) => p._id === productId);
  const adjust = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api('/merchant/inventory', {
        method: 'POST',
        body: {
          productId,
          quantityChange: Number(quantity) * (direction === 'in' ? 1 : -1),
          reason,
        },
      });
      setOpen(false);
      setQuantity('');
      setReason('');
      setSuccess('Stock updated. Your adjustment has been saved to inventory history.');
      history.reload();
      products.reload();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };
  const download = () =>
    downloadCsv('supplylane-inventory.csv', [
      ['Date', 'Product', 'Change', 'Reason', 'Updated by'],
      ...filtered.map((t) => [
        formatDate(t.createdAt || t.timestamp),
        t.product?.name,
        t.quantityChange,
        t.reason,
        t.updatedBy?.name,
      ]),
    ]);
  return (
    <div className="page-stack">
      <PageHeading
        title="Every unit, accounted for"
        description="Update stock with confidence. Every adjustment leaves a clear trail."
      >
        <button
          className="button button-secondary"
          disabled={!transactions.length}
          onClick={download}
        >
          <Download size={16} />
          Export history
        </button>
        <button
          className="button button-primary"
          onClick={() => {
            setError('');
            setOpen(true);
          }}
        >
          <Plus size={17} />
          Adjust stock
        </button>
      </PageHeading>
      <Notice>{success}</Notice>
      <div className="stats-grid three-stats">
        <StatCard
          label="Units on hand"
          value={number(products.data?.products?.reduce((sum, p) => sum + p.stock, 0) || 0)}
          icon={ClipboardList}
          note="Across your full catalog"
        />
        <StatCard
          label="Units added"
          value={number(transactions.reduce((sum, t) => sum + Math.max(0, t.quantityChange), 0))}
          icon={ArrowDownLeft}
          note="In the loaded inventory history"
        />
        <StatCard
          label="Units removed"
          value={number(transactions.reduce((sum, t) => sum + Math.max(0, -t.quantityChange), 0))}
          icon={ArrowUpRight}
          note="In the loaded inventory history"
        />
      </div>
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h2>Inventory history</h2>
            <p>A transparent record of every stock change.</p>
          </div>
          <div className="search-input">
            <Search size={17} />
            <input
              aria-label="Search inventory history"
              placeholder="Search product or reason…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
        {history.loading ? (
          <Loading />
        ) : history.error ? (
          <ErrorState error={history.error} onRetry={history.reload} />
        ) : !filtered.length ? (
          <EmptyState
            title="No stock changes to show"
            description="Inventory adjustments will appear here with a reason and who made the change."
          />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>PRODUCT</th>
                  <th>QUANTITY CHANGE</th>
                  <th>REASON</th>
                  <th>UPDATED BY</th>
                  <th>DATE & TIME</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((t) => (
                  <tr key={t._id}>
                    <td>
                      <div className="product-cell">
                        <ProductImage product={t.product} />
                        <span>
                          <strong>{t.product?.name || 'Archived product'}</strong>
                          <small>{t.product?.sku}</small>
                        </span>
                      </div>
                    </td>
                    <td>
                      <span
                        className={`stock-change ${t.quantityChange > 0 ? 'positive' : 'negative'}`}
                      >
                        {t.quantityChange > 0 ? '+' : ''}
                        {number(t.quantityChange)} {t.product?.unit}
                      </span>
                    </td>
                    <td className="reason-cell">{t.reason}</td>
                    <td>{t.updatedBy?.name || 'Merchant'}</td>
                    <td className="nowrap muted">{formatDate(t.createdAt || t.timestamp)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
      <Modal open={open} title="Adjust inventory" onClose={() => !busy && setOpen(false)}>
        <form onSubmit={adjust}>
          <Notice type="error">{error || products.error?.message}</Notice>
          <div className="field">
            <label htmlFor="inventory-product">Product</label>
            <select
              id="inventory-product"
              className="input"
              required
              value={productId}
              onChange={(e) => setProductId(e.target.value)}
            >
              <option value="">Choose a product</option>
              {products.data?.products?.map((p) => (
                <option key={p._id} value={p._id}>
                  {p.name} — {p.stock} {p.unit}
                </option>
              ))}
            </select>
          </div>
          {selected && (
            <div className="inventory-current">
              Currently on hand{' '}
              <strong>
                {number(selected.stock)} {selected.unit}
              </strong>
            </div>
          )}
          <div className="form-grid">
            <div className="field">
              <label htmlFor="inventory-direction">Adjustment</label>
              <select
                id="inventory-direction"
                className="input"
                value={direction}
                onChange={(e) => setDirection(e.target.value)}
              >
                <option value="in">Add stock</option>
                <option value="out">Reduce stock</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="inventory-quantity">Quantity</label>
              <input
                id="inventory-quantity"
                className="input"
                required
                type="number"
                step="1"
                min="1"
                max={direction === 'out' ? selected?.stock : 100000000}
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
            </div>
          </div>
          <div className="field">
            <label htmlFor="inventory-reason">Reason</label>
            <textarea
              className="input"
              id="inventory-reason"
              required
              minLength={3}
              maxLength={400}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
              placeholder="e.g. Received stock from supplier, confirmed customer order…"
            />
          </div>
          <p className="muted small-text">
            Your name, reason, and time of change are recorded automatically.
          </p>
          <div className="form-actions">
            <button
              type="button"
              className="button button-secondary"
              disabled={busy}
              onClick={() => setOpen(false)}
            >
              Cancel
            </button>
            <button className="button button-primary" disabled={busy || !selected}>
              {busy ? 'Updating…' : 'Update stock'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
