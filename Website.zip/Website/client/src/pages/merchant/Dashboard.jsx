import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  ArrowDownToLine,
  ArrowRight,
  ArrowUpRight,
  Box,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  Copy,
  Eye,
  Leaf,
  Link2,
  MessageCircle,
  Package,
  Plus,
  ShoppingBag,
  ShoppingCart,
  Sun,
  TrendingUp,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useApi } from '../../lib/hooks';
import { downloadCsv, formatDate, money, number } from '../../lib/api';
import {
  EmptyState,
  ErrorState,
  Loading,
  PageHeading,
  ProductImage,
  StatCard,
  StatusBadge,
} from '../../components/ui';

export function ActivityChart({ series = [], detailed = false }) {
  return (
    <div className="activity-chart">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={series} margin={{ top: 14, right: 12, left: -22, bottom: 0 }}>
          <defs>
            <linearGradient id="viewsFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#729981" stopOpacity={0.22} />
              <stop offset="95%" stopColor="#729981" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 5" vertical={false} stroke="#e8ebe6" />
          <XAxis
            dataKey="date"
            tickLine={false}
            axisLine={false}
            minTickGap={48}
            tick={{ fill: '#8a928b', fontSize: 11 }}
            tickFormatter={(date) =>
              new Date(date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
            }
          />
          <YAxis
            allowDecimals={false}
            tickLine={false}
            axisLine={false}
            tick={{ fill: '#8a928b', fontSize: 11 }}
          />
          <Tooltip
            contentStyle={{ border: '1px solid #e4e8df', borderRadius: 12, fontSize: 12 }}
            labelFormatter={(date) =>
              new Date(date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
            }
          />
          <Area
            isAnimationActive={false}
            name="Product views"
            type="monotone"
            dataKey="views"
            stroke="#537e63"
            fill="url(#viewsFill)"
            strokeWidth={2.4}
          />
          <Area
            isAnimationActive={false}
            name="Order requests"
            type="monotone"
            dataKey="checkouts"
            stroke="#d3ab66"
            fill="transparent"
            strokeWidth={2.2}
          />
          {detailed && (
            <Area
              isAnimationActive={false}
              name="Cart additions"
              type="monotone"
              dataKey="carts"
              stroke="#97a1c0"
              fill="transparent"
              strokeWidth={2}
            />
          )}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function InventoryHealth({ stats }) {
  const total = stats.totalProducts || 0;
  const healthy = Math.max(0, total - stats.lowStock - stats.outOfStock);
  const percent = total ? Math.round((healthy / total) * 100) : 0;
  return (
    <section className="panel health-panel">
      <div className="panel-heading">
        <h2>Inventory health</h2>
        <span className="small-label">Live status</span>
      </div>
      <div className="health-chart">
        <svg
          viewBox="0 0 180 180"
          role="img"
          aria-label={`${percent}% of products have healthy stock`}
        >
          <circle cx="90" cy="90" r="68" fill="none" stroke="#f0f1ec" strokeWidth="17" />
          <circle
            cx="90"
            cy="90"
            r="68"
            fill="none"
            stroke="#558064"
            strokeWidth="17"
            strokeDasharray={`${(healthy / (total || 1)) * 427.3} 427.3`}
            transform="rotate(-90 90 90)"
          />
          <circle
            cx="90"
            cy="90"
            r="68"
            fill="none"
            stroke="#d3aa67"
            strokeWidth="17"
            strokeDasharray={`${(stats.lowStock / (total || 1)) * 427.3} 427.3`}
            strokeDashoffset={(-healthy / (total || 1)) * 427.3}
            transform="rotate(-90 90 90)"
          />
          <circle
            cx="90"
            cy="90"
            r="68"
            fill="none"
            stroke="#cf7e68"
            strokeWidth="17"
            strokeDasharray={`${(stats.outOfStock / (total || 1)) * 427.3} 427.3`}
            strokeDashoffset={(-(healthy + stats.lowStock) / (total || 1)) * 427.3}
            transform="rotate(-90 90 90)"
          />
        </svg>
        <div className="health-center">
          <strong>
            {percent}
            <small>%</small>
          </strong>
          <span>healthy stock</span>
        </div>
      </div>
      <div className="health-legend">
        <Link to="/products?stock=in">
          <span className="legend-dot green" />
          In stock<strong>{healthy}</strong>
        </Link>
        <Link to="/products?stock=low">
          <span className="legend-dot gold" />
          Low stock<strong>{stats.lowStock}</strong>
        </Link>
        <Link to="/products?stock=out">
          <span className="legend-dot rust" />
          Out of stock<strong>{stats.outOfStock}</strong>
        </Link>
      </div>
    </section>
  );
}

export default function Dashboard({ analytics = false }) {
  const { user, shop, config } = useAuth();
  const [days, setDays] = useState('30');
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState('');
  const { data, loading, error, reload } = useApi(
    `/merchant/${analytics ? 'analytics' : 'dashboard'}?days=${days}`,
  );
  if (loading) return <Loading />;
  if (error) return <ErrorState error={error} onRetry={reload} />;
  const stats = data.stats;
  const series = data.series || [];
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/shop/${shop.slug}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopyError('Open your storefront and copy its URL from the address bar.');
    }
  };
  const exportStats = () =>
    downloadCsv('supplylane-analytics.csv', [
      ['Date', 'Product views', 'Cart additions', 'WhatsApp requests'],
      ...series.map((row) => [row.date, row.views, row.carts, row.checkouts]),
    ]);
  const greeting =
    new Date().getHours() < 12
      ? 'Good morning'
      : new Date().getHours() < 17
        ? 'Good afternoon'
        : 'Good evening';
  return (
    <div className="page-stack dashboard-page">
      <PageHeading
        title={
          analytics ? (
            'A closer look at your business'
          ) : (
            <>
              {greeting}, {user?.name?.split(' ')[0]} <Sun className="greeting-sun" size={26} />
            </>
          )
        }
        description={
          analytics
            ? 'See what catches attention and turns into an order request.'
            : 'Here’s what’s happening with your wholesale business today.'
        }
      >
        <label className="date-select">
          <CalendarDays size={16} />
          <select
            aria-label="Analytics period"
            value={days}
            onChange={(e) => setDays(e.target.value)}
          >
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
          </select>
          <ChevronDown size={14} />
        </label>
        <button className="button button-secondary export-button" onClick={exportStats}>
          <ArrowDownToLine size={16} />
          Export
        </button>
      </PageHeading>
      {!analytics && (
        <div className="shop-live-banner">
          <div className="live-banner-icon">
            <StoreIcon />
          </div>
          <div>
            <strong>
              Your storefront is open for business{' '}
              <span className="live-label">
                <span />
                LIVE
              </span>
            </strong>
            <p>Good products deserve to be found. Share your catalog with your customers.</p>
          </div>
          <button className="button button-white" onClick={copy}>
            {copied ? <Check size={16} /> : <Link2 size={16} />}{' '}
            {copied ? 'Link copied' : 'Copy shop link'}
          </button>
        </div>
      )}
      {copyError && (
        <p role="status" className="muted">
          {copyError}
        </p>
      )}
      <div className="stats-grid">
        <StatCard
          label="Total products"
          value={number(stats.totalProducts)}
          icon={Package}
          note={
            <>
              <span className="stat-context green-text">
                <CheckCircle2 size={12} />
                Your complete catalog
              </span>
              <Link to="/products">
                <ArrowUpRight size={15} />
              </Link>
            </>
          }
        />
        <StatCard
          label="Inventory on hand"
          value={number(stats.totalInventory)}
          icon={Box}
          note={
            <>
              <span className="stat-context">Units across all products</span>
              <Link to="/inventory">
                <ArrowUpRight size={15} />
              </Link>
            </>
          }
        />
        <StatCard
          label="Product views"
          value={number(stats.productViews)}
          icon={Eye}
          note={
            <>
              <span className="stat-context green-text">
                <TrendingUp size={13} />
                In the last {days} days
              </span>
              <Link to="/analytics">
                <ArrowUpRight size={15} />
              </Link>
            </>
          }
        />
        <StatCard
          label="WhatsApp requests"
          value={number(stats.checkoutRequests)}
          icon={MessageCircle}
          accent="stat-highlight"
          note={
            <>
              <span className="stat-context">Conversations that count</span>
              <Link to="/orders">
                <ArrowUpRight size={15} />
              </Link>
            </>
          }
        />
      </div>
      <div className="dashboard-chart-grid">
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Catalog activity</h2>
              <p>A little visibility goes a long way.</p>
            </div>
            <div className="chart-legend">
              <span>
                <i className="legend-dot green" />
                Product views
              </span>
              <span>
                <i className="legend-dot gold" />
                Order requests
              </span>
            </div>
          </div>
          <ActivityChart series={series} detailed={analytics} />
          <div className="chart-footer">
            <span>
              <Leaf size={15} /> Every visit is a new opportunity.
            </span>
            <span>
              {number(stats.cartAdditions)} cart additions <ShoppingCart size={14} />
            </span>
          </div>
        </section>
        <InventoryHealth stats={stats} />
      </div>
      <div className="dashboard-bottom-grid">
        <section className="panel popular-panel">
          <div className="panel-heading">
            <div>
              <h2>{analytics ? 'Most requested products' : 'Your most viewed products'}</h2>
              <p>
                {analytics
                  ? 'The products your customers are asking for.'
                  : 'A few favorites getting all the attention.'}
              </p>
            </div>
            <Link className="text-link" to="/products">
              All products <ArrowRight size={15} />
            </Link>
          </div>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>PRODUCT</th>
                  <th>PRICE</th>
                  <th>{analytics ? 'UNITS REQUESTED' : 'VIEWS'}</th>
                  <th>STOCK</th>
                </tr>
              </thead>
              <tbody>
                {(analytics ? data.mostRequested : data.mostViewed)
                  ?.slice(0, 5)
                  .map((item, index) => {
                    const p = item.product;
                    if (!p) return null;
                    return (
                      <tr key={p._id || index}>
                        <td>
                          <Link to={`/products/${p._id}/edit`} className="product-cell">
                            <ProductImage product={p} />
                            <span>
                              <strong>{p.name}</strong>
                              <small>{p.category?.name || p.unit}</small>
                            </span>
                          </Link>
                        </td>
                        <td>
                          {money(p.price)}
                          <small className="cell-unit"> / {p.unit}</small>
                        </td>
                        <td>
                          <span className="view-count">
                            <Eye size={13} />
                            {number(item.count)}
                          </span>
                        </td>
                        <td>
                          <StatusBadge
                            status={
                              p.stock === 0
                                ? 'Out of stock'
                                : p.stock <= p.minStock
                                  ? 'Low stock'
                                  : 'In stock'
                            }
                          />
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
          {!(analytics ? data.mostRequested : data.mostViewed)?.length && (
            <EmptyState
              title="Your next bestseller starts here"
              description="Product activity will appear as customers explore your catalog."
            />
          )}
        </section>
        <div className="dashboard-side-stack">
          <section className="panel stock-alert-panel">
            <div className="panel-heading">
              <h2>Time for a restock</h2>
              <span className="count-bubble">{stats.lowStock + stats.outOfStock}</span>
            </div>
            <p className="muted compact">A quick check keeps your shelves ready.</p>
            <div className="restock-list">
              {data.lowStockProducts?.slice(0, 3).map((p) => (
                <Link key={p._id} to={`/inventory?product=${p._id}`}>
                  <ProductImage product={p} />
                  <span>
                    <strong>{p.name}</strong>
                    <small className={p.stock === 0 ? 'rust-text' : 'gold-text'}>
                      {p.stock === 0 ? 'Out of stock' : `${p.stock} ${p.unit} left`}
                    </small>
                  </span>
                  <ArrowUpRight size={15} />
                </Link>
              ))}
              {!data.lowStockProducts?.length && (
                <p className="muted">All stocked up. You’re ready for business.</p>
              )}
            </div>
            <Link className="button button-secondary full-width" to="/inventory">
              Manage inventory <ArrowRight size={15} />
            </Link>
          </section>
          <Link className="add-product-card" to="/products/new">
            <span className="add-product-icon">
              <Plus size={20} />
            </span>
            <span>
              <strong>Room for something new?</strong>
              <small>Add your next great product.</small>
            </span>
            <ArrowUpRight size={18} />
          </Link>
        </div>
      </div>
      {analytics && (
        <section className="panel">
          <div className="panel-heading">
            <h2>Customer journey</h2>
            <span className="muted">Last {days} days</span>
          </div>
          <div className="journey-grid">
            <div>
              <Eye />
              <strong>{number(stats.productViews)}</strong>
              <span>Product views</span>
            </div>
            <ArrowRight />
            <div>
              <ShoppingCart />
              <strong>{number(stats.cartAdditions)}</strong>
              <span>Cart additions</span>
            </div>
            <ArrowRight />
            <div>
              <MessageCircle />
              <strong>{number(stats.checkoutRequests)}</strong>
              <span>WhatsApp requests</span>
            </div>
          </div>
          <p className="panel-footnote">
            Activity counts include repeat actions. Requests are customer intent; they do not
            indicate confirmed sales or payments.
          </p>
        </section>
      )}
    </div>
  );
}
function StoreIcon() {
  return <ShoppingBag size={23} strokeWidth={1.6} />;
}
