import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowUpRight,
  Check,
  ImagePlus,
  Leaf,
  LoaderCircle,
  Save,
  Store,
  Trash2,
  Upload,
} from 'lucide-react';
import { PageHeading, Loading, ErrorState, Notice } from '../../components/ui';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../lib/api';
import { useApi } from '../../lib/hooks';

const validPhone = (value) =>
  /^[+\d\s()-]+$/.test(value) &&
  value.replace(/\D/g, '').length >= 8 &&
  value.replace(/\D/g, '').length <= 15;
const validImage = (value) =>
  !value || /^https?:\/\/[^\s]+$/i.test(value) || /^\/(?!\/)[\w/.,%()@-]+$/.test(value);
const shopForm = (shop) => ({
  name: shop.name || '',
  slug: shop.slug || '',
  description: shop.description || '',
  logo: shop.logo || '',
  banner: shop.banner || '',
  address: shop.address || '',
  phone: shop.phone || '',
  whatsapp: shop.whatsapp || '',
  businessHours: shop.businessHours || '',
  theme: { primary: shop.theme?.primary || '#28624e' },
});

function ImageSetting({ kind, value, onChange, onUpload, uploading, disabled }) {
  const input = useRef(null);
  const [failed, setFailed] = useState(false);
  const title = kind === 'logo' ? 'Shop logo' : 'Shop banner';
  useEffect(() => setFailed(false), [value]);
  return (
    <div className="field" style={{ minWidth: 0 }}>
      <label htmlFor={`shop-${kind}-url`}>{title}</label>
      <div
        style={{
          display: 'flex',
          flexDirection: kind === 'banner' ? 'column' : 'row',
          gap: 16,
          alignItems: kind === 'banner' ? 'stretch' : 'center',
          marginBottom: 12,
        }}
      >
        <div
          style={{
            width: kind === 'logo' ? 88 : '100%',
            height: kind === 'logo' ? 88 : 154,
            minWidth: kind === 'logo' ? 88 : undefined,
            borderRadius: 12,
            overflow: 'hidden',
            border: '1px solid var(--border, #e3e8df)',
            background: '#f1f5ed',
            display: 'grid',
            placeItems: 'center',
            color: '#7d9671',
          }}
        >
          {value && !failed ? (
            <img
              src={value}
              alt={`${title} preview`}
              style={{
                width: '100%',
                height: '100%',
                objectFit: kind === 'logo' ? 'contain' : 'cover',
              }}
              onError={() => setFailed(true)}
            />
          ) : (
            <ImagePlus size={28} strokeWidth={1.4} />
          )}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 9 }}>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button
              type="button"
              className="button button-secondary"
              disabled={disabled}
              onClick={() => input.current?.click()}
            >
              {uploading ? <LoaderCircle size={15} className="spin" /> : <Upload size={15} />}
              {uploading ? 'Uploading…' : `Upload ${kind}`}
            </button>
            {value && (
              <button
                type="button"
                className="button button-secondary"
                disabled={disabled}
                onClick={() => onChange('')}
                aria-label={`Remove ${title.toLowerCase()}`}
              >
                <Trash2 size={15} />
                Remove
              </button>
            )}
          </div>
          <small className="muted" style={{ fontSize: 11 }}>
            JPG, PNG, WebP, or GIF · up to 5 MB
            {kind === 'logo' ? ' · square works best' : ' · landscape works best'}
          </small>
        </div>
      </div>
      <input
        ref={input}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/gif"
        hidden
        disabled={disabled}
        aria-label={`Upload ${title.toLowerCase()}`}
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = '';
          if (file) onUpload(file);
        }}
      />
      <input
        id={`shop-${kind}-url`}
        className="input"
        type="text"
        value={value}
        maxLength={1500}
        placeholder="Or paste an image URL"
        disabled={disabled}
        onChange={(event) => onChange(event.target.value)}
      />
      {failed && (
        <small style={{ color: '#a86144' }}>
          The image could not be previewed. Check its address or upload a new image.
        </small>
      )}
    </div>
  );
}

export default function Settings() {
  const { data, loading, error, reload, setData } = useApi('/merchant/shop');
  const { refresh } = useAuth();
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState('');
  const [notice, setNotice] = useState({ type: 'success', message: '' });
  const saveLock = useRef(false);
  useEffect(() => {
    if (data?.shop) setForm(shopForm(data.shop));
  }, [data]);
  const busy = saving || Boolean(uploading);
  function change(field, value) {
    setForm((current) => ({ ...current, [field]: value }));
    setNotice({ type: 'success', message: '' });
  }
  async function uploadImage(kind, file) {
    if (busy) return;
    if (!['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(file.type)) {
      setNotice({ type: 'error', message: 'Choose a JPG, PNG, WebP, or GIF image.' });
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setNotice({
        type: 'error',
        message: 'Images must be 5 MB or smaller. Choose a smaller file and try again.',
      });
      return;
    }
    setUploading(kind);
    setNotice({ type: 'success', message: '' });
    try {
      const body = new FormData();
      body.append('images', file);
      const result = await api('/merchant/uploads', { method: 'POST', body });
      if (!result.images?.[0])
        throw new Error('The upload did not return an image. Please try again.');
      setForm((current) => ({ ...current, [kind]: result.images[0] }));
      setNotice({
        type: 'success',
        message: `${kind === 'logo' ? 'Logo' : 'Banner'} uploaded. Save changes to publish it to your shop.`,
      });
    } catch (caught) {
      setNotice({
        type: 'error',
        message:
          caught.status === 503
            ? 'Image uploads are not configured yet. Ask your platform administrator to enable Cloudinary, or enter a hosted image URL below. You can still save your other shop details.'
            : caught.message,
      });
    } finally {
      setUploading('');
    }
  }
  async function save(event) {
    event.preventDefault();
    if (busy || saveLock.current) return;
    const payload = Object.fromEntries(
      Object.entries(form).map(([key, value]) => [
        key,
        typeof value === 'string' ? value.trim() : value,
      ]),
    );
    payload.theme = { primary: form.theme.primary.trim() };
    let message = '';
    if (!payload.name) message = 'Enter your shop name.';
    else if (
      payload.slug.length < 3 ||
      payload.slug.length > 90 ||
      !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(payload.slug)
    )
      message =
        'Your shop address must be 3–90 characters, using lowercase letters, numbers, and single hyphens between words.';
    else if (!validPhone(payload.whatsapp))
      message = 'Enter your WhatsApp business number, including country code, with 8–15 digits.';
    else if (payload.phone && !validPhone(payload.phone))
      message = 'Your contact number must contain 8–15 digits, or leave it empty.';
    else if (!/^#[a-f0-9]{6}$/i.test(payload.theme.primary))
      message = 'Enter a six-digit hex color, for example #28624e.';
    else if (!validImage(payload.logo) || !validImage(payload.banner))
      message = 'Use an HTTP or HTTPS image URL, or a valid local image path starting with /.';
    if (message) {
      setNotice({ type: 'error', message });
      return;
    }
    saveLock.current = true;
    setSaving(true);
    setNotice({ type: 'success', message: '' });
    try {
      const result = await api('/merchant/shop', { method: 'PATCH', body: payload });
      setData(result);
      setForm(shopForm(result.shop));
      try {
        await refresh();
        setNotice({
          type: 'success',
          message: 'Your shop settings have been saved and are live on your storefront.',
        });
      } catch {
        setNotice({
          type: 'success',
          message:
            'Your shop settings were saved. Refresh this page to update your workspace header.',
        });
      }
    } catch (caught) {
      setNotice({ type: 'error', message: caught.message });
    } finally {
      setSaving(false);
      saveLock.current = false;
    }
  }
  if (loading || (!form && !error)) return <Loading />;
  if (error) return <ErrorState error={error} onRetry={reload} />;
  const currentShop = data.shop;
  const previewPath = `/shop/${currentShop.slug}`;
  const previewColor = /^#[a-f0-9]{6}$/i.test(form.theme.primary) ? form.theme.primary : '#28624e';
  const modified = JSON.stringify(form) !== JSON.stringify(shopForm(currentShop));
  const placeholderNumber = form.whatsapp.replace(/\D/g, '') === '919000000000';
  return (
    <div className="page-stack">
      <PageHeading
        title="Shop settings"
        description="Make your storefront feel like your business."
      >
        <Link
          to={previewPath}
          target="_blank"
          rel="noopener noreferrer"
          className="button button-secondary"
        >
          View storefront <ArrowUpRight size={15} />
        </Link>
      </PageHeading>
      <Notice type={notice.type}>{notice.message}</Notice>
      {placeholderNumber && (
        <Notice type="info">
          This shop currently uses a demo WhatsApp number. Replace it with your own business number
          before sharing your catalog with customers.
        </Notice>
      )}
      <form onSubmit={save} className="page-stack">
        <section className="panel form-panel">
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 25 }}>
            <span
              style={{
                width: 37,
                height: 37,
                display: 'grid',
                placeItems: 'center',
                borderRadius: 10,
                background: '#edf3e7',
                color: '#507345',
              }}
            >
              <Store size={18} />
            </span>
            <div>
              <h2 style={{ margin: 0, fontSize: 16 }}>The essentials</h2>
              <p className="muted" style={{ margin: '5px 0 0', fontSize: 12 }}>
                Introduce your business and choose your shop address.
              </p>
            </div>
          </div>
          <div className="form-grid">
            <div className="field">
              <label htmlFor="shop-name">
                Shop name <span aria-hidden="true">*</span>
              </label>
              <input
                id="shop-name"
                className="input"
                value={form.name}
                required
                maxLength={120}
                placeholder="e.g. Greenfield Wholesale"
                disabled={busy}
                onChange={(event) => change('name', event.target.value)}
              />
            </div>
            <div className="field">
              <label htmlFor="shop-slug">
                Shop address <span aria-hidden="true">*</span>
              </label>
              <input
                id="shop-slug"
                className="input"
                value={form.slug}
                required
                minLength={3}
                maxLength={90}
                pattern="[a-z0-9]+(-[a-z0-9]+)*"
                title="Lowercase letters and numbers, separated by single hyphens"
                placeholder="greenfield"
                disabled={busy}
                onChange={(event) => change('slug', event.target.value.toLowerCase())}
              />
              <small className="muted" style={{ overflowWrap: 'anywhere' }}>
                {window.location.origin}/shop/{form.slug || 'your-shop'}
              </small>
              {form.slug !== currentShop.slug && (
                <small style={{ color: '#a17443' }}>
                  Save to publish this new address. Links using your previous address will stop
                  working.
                </small>
              )}
            </div>
            <div className="field" style={{ gridColumn: '1 / -1' }}>
              <label htmlFor="shop-description">Shop description</label>
              <textarea
                id="shop-description"
                className="input"
                value={form.description}
                maxLength={3000}
                rows={4}
                placeholder="Tell customers what you stock and what makes your business different."
                disabled={busy}
                onChange={(event) => change('description', event.target.value)}
              />
              <small className="muted">
                This appears on your storefront. {form.description.length}/3,000 characters
              </small>
            </div>
          </div>
        </section>
        <section className="panel form-panel">
          <h2 style={{ margin: '0 0 7px', fontSize: 16 }}>Branding & appearance</h2>
          <p className="muted" style={{ margin: '0 0 26px', fontSize: 12 }}>
            A familiar look, from your shop sign to your online catalog.
          </p>
          <div className="form-grid" style={{ alignItems: 'start' }}>
            <ImageSetting
              kind="logo"
              value={form.logo}
              onChange={(value) => change('logo', value)}
              onUpload={(file) => uploadImage('logo', file)}
              uploading={uploading === 'logo'}
              disabled={busy}
            />
            <ImageSetting
              kind="banner"
              value={form.banner}
              onChange={(value) => change('banner', value)}
              onUpload={(file) => uploadImage('banner', file)}
              uploading={uploading === 'banner'}
              disabled={busy}
            />
            <div className="field">
              <label htmlFor="shop-color">Brand color</label>
              <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <input
                  type="color"
                  aria-label="Choose brand color"
                  value={previewColor}
                  disabled={busy}
                  style={{
                    width: 44,
                    height: 41,
                    padding: 3,
                    border: '1px solid #dfe6d8',
                    borderRadius: 7,
                    background: '#fff',
                    cursor: 'pointer',
                  }}
                  onChange={(event) => change('theme', { primary: event.target.value })}
                />
                <input
                  id="shop-color"
                  className="input"
                  value={form.theme.primary}
                  pattern="#[0-9a-fA-F]{6}"
                  maxLength={7}
                  required
                  placeholder="#28624e"
                  style={{ maxWidth: 150 }}
                  disabled={busy}
                  onChange={(event) => change('theme', { primary: event.target.value })}
                />
              </div>
              <small className="muted">Used for your storefront’s buttons and highlights.</small>
            </div>
            <div
              style={{
                alignSelf: 'end',
                padding: 17,
                borderRadius: 10,
                border: '1px solid #e3e8dd',
                background: '#fafcf7',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 9,
                  fontSize: 13,
                  fontWeight: 600,
                  color: previewColor,
                }}
              >
                <Leaf size={19} />
                {form.name || 'Your shop'}
              </div>
              <span
                style={{
                  display: 'inline-flex',
                  marginTop: 13,
                  padding: '9px 13px',
                  fontSize: 11,
                  borderRadius: 6,
                  background: previewColor,
                  color: '#fff',
                  gap: 7,
                  alignItems: 'center',
                }}
              >
                <Check size={13} />
                Your storefront color
              </span>
            </div>
          </div>
        </section>
        <section className="panel form-panel">
          <h2 style={{ margin: '0 0 7px', fontSize: 16 }}>Contact & ordering</h2>
          <p className="muted" style={{ margin: '0 0 26px', fontSize: 12 }}>
            Help customers reach you and send their order requests to the right place.
          </p>
          <div className="form-grid">
            <div className="field">
              <label htmlFor="shop-whatsapp">
                WhatsApp business number <span aria-hidden="true">*</span>
              </label>
              <input
                id="shop-whatsapp"
                className="input"
                type="tel"
                value={form.whatsapp}
                required
                maxLength={25}
                placeholder="e.g. +91 98765 43210"
                autoComplete="tel"
                disabled={busy}
                onChange={(event) => change('whatsapp', event.target.value)}
              />
              <small className="muted">
                Include your country code. Customer order requests go to this number.
              </small>
            </div>
            <div className="field">
              <label htmlFor="shop-phone">Contact phone</label>
              <input
                id="shop-phone"
                className="input"
                type="tel"
                value={form.phone}
                maxLength={25}
                placeholder="e.g. +91 98765 43210"
                autoComplete="tel"
                disabled={busy}
                onChange={(event) => change('phone', event.target.value)}
              />
              <small className="muted">
                Optional. Displayed in your shop’s contact information.
              </small>
            </div>
            <div className="field">
              <label htmlFor="shop-address">Business address</label>
              <textarea
                id="shop-address"
                className="input"
                value={form.address}
                maxLength={600}
                rows={3}
                autoComplete="street-address"
                placeholder="Street, area, city, and postal code"
                disabled={busy}
                onChange={(event) => change('address', event.target.value)}
              />
            </div>
            <div className="field">
              <label htmlFor="shop-hours">Business hours</label>
              <textarea
                id="shop-hours"
                className="input"
                value={form.businessHours}
                maxLength={300}
                rows={3}
                placeholder="e.g. Monday–Saturday, 9:00 AM–7:00 PM"
                disabled={busy}
                onChange={(event) => change('businessHours', event.target.value)}
              />
            </div>
          </div>
        </section>
        <div
          className="form-actions"
          style={{ justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}
        >
          <span className="muted" style={{ fontSize: 12 }}>
            {modified ? 'You have unsaved changes.' : 'Your shop settings are up to date.'}
          </span>
          <div style={{ display: 'flex', gap: 10 }}>
            <button
              className="button button-secondary"
              type="button"
              disabled={busy || !modified}
              onClick={() => {
                setForm(shopForm(currentShop));
                setNotice({ type: 'success', message: '' });
              }}
            >
              Discard changes
            </button>
            <button type="submit" className="button button-primary" disabled={busy || !modified}>
              {saving ? <LoaderCircle size={16} className="spin" /> : <Save size={16} />}
              {saving ? 'Saving…' : 'Save changes'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
