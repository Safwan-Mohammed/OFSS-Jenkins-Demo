import { useEffect, useRef, useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { ArrowRight, Check, Leaf, Package, ShieldCheck, Store, TrendingUp } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Brand } from '../components/Layout';
import { Notice } from '../components/ui';

export default function Login() {
  const { user, login, config, configError } = useAuth();
  const navigate = useNavigate();
  const googleRef = useRef(null);
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const authenticate = async (type, body, key) => {
    setBusy(key);
    setError('');
    try {
      const result = await login(type, body);
      navigate(result.user.role === 'super_admin' ? '/platform' : '/dashboard');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy('');
    }
  };
  useEffect(() => {
    if (!config.googleClientId) return;
    let cancelled = false;
    const render = () => {
      if (cancelled || !window.google || !googleRef.current) return;
      window.google.accounts.id.initialize({
        client_id: config.googleClientId,
        callback: (result) => authenticate('google', { credential: result.credential }, 'google'),
      });
      window.google.accounts.id.renderButton(googleRef.current, {
        type: 'standard',
        theme: 'outline',
        size: 'large',
        width: 320,
        text: 'continue_with',
      });
    };
    const existing = document.getElementById('google-gsi');
    if (existing) {
      if (window.google) render();
      else existing.addEventListener('load', render);
    } else {
      const script = document.createElement('script');
      script.id = 'google-gsi';
      script.src = 'https://accounts.google.com/gsi/client';
      script.async = true;
      script.onload = render;
      script.onerror = () =>
        setError('Google sign-in could not load. Check your connection and try again.');
      document.head.appendChild(script);
    }
    return () => {
      cancelled = true;
      existing?.removeEventListener('load', render);
    };
  }, [config.googleClientId]);
  if (user)
    return <Navigate to={user.role === 'super_admin' ? '/platform' : '/dashboard'} replace />;
  return (
    <div className="login-page">
      <section className="login-story">
        <Brand light />
        <div className="login-story-content">
          <span className="eyebrow light">
            <span />
            YOUR NEXT CHAPTER IN WHOLESALE
          </span>
          <h1>
            A small step online.
            <br />A big leap for
            <br />
            <em>your business.</em>
          </h1>
          <p>
            Your products. Your customers. One beautifully simple place to bring it all together.
          </p>
          <div className="login-benefits">
            {[
              'A catalog customers love to browse',
              'Orders that come straight to WhatsApp',
              'Less admin. More room to grow.',
            ].map((text) => (
              <div key={text}>
                <span>
                  <Check size={14} />
                </span>
                {text}
              </div>
            ))}
          </div>
          <div className="login-mini-card">
            <div className="login-mini-icon">
              <Store size={28} />
            </div>
            <div>
              <strong>Your neighborhood. Your network.</strong>
              <span>Built for independent wholesale merchants.</span>
            </div>
            <Leaf size={25} />
          </div>
        </div>
        <span className="login-copyright">
          © {new Date().getFullYear()} SupplyLane. Built for better business.
        </span>
      </section>
      <section className="login-form-panel">
        <div className="login-form">
          <span className="eyebrow">LET’S GET TO WORK</span>
          <h2>Welcome to SupplyLane</h2>
          <p className="login-subtitle">Your business is growing. Let’s keep it moving.</p>
          <Notice type="error">{error || configError?.message}</Notice>
          {config.googleClientId ? (
            <div className="google-login" ref={googleRef} />
          ) : (
            !config.demoMode && (
              <div className="notice">
                Google sign-in is not configured yet. Set GOOGLE_CLIENT_ID on the server to connect
                your account.
              </div>
            )
          )}
          {config.demoMode && (
            <>
              <div className="demo-login-label">
                <span />
                EXPLORE THE LOCAL DEMO
                <span />
              </div>
              <button
                className="button button-primary demo-login-button"
                disabled={!!busy}
                onClick={() => authenticate('demo', { account: 'merchant' }, 'merchant')}
              >
                <Store size={19} />
                {busy === 'merchant' ? 'Opening workspace…' : 'Open merchant workspace'}
                <ArrowRight size={19} />
              </button>
              <div className="demo-login-options">
                <button
                  className="button button-secondary"
                  disabled={!!busy}
                  onClick={() => authenticate('demo', { account: 'super_admin' }, 'admin')}
                >
                  <ShieldCheck size={17} />
                  Platform admin
                </button>
                <Link className="button button-secondary" to="/shop/greenfield-wholesale">
                  <Package size={17} />
                  Customer catalog
                </Link>
              </div>
              <p className="login-demo-note">
                A working demo with sample data. No sign-up needed.
                <br />
                Data resets when the local server restarts.
              </p>
            </>
          )}
          <div className="login-security">
            <ShieldCheck size={17} />
            <span>Secure sign-in. Your shop stays yours.</span>
          </div>
        </div>
        <div className="login-bottom">
          A little less busywork. A lot more business. <TrendingUp size={16} />
        </div>
      </section>
    </div>
  );
}
